from pathlib import Path
import base64,hashlib,json,re,unittest
root=Path(__file__).resolve().parents[1]
class SourceChecks(unittest.TestCase):
    def test_seed_identity(self):
        m=json.loads((root/'release-manifest.json').read_text())
        for f in m['files']:
            p=root/'seed'/f['path']
            if p.exists():
                self.assertEqual(p.stat().st_size,f['bytes'])
                self.assertEqual(hashlib.sha512(p.read_bytes()).hexdigest(),f['sha512'])
    def test_embedded_route_has_no_external_staging(self):
        s=(root/'scripts/Start-OfflineSetup.ps1').read_text()
        self.assertIn("$release='/home/elastic/releases/elastic-kit-9.5.4-e2e'",s)
        for forbidden in ('Invoke-WebRequest','Invoke-RestMethod','mounted-share','Local staging root','dnf '):self.assertNotIn(forbidden,s)
    def test_existing_installer_is_not_preempted(self):
        b=json.loads((root/'blueprint-template.json').read_text())
        self.assertFalse({'elasticsearch','kibana','elastic-agent','logstash'} & set(b['customizations']['packages']))
        self.assertNotIn('users',b['customizations'])
        self.assertEqual(b['customizations']['containers'][0]['source'],'PAYLOAD_DIGEST_REQUIRED')
        mounts={x['mountpoint']:x['min_size'] for x in b['customizations']['filesystem']}
        self.assertGreaterEqual(mounts['/home'],8*1024**3)
        self.assertGreaterEqual(mounts['/srv/elastic-data'],30*1024**3)
    def test_never_pull_at_boot(self):
        s=(root/'scripts/Stage-V15.sh').read_text()
        self.assertIn('--pull=never',s)
        b=json.loads((root/'blueprint-template.json').read_text())
        units='\n'.join(base64.b64decode(x['data']).decode() for x in b['customizations']['files'])
        self.assertIn('--pull=never',units)
        self.assertNotIn('network-online.target',units)
    def test_local_script_dependencies(self):
        for p in (root/'scripts').glob('*'):
            if p.suffix not in ('.ps1','.psm1'):continue
            for name in re.findall(r"Join-Path \$PSScriptRoot '([^']+\.(?:ps1|psm1|py|sh))'",p.read_text()):
                self.assertTrue((root/'scripts'/name).exists(),f'{p.name}: {name}')
    def test_service_helper_does_not_depend_on_home(self):
        self.assertIn("$helper='/usr/local/libexec/elastic-kit/artifact-server.py'",(root/'scripts/Install-KitFleet.ps1').read_text())
    def test_curated_catalog(self):
        c=json.loads((root/'integration-catalog.json').read_text())
        self.assertEqual(len(c),26)
        self.assertTrue({'tenable_sc','trellix_epo_on_prem','windows','netflow'} <= {x['name'] for x in c})
        self.assertFalse({'aws','azure','gcp'} & {x['name'] for x in c})
if __name__=='__main__':unittest.main()
