#!/bin/bash
# Runs on the guest with no network fetches; all content was embedded by Red Hat.
set -Eeuo pipefail
umask 077
test "$EUID" = 0
home=/home/elastic
image=localhost/elastic-watchtower-v15:payload
for path in "$home" /var/lib/elastic-kit /etc/elastic-kit; do
  test ! -L "$path" || { echo "Unexpected symlink: $path"; exit 1; }
done
install -d -m 0700 "$home" /var/lib/elastic-kit /etc/elastic-kit /var/log/elastic-kit
exec 9>/var/lib/elastic-kit/v15-stage.lock
flock -n 9 || exit 75
exec >>/var/log/elastic-kit/v15-stage.log 2>&1
podman image exists "$image" || { echo 'Required embedded payload container is missing; no download will be attempted.'; exit 1; }
stage=$(mktemp -d /home/elastic/.v15-stage-XXXXXXXX)
cid=''
cleanup() {
  if [[ -n "$cid" ]]; then podman rm "$cid" >/dev/null || true; fi
  if [[ "$stage" == /home/elastic/.v15-stage-* && -d "$stage" ]]; then rm -rf -- "$stage"; fi
}
trap cleanup EXIT
cid=$(podman create --pull=never "$image" /bin/false)
podman cp "$cid:/payload/." "$stage/"
/usr/libexec/platform-python - "$stage" <<'PY'
import hashlib,json,pathlib,sys
root=pathlib.Path(sys.argv[1])
def digest(path,algo):
    h=hashlib.new(algo)
    with path.open('rb') as f:
        while True:
            b=f.read(1048576)
            if not b: break
            h.update(b)
    return h.hexdigest()
for name,wanted in json.loads((root/'source-manifest.json').read_text()).items():
    if '..' in pathlib.PurePosixPath(name).parts or name.startswith('/'): raise SystemExit('Invalid source path')
    if digest(root/name,'sha256')!=wanted: raise SystemExit('Source checksum mismatch')
release=root/'releases/elastic-kit-9.5.4-e2e'
manifest=release/'release-manifest.json'
if digest(manifest,'sha256')!='04fa5e413b60088c676b6ff414f667bf08828409bb6717f45b73047ebf212ddb': raise SystemExit('Manifest mismatch')
for item in json.loads(manifest.read_text())['files']:
    p=release/item['path']
    if '..' in pathlib.PurePosixPath(item['path']).parts or item['path'].startswith('/'): raise SystemExit('Invalid payload path')
    if p.stat().st_size!=item['bytes'] or digest(p,'sha512')!=item['sha512']: raise SystemExit('Payload checksum mismatch: '+item['path'])
PY
for directory in scripts releases tools; do
  if [[ -e "$home/$directory" ]]; then
    test ! -L "$home/$directory"
    diff -qr "$home/$directory" "$stage/$directory" || { echo 'Different release preserved; explicit upgrade required.'; exit 1; }
  else
    mv "$stage/$directory" "$home/$directory"
  fi
done
chown -R root:root "$home/scripts" "$home/releases" "$home/tools"
find "$home/scripts" "$home/releases" "$home/tools" -type d -exec chmod 0700 {} +
find "$home/scripts" "$home/releases" "$home/tools" -type f -exec chmod 0600 {} +
install -m 0600 "$stage/source-manifest.json" "$home/source-manifest.json"
install -m 0600 "$stage/integration-catalog.json" "$home/integration-catalog.json"
install -d -m 0700 "$home/kits"
for pair in config:/etc/elastic-kit state:/var/lib/elastic-kit logs:/var/log/elastic-kit; do
  name=${pair%%:*}; target=${pair#*:}
  if [[ -L "$home/$name" ]]; then test "$(readlink "$home/$name")" = "$target"
  elif [[ -e "$home/$name" ]]; then echo "Unexpected existing path $name";exit 1
  else ln -s "$target" "$home/$name"; fi
done
# Services using ProtectHome cannot read scripts under /home.
install -d -m 0755 /usr/local/libexec/elastic-kit
install -m 0644 "$home/scripts/artifact-server.py" /usr/local/libexec/elastic-kit/artifact-server.py
/usr/libexec/platform-python "$home/scripts/normalize-shm-fstab.py"
mount -o remount /dev/shm
restorecon -RF "$home" /usr/local/libexec/elastic-kit /etc/elastic-kit /var/lib/elastic-kit /var/log/elastic-kit /etc/fstab
while IFS= read -r -d '' file; do
  fapolicyd-cli --file update "$file" || fapolicyd-cli --file add "$file"
done < <(find "$home/scripts" /usr/local/libexec/elastic-kit -type f -print0)
fapolicyd-cli --update
install -m 0644 "$home/scripts/elastic-login.sh" /etc/profile.d/elastic-watchtower.sh
restorecon /etc/profile.d/elastic-watchtower.sh
fapolicyd-cli --file update /etc/profile.d/elastic-watchtower.sh || fapolicyd-cli --file add /etc/profile.d/elastic-watchtower.sh
fapolicyd-cli --update
systemctl daemon-reload
systemctl enable --now elastic-epr
printf 'verified\n' > /var/lib/elastic-kit/v15-payload-ready
echo 'Offline payload ready; open /home/elastic/scripts/Start-Appliance.ps1 with pwsh.'
