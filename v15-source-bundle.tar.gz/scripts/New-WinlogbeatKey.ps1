#requires -Version 7.2
[CmdletBinding()]
param([Parameter(Mandatory)][string]$SiteProfile,
      [Parameter(Mandatory)][ValidatePattern('^[A-Za-z0-9][A-Za-z0-9.-]{0,252}$')][string]$ComputerName,
      [ValidateRange(1,365)][int]$ValidDays=90)
$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
Import-Module (Join-Path $PSScriptRoot 'SiteProfile.psm1') -Force
Import-Module (Join-Path $PSScriptRoot 'Kit.Common.psm1') -Force
Assert-KitRoot
$profile=Get-Content -Raw -LiteralPath $SiteProfile | ConvertFrom-Json -AsHashtable
$null=Test-SiteProfile $profile
$folder='/etc/elastic-kit/endpoint-keys/'+$ComputerName.ToLowerInvariant()
if(Test-Path $folder){throw 'Existing endpoint key record preserved. Use a reviewed rotation procedure.'}
$null=Invoke-KitNative install @('-d','-m','0700',$folder)
$keyId=$null
try {
    $body=@{name=('kit-'+$profile.site_name+'-'+$ComputerName);expiration=([string]$ValidDays+'d');role_descriptors=@{winlogbeat_publisher=@{cluster=@('monitor','read_ilm','read_pipeline');indices=@(@{names=@('winlogbeat-9.5.4');privileges=@('view_index_metadata','create_doc','auto_configure')})}};metadata=@{site=$profile.site_name;assigned_endpoint=$ComputerName;purpose='winlogbeat-publishing'}}
    $result=(Invoke-KitApi $profile -Method POST -Path '/_security/api_key' -Body $body).Data
    $keyId=$result.id
    Write-KitPrivateFile "$folder/publishing.key" ($result.id+':'+$result.api_key+"`n") -CreateNew
    $record=@{id=$result.id;assigned_endpoint=$ComputerName;expires_unix_ms=$result.expiration;created_utc=[DateTime]::UtcNow.ToString('o')}
    Write-KitPrivateFile "$folder/key-record.json" ($record|ConvertTo-Json) -CreateNew
    $result=$null
} catch {
    if($keyId){$null=Invoke-KitApi $profile -Method DELETE -Path '/_security/api_key' -Body @{ids=@($keyId)} -AllowFailure}
    throw
}
Write-Host "Protected key file: $folder/publishing.key"
Write-Host 'Transfer only to the assigned endpoint using approved protected staging. Never copy it into the common Winlogbeat folder.'
Write-Host "Schedule rotation before $ValidDays days. The hostname is an assignment label, not a cryptographic host restriction."
