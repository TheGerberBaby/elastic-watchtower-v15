#requires -Version 7.2
[CmdletBinding()]
param([Parameter(Mandatory)][string]$SiteProfile,
      [Parameter(Mandatory)][string]$CertificateDirectory,
      [Parameter(Mandatory)][string]$HttpCA,
      [string]$OutputDirectory='/etc/elastic-kit/pki',
      [string]$CsrKeyDirectory)
$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
Import-Module (Join-Path $PSScriptRoot 'SiteProfile.psm1') -Force
Import-Module (Join-Path $PSScriptRoot 'Kit.Common.psm1') -Force
$profile=Get-Content -Raw -LiteralPath $SiteProfile | ConvertFrom-Json -AsHashtable
$null=Test-SiteProfile $profile
if ($profile.mode -ne 'fresh' -or $profile.tls_mode -notin @('provided','csr')) { throw 'This importer is only for fresh sites that selected an existing CA.' }
Assert-KitRoot
if (Test-Path -LiteralPath $OutputDirectory) { throw 'Existing site PKI preserved; use the renewal/recovery procedure.' }
function Assert-PublicCA([string]$Path) {
    $pem=[IO.File]::ReadAllText($Path)
    if ($pem.Contains('PRIVATE KEY')) { throw 'A CA certificate file must contain only public certificates.' }
    $cert=[Security.Cryptography.X509Certificates.X509Certificate2]::CreateFromPem($pem)
    try {
        $caExtension=@($cert.Extensions | Where-Object { $_.Oid.Value -eq '2.5.29.19' })
        if ($caExtension.Count -ne 1 -or -not $caExtension[0].CertificateAuthority) { throw 'Expected a CA certificate.' }
        if ($cert.NotAfter.ToUniversalTime() -le [DateTime]::UtcNow -or $cert.NotBefore.ToUniversalTime() -gt [DateTime]::UtcNow) { throw 'CA is outside its validity period.' }
    } finally { $cert.Dispose() }
}
Assert-PublicCA $HttpCA
$transportCA=Resolve-KitMember $CertificateDirectory 'transport-ca/ca.crt' -MustExist
Assert-PublicCA $transportCA
$staged=@()
foreach ($service in @('elasticsearch-http','elasticsearch-transport','kibana','fleet-server','artifacts')) {
    $certificate=Resolve-KitMember $CertificateDirectory "$service/$service.crt" -MustExist
    $keyRoot=if($CsrKeyDirectory){$CsrKeyDirectory}else{$CertificateDirectory}
    $key=Resolve-KitMember $keyRoot "$service/$service.key" -MustExist
    $ca=if($service -eq 'elasticsearch-transport'){$transportCA}else{$HttpCA}
    $null=Invoke-KitNative openssl @('verify','-CAfile',$ca,'-purpose','sslserver','-verify_hostname',$profile.hostname,$certificate)
    $null=Invoke-KitNative openssl @('verify','-CAfile',$ca,'-purpose','sslserver','-verify_ip',$profile.ipv4_address,$certificate)
    $null=Invoke-KitNative openssl @('x509','-in',$certificate,'-checkend','2592000','-noout')
    if ($service -eq 'elasticsearch-transport') { $null=Invoke-KitNative openssl @('verify','-CAfile',$ca,'-purpose','sslclient',$certificate) }
    $publicCert=(Invoke-KitNative openssl @('x509','-in',$certificate,'-noout','-pubkey')).Stdout.Trim()
    # An empty passphrase prevents accidental interactive hangs. Encrypted keys
    # must be decrypted by the PKI administrator into protected local staging.
    $publicKey=(Invoke-KitNative openssl @('pkey','-in',$key,'-passin','pass:','-pubout') -Sensitive).Stdout.Trim()
    if ($publicCert -cne $publicKey) { throw "Certificate/key mismatch for $service" }
    $staged+=@{ Service=$service;Certificate=$certificate;Key=$key }
}
$null=Invoke-KitNative install @('-d','-m','0700',$OutputDirectory)
foreach ($layer in @('http','transport')) {
    $null=Invoke-KitNative install @('-d','-m','0700',"$OutputDirectory/$layer-ca")
    $inputCA=if($layer -eq 'http'){$HttpCA}else{$transportCA}
    $null=Invoke-KitNative install @('-m','0600',$inputCA,"$OutputDirectory/$layer-ca/ca.crt")
}
foreach ($entry in $staged) {
    $dir=Join-Path $OutputDirectory $entry.Service
    $null=Invoke-KitNative install @('-d','-m','0700',$dir)
    $null=Invoke-KitNative install @('-m','0600',$entry.Certificate,(Join-Path $dir ($entry.Service+'.crt')))
    $null=Invoke-KitNative install @('-m','0600',$entry.Key,(Join-Path $dir ($entry.Service+'.key')))
}
Write-KitPrivateFile (Join-Path $OutputDirectory 'import-complete.json') (@{ imported_at=[DateTime]::UtcNow.ToString('o');hostname=$profile.hostname;services=@($staged.Service);source_mode=$profile.tls_mode } | ConvertTo-Json) -CreateNew
Write-Output 'Supplied certificates passed chain, DNS/IP, expiry, purpose and key checks. CA signing keys were not imported.'
