if [ -n "${BASH_VERSION:-}" ] && [[ $- == *i* ]] && [ "$(id -u)" = 0 ] && [ -z "${SSH_CONNECTION:-}" ] && [ -z "${ELASTIC_MENU_OFFERED:-}" ] && [ -f /var/lib/elastic-kit/v15-payload-ready ]; then
  export ELASTIC_MENU_OFFERED=1
  printf '\nOpen the offline Elastic setup menu? [Y/n] '
  read -r elastic_answer
  case "$elastic_answer" in
    ''|y|Y|yes|YES) pwsh -NoLogo -NoProfile -File /home/elastic/scripts/Start-Appliance.ps1 ;;
  esac
  unset elastic_answer
fi
