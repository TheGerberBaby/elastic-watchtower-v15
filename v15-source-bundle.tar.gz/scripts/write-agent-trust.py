#!/usr/libexec/platform-python
"""Create an atomic, dedicated fapolicyd trust list from a stopped Agent tree.

Called only by the installer after release verification. Never run as a service
startup hook: that would silently trust later modifications. Runtime sockets,
logs, state and links are excluded; links resolve to separately listed files.
"""
import argparse
import hashlib
import os
import re
import stat
import tempfile


def records(root):
    root = os.path.abspath(root)
    if os.path.realpath(root) != root or not os.path.isdir(root):
        raise ValueError('Trust root must be a real directory, without links')
    result = []
    for folder, dirs, files in os.walk(root, followlinks=False):
        dirs[:] = sorted(d for d in dirs if not os.path.islink(os.path.join(folder, d))
                         and d not in ('logs', 'run', 'downloads'))
        for name in sorted(files):
            if name.endswith('.lock'):
                continue
            path = os.path.join(folder, name)
            before = os.lstat(path)
            if not stat.S_ISREG(before.st_mode):
                continue
            if any(ch in path for ch in ('\n', '\r', '\x00')):
                raise ValueError('Invalid path in trust tree')
            digest = hashlib.sha256()
            with open(path, 'rb') as stream:
                for chunk in iter(lambda: stream.read(1024 * 1024), b''):
                    digest.update(chunk)
            after = os.lstat(path)
            if (before.st_ino, before.st_size, before.st_mtime_ns) != (
                    after.st_ino, after.st_size, after.st_mtime_ns):
                raise ValueError('Agent files changed while preparing trust')
            result.append('{} {} {}\n'.format(path, before.st_size, digest.hexdigest()))
    if not result:
        raise ValueError('No regular Agent files found')
    return result


def projected_records(root, destination, version, upgrade=False):
    """Pin the reviewed package mapping before Fleet Server's first execution."""
    if os.path.realpath(destination) != destination:
        raise ValueError('Projected Agent destination must be absent and have no linked parents')
    if upgrade:
        if not os.path.isdir(destination):
            raise ValueError('Upgrade requires an existing real Agent home')
    elif os.path.lexists(destination):
        raise ValueError('Fresh projected Agent destination must be absent')
    with open(os.path.join(root, 'manifest.yaml')) as stream:
        manifest = stream.read()
    pattern = (r'\Aversion: co\.elastic\.agent/v1\nkind: PackageManifest\npackage:\n'
               r'    version: ' + re.escape(version) + r'\n'
               r'    hash: ([a-f0-9]{40})\n'
               r'    versioned-home: (data/elastic-agent-([a-f0-9]{6}))\n'
               r'    path-mappings:\n'
               r'        - ([^\n]+): ([^\n]+)\n'
               r'          manifest.yaml: ([^\n]+)\n'
               r'    flavors:\n')
    match = re.match(pattern, manifest)
    if not match:
        raise ValueError('Unreviewed Agent package path mapping')
    commit, old_home, short, mapping_source, new_home, new_manifest = match.groups()
    expected = 'data/elastic-agent-' + version + '-' + short
    if (not commit.startswith(short) or mapping_source != old_home
            or new_home != expected or new_manifest != expected + '/manifest.yaml'):
        raise ValueError('Agent version/hash/path mapping mismatch')
    if upgrade:
        target_home = os.path.join(destination, *new_home.split('/'))
        if os.path.realpath(target_home) != target_home:
            raise ValueError('Upgrade versioned home cannot traverse links')
        if os.path.lexists(target_home):
            raise ValueError('Existing target Agent version must be inspected, not re-trusted')
    projected = []
    seen = set()
    for line in records(root):
        path, size, digest = line.rstrip('\n').rsplit(' ', 2)
        relative = os.path.relpath(path, root).replace(os.sep, '/')
        if relative == 'manifest.yaml':
            relative = new_manifest
        elif relative.startswith(old_home + '/'):
            relative = new_home + relative[len(old_home):]
        if upgrade and not relative.startswith(new_home + '/'):
            continue
        target = os.path.join(destination, relative)
        if target in seen:
            raise ValueError('Duplicate projected trust path')
        seen.add(target)
        projected.append('{} {} {}\n'.format(target, size, digest))
    return projected


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', required=True)
    parser.add_argument('--name', required=True, choices=('elastic-kit-agent-stage', 'elastic-kit-agent', 'elastic-kit-agent-install', 'elastic-kit-agent-upgrade'))
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument('--project-to')
    mode.add_argument('--upgrade-to')
    parser.add_argument('--version')
    args = parser.parse_args()
    if os.geteuid() != 0:
        raise ValueError('Root required')
    destination = args.project_to or args.upgrade_to
    if destination:
        version = args.version or ''
        if not re.fullmatch(r'9\.5\.4(?:\+build[0-9]+)?', version):
            raise ValueError('Unreviewed Agent version')
        prefix = re.fullmatch(r'(/srv/[A-Za-z0-9_-]+)/Elastic/Agent', destination)
        expected_name = 'elastic-kit-agent-upgrade' if args.upgrade_to else 'elastic-kit-agent-install'
        if (not prefix or args.name != expected_name
                or args.root != prefix.group(1) + '/agent-install-' + version + '/elastic-agent-' + version + '-linux-x86_64'):
            raise ValueError('Invalid projected kit paths')
        data = projected_records(args.root, destination, version, upgrade=bool(args.upgrade_to))
    else:
        if args.name in ('elastic-kit-agent-install', 'elastic-kit-agent-upgrade') or not re.fullmatch(r'/srv/[A-Za-z0-9_-]+/(Elastic/Agent|agent-install-[A-Za-z0-9.+_-]+)', args.root):
            raise ValueError('Only the kit Agent directories may be trusted')
        data = records(args.root)
    parent = '/etc/fapolicyd/trust.d'
    os.makedirs(parent, mode=0o755, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix='.' + args.name + '-', dir=parent)
    try:
        with os.fdopen(fd, 'w') as stream:
            stream.write('# AUTOGENERATED FILE VERSION 3\n# Verified Elastic kit Agent payload\n')
            stream.writelines(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.chmod(temporary, 0o644)
        os.replace(temporary, os.path.join(parent, args.name))
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)
    print('Prepared {} regular-file trust records'.format(len(data)))


if __name__ == '__main__':
    main()
