#requires -Version 7.2
<# Engineering runner for a fresh stack created by Install-ElasticKit.ps1.
Do not run against an existing Fleet deployment or a recovery target.
#>
[CmdletBinding()]
param([Parameter(Mandatory)][string]$SiteProfile,
      [Parameter(Mandatory)][string]$ReleaseDirectory,
      [Parameter(Mandatory)][string]$ExpectedManifestSHA256,
      [Parameter(Mandatory)][string]$DataDirectory)
$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
Import-Module (Join-Path $PSScriptRoot 'SiteProfile.psm1') -Force
Import-Module (Join-Path $PSScriptRoot 'Kit.Common.psm1') -Force
Assert-KitRoot
$profile=Get-Content -Raw -LiteralPath $SiteProfile | ConvertFrom-Json -AsHashtable
$null=Test-SiteProfile $profile
if($profile.mode -ne 'fresh'){throw 'Fleet bootstrap refuses recovery profiles.'}
if($DataDirectory -notmatch '^/srv/[A-Za-z0-9_-]+$'){throw 'Invalid data directory.'}
$release=Read-KitRelease $ReleaseDirectory $ExpectedManifestSHA256 -RequireFull
$version=$release.Manifest.version
$agentVersion=$release.Roles.linux_agent[0].package_version
$parent=Get-Content -Raw /var/lib/elastic-kit/install-state.json | ConvertFrom-Json -AsHashtable
if($parent.release_sha256 -ne $release.SHA256 -or $parent.profile_sha256 -ne (Get-FileHash $SiteProfile -Algorithm SHA256).Hash){throw 'Fleet setup does not match this installation.'}
$ca=[IO.File]::ReadAllText('/etc/elastic-kit/pki/http-ca/ca.crt')
$ids=@{output='elastic-kit-output';hosts='elastic-kit-fleet-host';download='elastic-kit-download';policy='elastic-kit-server';package='elastic-kit-fleet-server'}
$fleetStatePath='/var/lib/elastic-kit/fleet-state.json'
if(Test-Path $fleetStatePath){$state=Get-Content -Raw $fleetStatePath | ConvertFrom-Json -AsHashtable}
else {
    if(Test-Path "$DataDirectory/Elastic/Agent"){throw 'Existing Agent installation preserved.'}
    $existing=Invoke-KitApi $profile -Service kibana -Path '/api/fleet/agent_policies?perPage=100'
    if(@($existing.Data.items | Where-Object {$_.id -eq $ids.policy}).Count){throw 'Existing kit Fleet policy preserved. No local ownership journal exists.'}
    $state=@{release_sha256=$release.SHA256;uploaded=@();created=@();status='preparing'}
    Write-KitPrivateFile $fleetStatePath ($state|ConvertTo-Json -Depth 15) -CreateNew
}
if($state.release_sha256 -ne $release.SHA256){throw 'Fleet release change requires the maintenance workflow.'}
function Save-FleetState { Write-KitPrivateFile $fleetStatePath ($state|ConvertTo-Json -Depth 15) }
function Create-FleetObject([string]$Kind,[string]$Id,[hashtable]$Body) {
    $route='/api/fleet/'+$Kind
    $found=Invoke-KitApi $profile -Service kibana -Path "$route/$Id" -AllowFailure
    if($found.Success){
        if($state.created -notcontains "$Kind/$Id"){throw "Unjournaled object preserved: $Kind/$Id. Inspect a possible interrupted create before resuming."}
        return
    }
    if($found.Status -ne 404){throw "Cannot inspect Fleet $Kind/$Id"}
    $Body.id=$Id
    $result=Invoke-KitApi $profile -Service kibana -Method POST -Path $route -Body $Body
    if($result.Data.item.id -ne $Id){throw 'Fleet returned an unexpected object identity.'}
    $state.created+=,"$Kind/$Id";Save-FleetState
}
# Kibana refuses uploaded packages whose names are bundled. Match the bundled
# bytes to our verified release, then install that exact version while offline.
$null=Invoke-KitApi $profile -Service kibana -Method POST -Path '/api/fleet/setup' -Body @{}
foreach($package in $release.Roles.integration) {
    if($package.package_name -notmatch '^[a-z0-9_]+$' -or $package.package_version -notmatch '^\d+\.\d+\.\d+$'){throw 'Integration identity is invalid.'}
    $identity=$package.package_name+'/'+$package.package_version
    if($state.uploaded -contains $identity){continue}
    $bundled='/usr/share/kibana/node_modules/@kbn/fleet-plugin/target/bundled_packages/'+$package.package_name+'-'+$package.package_version+'.zip'
    if(-not(Test-Path -LiteralPath $bundled) -or (Get-FileHash -LiteralPath $bundled -Algorithm SHA512).Hash -ne $package.sha512){throw "Pinned integration is not present in the signed Kibana RPM: $identity"}
    $null=Invoke-KitApi $profile -Service kibana -Method POST -Path ('/api/fleet/epm/packages/'+$identity) -Body @{}
    $state.uploaded+=,$identity;Save-FleetState
}
Create-FleetObject 'outputs' $ids.output @{name='This kit Elasticsearch';type='elasticsearch';hosts=@($profile.elasticsearch_url);is_default=$true;is_default_monitoring=$true;ssl=@{certificate_authorities=@($ca)};config_yaml="ssl.verification_mode: full`n"}
Create-FleetObject 'fleet_server_hosts' $ids.hosts @{name='This kit Fleet Server';host_urls=@($profile.fleet_url);is_default=$true}
Create-FleetObject 'agent_download_sources' $ids.download @{name='This kit offline artifacts';host="https://$($profile.hostname):8443";is_default=$true;ssl=@{certificate_authorities=@($ca)}}
# The kit has one default output. Explicit per-policy output overrides require a
# paid licence even when they point to that same output; inherit the default.
Create-FleetObject 'agent_policies' $ids.policy @{name='Kit Fleet Server';namespace='default';description='Dedicated local Fleet Server';monitoring_enabled=@();fleet_server_host_id=$ids.hosts;download_source_id=$ids.download}
$fleetPackage=@($release.Roles.integration | Where-Object {$_.package_name -eq 'fleet_server'})
if($fleetPackage.Count -ne 1){throw 'Expected one pinned Fleet Server integration.'}
Create-FleetObject 'package_policies' $ids.package @{name='Kit Fleet Server';namespace='default';enabled=$true;policy_ids=@($ids.policy);package=@{name='fleet_server';version=$fleetPackage[0].package_version};inputs=@(@{type='fleet-server';policy_template='fleet_server';enabled=$true;streams=@();vars=@{max_agents=@{value=100;type='integer'};custom=@{value="server.pgp.upstream_url: https://$($profile.hostname):8443/$($release.Roles.agent_pgp_key[0].artifact_path)`n";type='yaml'}}})}

# Only distributable payloads with explicit URL paths enter the public artifact
# directory. Site settings, certificates and tokens cannot be listed here.
$artifactRoot="$DataDirectory/artifacts"
$null=Invoke-KitNative install @('-d','-m','0755',$artifactRoot)
$allow=@();$served=[Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
foreach($file in $release.Manifest.files) {
    if(-not $file.Contains('artifact_path')){continue}
    if($file.role -notin @('linux_agent','windows_agent','agent_signature','agent_checksum','agent_pgp_key')){throw 'Non-distributable artifact role.'}
    if(-not $served.Add($file.artifact_path)){throw 'Duplicate artifact URL.'}
    $target=Resolve-KitMember $artifactRoot $file.artifact_path
    $null=Invoke-KitNative install @('-d','-m','0755',(Split-Path -Parent $target))
    if(Test-Path $target) {
        if((Get-FileHash $target -Algorithm SHA512).Hash -ne $file.sha512){throw 'Existing artifact content differs. Preserved.'}
    } else {$null=Invoke-KitNative install @('-m','0644',$file.full_path,$target)}
    $allow+=@{path=$file.artifact_path;bytes=$file.bytes}
}
foreach($role in @('linux_agent','windows_agent','agent_pgp_key')){if(-not $release.Roles[$role][0].Contains('artifact_path')){throw "Missing artifact URL: $role"}}
foreach($agent in @($release.Roles.linux_agent[0],$release.Roles.windows_agent[0])) {
    foreach($suffix in @('.sha512','.asc')){if(-not $served.Contains($agent.artifact_path+$suffix)){throw "Missing offline Agent verification companion: $suffix"}}
}
$config=@{root=$artifactRoot;bind=$profile.ipv4_address;port=8443;certificate='/etc/elastic-kit/pki/artifacts/artifacts.crt';key='/etc/elastic-kit/pki/artifacts/artifacts.key';files=$allow}
Write-KitPrivateFile '/etc/elastic-kit/artifact-server.json' ($config|ConvertTo-Json -Depth 10)
$helper='/usr/local/libexec/elastic-kit/artifact-server.py'
$unit=@"
[Unit]
Description=Elastic kit approved offline artifacts over HTTPS
After=network-online.target
Wants=network-online.target
RequiresMountsFor=$artifactRoot
[Service]
Type=simple
ExecStart=/usr/libexec/platform-python $helper --config /etc/elastic-kit/artifact-server.json
Restart=on-failure
RestartSec=5
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
ReadOnlyPaths=$artifactRoot /etc/elastic-kit
CapabilityBoundingSet=
RestrictAddressFamilies=AF_INET AF_INET6 AF_UNIX
TasksMax=128
MemoryMax=256M
UMask=0077
[Install]
WantedBy=multi-user.target
"@
Write-KitPrivateFile '/etc/systemd/system/elastic-kit-https.service' ($unit+"`n") -Mode '0644'
$null=Invoke-KitNative restorecon @('-RF','/etc/elastic-kit',$artifactRoot)
$null=Invoke-KitNative fapolicyd-cli @('--file','add',$helper) -AllowFailure
$null=Invoke-KitNative fapolicyd-cli @('--update')
$null=Invoke-KitNative systemctl @('daemon-reload')
$null=Invoke-KitNative systemctl @('enable','--now','elastic-kit-https')
$artifactReady=$false
$artifactDeadline=[DateTime]::UtcNow.AddSeconds(60)
do {
    $probe=Invoke-KitNative curl @('--silent','--show-error','--fail','--noproxy','*','--connect-timeout','5','--max-time','10','--cacert','/etc/elastic-kit/pki/http-ca/ca.crt',"https://$($profile.hostname):8443/healthz") -AllowFailure
    if($probe.ExitCode -eq 0 -and $probe.Stdout.Trim() -eq 'ready'){$artifactReady=$true;break}
    Start-Sleep -Seconds 2
} while([DateTime]::UtcNow -lt $artifactDeadline)
if(-not $artifactReady){throw 'Artifact HTTPS service did not become ready within one minute.'}

$tokenPath='/etc/elastic-kit/secrets/fleet-server.token'
if(-not(Test-Path $tokenPath)) {
    $token=(Invoke-KitApi $profile -Method POST -Path '/_security/service/elastic/fleet-server/credential/token/elastic-kit').Data.token.value
    # Agent's service-token-path reader uses the bytes verbatim in an HTTP
    # Authorization header, so this secret file must not end with a newline.
    Write-KitPrivateFile $tokenPath $token -CreateNew
    $token=$null
}
$agentHome="$DataDirectory/Elastic/Agent"
if(-not(Test-Path "$agentHome/elastic-agent")) {
    $extract="$DataDirectory/agent-install-$agentVersion"
    $extractArgs=@((Join-Path $PSScriptRoot 'extract-agent.py'),'--archive',$release.Roles.linux_agent[0].full_path,'--destination',$extract,'--version',$agentVersion)
    if(Test-Path $extract){$extractArgs+=,'--verify-existing'}
    $null=Invoke-KitNative '/usr/libexec/platform-python' $extractArgs
    $binary="$extract/elastic-agent-$agentVersion-linux-x86_64/elastic-agent"
    $null=Invoke-KitNative '/usr/libexec/platform-python' @((Join-Path $PSScriptRoot 'write-agent-trust.py'),'--root',$extract,'--name','elastic-kit-agent-stage')
    # Fleet Server rejects --delay-enroll in this reviewed version. Pin the
    # vendor manifest's final paths/hashes before install invokes enrollment.
    $null=Invoke-KitNative '/usr/libexec/platform-python' @((Join-Path $PSScriptRoot 'write-agent-trust.py'),'--root',(Split-Path -Parent $binary),'--name','elastic-kit-agent-install','--project-to',$agentHome,'--version',$agentVersion)
    $null=Invoke-KitNative restorecon @('-RF','/etc/fapolicyd/trust.d')
    $null=Invoke-KitNative fapolicyd-cli @('--update')
    $args=@('install','--non-interactive','--install-servers',"--base-path=$DataDirectory",("--url="+$profile.fleet_url),("--fleet-server-es="+$profile.elasticsearch_url),"--fleet-server-policy=$($ids.policy)","--fleet-server-service-token-path=$tokenPath",'--certificate-authorities=/etc/elastic-kit/pki/http-ca/ca.crt','--fleet-server-es-ca=/etc/elastic-kit/pki/http-ca/ca.crt','--fleet-server-cert=/etc/elastic-kit/pki/fleet-server/fleet-server.crt','--fleet-server-cert-key=/etc/elastic-kit/pki/fleet-server/fleet-server.key',"--fleet-server-host=$($profile.ipv4_address)",'--fleet-server-port=8220','--fleet-server-timeout=5m')
    $installed=Invoke-KitNative $binary $args -Sensitive -AllowFailure -TimeoutSeconds 420
    if($installed.ExitCode -ne 0){
        Write-KitPrivateFile '/var/lib/elastic-kit/agent-install-error.txt' ($installed.Stdout+"`n"+$installed.Stderr)
        throw 'Agent install failed; diagnostic retained only in protected /var/lib/elastic-kit/agent-install-error.txt.'
    }
}
$null=Invoke-KitNative systemctl @('stop','elastic-agent')
$null=Invoke-KitNative '/usr/libexec/platform-python' @((Join-Path $PSScriptRoot 'write-agent-trust.py'),'--root',$agentHome,'--name','elastic-kit-agent')
if(Test-Path '/etc/fapolicyd/trust.d/elastic-kit-agent-install'){[IO.File]::Delete('/etc/fapolicyd/trust.d/elastic-kit-agent-install')}
$null=Invoke-KitNative restorecon @('-RF','/etc/fapolicyd/trust.d')
$null=Invoke-KitNative fapolicyd-cli @('--update')
$null=Invoke-KitNative systemctl @('restart','elastic-agent')
$deadline=[DateTime]::UtcNow.AddMinutes(3)
$healthy=$false
do {
    $probe=Invoke-KitNative curl @('--silent','--show-error','--fail','--noproxy','*','--connect-timeout','5','--max-time','10','--cacert','/etc/elastic-kit/pki/http-ca/ca.crt',($profile.fleet_url+'/api/status')) -AllowFailure
    if($probe.ExitCode -eq 0){
        $status=$probe.Stdout | ConvertFrom-Json -AsHashtable
        if($status.status -eq 'HEALTHY'){$healthy=$true;break}
    }
    Start-Sleep -Seconds 3
} while([DateTime]::UtcNow -lt $deadline)
if(-not $healthy){throw 'Fleet Server HTTPS status did not become HEALTHY within three minutes.'}
$state.status='fleet-https-healthy-endpoint-acceptance-pending';Save-FleetState
Write-Host 'Fleet Server answered HEALTHY over verified HTTPS. Endpoint enrollment remains a separate acceptance test.'
