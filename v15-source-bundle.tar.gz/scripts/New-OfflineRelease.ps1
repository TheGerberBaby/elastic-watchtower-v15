#requires -Version 7.2
<# Run on the connected preparation workstation after browser downloads.
This command copies only explicitly listed inputs. It makes no network requests.
#>
[CmdletBinding()]
param([Parameter(Mandatory)][string]$InputPlan,
      [Parameter(Mandatory)][string]$OutputDirectory)
$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
Import-Module (Join-Path $PSScriptRoot 'Kit.Common.psm1') -Force
$plan=Get-Content -Raw -LiteralPath $InputPlan | ConvertFrom-Json -AsHashtable
if ($plan.version -notmatch '^\d+\.\d+\.\d+$' -or $plan.release_id -notmatch '^[A-Za-z0-9_-]{1,80}$') { throw 'Invalid version/release identity.' }
if (Test-Path -LiteralPath $OutputDirectory) { throw 'Existing release preserved. Build into a new versioned directory.' }
$approved=@();$paths=[Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
foreach ($input in $plan.files) {
    if (-not $paths.Add([string]$input.path)) { throw 'Duplicate output path.' }
    $null=Resolve-KitMember $OutputDirectory $input.path
    if ($input.sha512 -notmatch '^[a-fA-F0-9]{128}$') { throw 'Every input needs an independently approved SHA-512.' }
    $source=Get-Item -LiteralPath $input.source
    if ($source.PSIsContainer -or $source.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Only regular input files are supported.' }
    if ((Get-FileHash -LiteralPath $source.FullName -Algorithm SHA512).Hash -ne $input.sha512) { throw "Input checksum mismatch: $($input.path)" }
    $entry=@{role=$input.role;path=$input.path;sha512=$input.sha512.ToLowerInvariant();bytes=$source.Length}
    foreach($field in @('package_name','package_version','artifact_path','pipeline_id')) { if($input.Contains($field)){$entry[$field]=$input[$field]} }
    $approved+=@{ Source=$source.FullName;Entry=$entry }
}
$null=New-Item -ItemType Directory -Path $OutputDirectory
foreach ($item in $approved) {
    $target=Resolve-KitMember $OutputDirectory $item.Entry.path
    $null=New-Item -ItemType Directory -Path (Split-Path -Parent $target) -Force
    Copy-Item -LiteralPath $item.Source -Destination $target
}
$manifest=[ordered]@{schema_version=1;release_id=$plan.release_id;version=$plan.version;created_utc=[DateTime]::UtcNow.ToString('o');files=@($approved.Entry)}
if($plan.Contains('allowed_upgrade_from')){$manifest.allowed_upgrade_from=@($plan.allowed_upgrade_from)}
$manifestPath=Join-Path $OutputDirectory 'release-manifest.json'
[IO.File]::WriteAllText($manifestPath,($manifest | ConvertTo-Json -Depth 12),[Text.UTF8Encoding]::new($false))
$hash=(Get-FileHash -LiteralPath $manifestPath -Algorithm SHA256).Hash.ToLowerInvariant()
$null=Read-KitRelease -Directory $OutputDirectory -ExpectedManifestSHA256 $hash -RequireFull
[pscustomobject]@{ReleaseDirectory=[IO.Path]::GetFullPath($OutputDirectory);ManifestSHA256=$hash;Status='assembled; deployment acceptance still required'}
