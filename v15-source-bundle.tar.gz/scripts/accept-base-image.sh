#!/bin/bash
# Read-only base-image checks. Does not configure, clean, install or join anything.
set -uo pipefail
export LC_ALL=C
failures=0
check() {
  local label=$1; shift
  if "$@"; then printf 'PASS: %s\n' "$label"; else
    printf 'FAIL: %s\n' "$label"; failures=$((failures+1))
  fi
}
[[ $(id -u) == 0 ]] || { echo 'Run as root to inspect protected paths.'; exit 2; }
echo 'Elastic offline base acceptance; no changes are made'
date -u +%FT%TZ
check 'RHEL 8' bash -c '. /etc/os-release; [[ "$ID" == rhel && "$VERSION_ID" == 8.* ]]'
check 'x86_64' bash -c '[[ $(uname -m) == x86_64 ]]'
check 'Kernel FIPS enabled' grep -qx 1 /proc/sys/crypto/fips_enabled
check 'SELinux enforcing' bash -c '[[ $(getenforce) == Enforcing ]]'
for option in nodev nosuid noexec; do
  check "/dev/shm mounted with $option" bash -c 'findmnt -rn -o OPTIONS /dev/shm | tr , "\n" | grep -qx "$1"' _ "$option"
done
check 'Boot filesystem remount succeeded' bash -c '[[ $(systemctl show -p Result --value systemd-remount-fs.service) == success ]]'
for package in powershell podman open-vm-tools realmd sssd sssd-tools adcli oddjob oddjob-mkhomedir samba-common-tools krb5-libs cifs-utils keyutils chrony bind-utils curl jq tar unzip rsync lvm2 xfsprogs openscap-scanner scap-security-guide policycoreutils-python-utils; do
  check "Package $package" rpm -q "$package"
done
# The selected RHEL 8 STIG profile explicitly removes krb5-workstation.
# Its CLI tools are not a valid mandatory expectation for this base profile.
# Realmd/adcli/SSSD and Kerberos libraries still require a separate AD join test.
check 'STIG excludes krb5-workstation' bash -c '! rpm -q krb5-workstation >/dev/null 2>&1'
check 'PowerShell starts offline' pwsh -NoLogo -NoProfile -NonInteractive -Command '$PSVersionTable.PSVersion.ToString()'
check 'Podman starts' podman --version
check 'OpenSSL certificate checks available' openssl version
for service in sshd firewalld fapolicyd auditd chronyd vmtoolsd; do
  check "$service active" systemctl is-active --quiet "$service"
done
for package in elasticsearch kibana elastic-agent; do
  if rpm -q "$package" >/dev/null 2>&1; then
    echo "FAIL: $package is installed in reusable base"; failures=$((failures+1))
  else echo "PASS: $package is absent from RPM database"; fi
done
# Inspect only. Never delete paths on existing or restored systems.
for path in /etc/elasticsearch /etc/kibana /var/lib/elasticsearch /var/lib/kibana /opt/Elastic/Agent /etc/krb5.keytab; do
  if [[ -e "$path" || -L "$path" ]]; then
    echo "FAIL: Unexpected identity/data path exists: $path"; failures=$((failures+1))
  else echo "PASS: Absent $path"; fi
done
for helper in run-artifacts load-artifacts; do
  check "Artifact helper $helper present" test -x "/usr/local/libexec/elastic-kit/$helper"
done
for service in elasticsearch kibana; do
  check "$service masked" bash -c '[[ $(systemctl is-enabled "$1" 2>/dev/null) == masked ]]' _ "$service"
done
echo 'Filesystem evidence (capacity and options, not a production sizing acceptance):'
findmnt -rn -o TARGET,FSTYPE,OPTIONS /
df -h / /var /var/log /var/log/audit /home /tmp /var/tmp
echo "Failures: $failures"
echo 'Manual gates: unique OS/SSH identities across two clones; unique admin access; offline reboot; approved package inventory; STIG/ACAS; storage sizing.'
echo 'Passing does not certify security, absence of secrets elsewhere, Elastic FIPS, or production readiness.'
[[ $failures == 0 ]]
