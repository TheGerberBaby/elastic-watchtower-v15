#requires -Version 5.1
#requires -RunAsAdministrator
<#
Fresh endpoint installer for PsExec -s (LocalSystem). No interactive prompts.
Run only after release approval and local staging with restricted ACLs.
Existing Winlogbeat service, installation or data is preserved by refusing to run.
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory)][string]$ApiKeyFile,
    [Parameter(Mandatory)][ValidatePattern('^[a-fA-F0-9]{64}$')][string]$ExpectedManifestSHA256
)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
if ([Security.Principal.WindowsIdentity]::GetCurrent().User.Value -ne 'S-1-5-18') {
    throw 'Run as LocalSystem using PsExec -s; the keystore must be created under the service identity.'
}
$source = [IO.Path]::GetFullPath($PSScriptRoot)
$destination = Join-Path $env:ProgramFiles 'Winlogbeat'
$dataRoot = Join-Path $env:ProgramFiles 'Winlogbeat-Data'
$legacy = Join-Path $env:ProgramData 'Winlogbeat'
if ((Get-Service -Name winlogbeat -ErrorAction SilentlyContinue) -or (Test-Path -LiteralPath $destination) -or (Test-Path -LiteralPath $dataRoot) -or (Test-Path -LiteralPath $legacy)) {
    throw 'Existing service, installation or data detected. Use the tested upgrade procedure; nothing was changed.'
}
$manifestPath = Join-Path $source 'payload-manifest.json'
if ((Get-FileHash -LiteralPath $manifestPath -Algorithm SHA256).Hash -ne $ExpectedManifestSHA256) { throw 'Manifest hash mismatch.' }
$manifest = Get-Content -Raw -LiteralPath $manifestPath | ConvertFrom-Json
if ($manifest.schema_version -ne 1 -or $manifest.version -ne '9.5.4') { throw 'Unsupported payload manifest/version.' }
$approved = @{}
foreach ($entry in $manifest.files) {
    $relative = [string]$entry.path
    if ([IO.Path]::IsPathRooted($relative) -or $relative -match '(^|[\\/])\.\.?([\\/]|$)|:|[\x00-\x1f]' -or $entry.sha256 -notmatch '^[a-f0-9]{64}$') { throw 'Unsafe manifest entry.' }
    if ($approved.ContainsKey($relative)) { throw 'Duplicate manifest entry.' }
    $full = [IO.Path]::GetFullPath((Join-Path $source $relative))
    if (-not $full.StartsWith($source.TrimEnd('\')+'\',[StringComparison]::OrdinalIgnoreCase)) { throw 'Manifest path escapes payload.' }
    if ((Get-Item -LiteralPath $full).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Reparse points are not allowed.' }
    if ((Get-FileHash -LiteralPath $full -Algorithm SHA256).Hash.ToLowerInvariant() -ne $entry.sha256) { throw "Payload hash mismatch: $relative" }
    $approved[$relative]=$true
}
foreach ($name in @('winlogbeat.exe','winlogbeat.yml','install-service-winlogbeat.ps1','certs/ca.crt')) {
    if (-not $approved.ContainsKey($name)) { throw "Required manifest payload missing: $name" }
}
foreach ($item in Get-ChildItem -LiteralPath $source -Recurse -Force) {
    if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Reparse points are not allowed in the payload.' }
    if (-not $item.PSIsContainer) {
        $relative=$item.FullName.Substring($source.Length+1).Replace('\','/')
        if ($relative -ne 'payload-manifest.json' -and -not $approved.ContainsKey($relative)) { throw "Unlisted payload file: $relative" }
    }
}
$secretPath=[IO.Path]::GetFullPath($ApiKeyFile)
if ($secretPath.StartsWith('\\') -or -not (Test-Path -LiteralPath $secretPath -PathType Leaf)) { throw 'API key must be staged in a protected local file.' }
if ($secretPath.StartsWith($source.TrimEnd('\')+'\',[StringComparison]::OrdinalIgnoreCase)) { throw 'Keep endpoint credentials outside the distributable payload.' }
if ((Get-Item -LiteralPath $secretPath).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Secret file cannot be a reparse point.' }
foreach ($ace in (Get-Acl -LiteralPath $secretPath).Access) {
    $sid=$ace.IdentityReference.Translate([Security.Principal.SecurityIdentifier]).Value
    if ($ace.AccessControlType -eq 'Allow' -and $sid -notin @('S-1-5-18','S-1-5-32-544')) { throw 'Secret file ACL must allow only SYSTEM and Administrators.' }
}
$key=[IO.File]::ReadAllText($secretPath).Trim()
if ($key -notmatch '^[A-Za-z0-9_-]+:[A-Za-z0-9_-]+$') { throw 'Expected endpoint publishing key in id:api_key format.' }

$null=New-Item -ItemType Directory -Path $destination
& icacls.exe $destination '/inheritance:r' '/grant:r' '*S-1-5-18:(OI)(CI)F' '*S-1-5-32-544:(OI)(CI)F' | Out-Null
if ($LASTEXITCODE -ne 0) { throw 'Could not protect installation directory.' }
foreach ($relative in $approved.Keys) {
    $target=Join-Path $destination $relative
    $null=New-Item -ItemType Directory -Force -Path ([IO.Path]::GetDirectoryName($target))
    Copy-Item -LiteralPath (Join-Path $source $relative) -Destination $target
}
$null=New-Item -ItemType Directory -Path $dataRoot
& icacls.exe $dataRoot '/inheritance:r' '/grant:r' '*S-1-5-18:(OI)(CI)F' '*S-1-5-32-544:(OI)(CI)F' | Out-Null
if ($LASTEXITCODE -ne 0) { throw 'Could not protect data directory.' }
$data=Join-Path $dataRoot 'Winlogbeat'
$logs=Join-Path $data 'logs'
$keystoreDir=Join-Path $destination 'data'
$null=New-Item -ItemType Directory -Force -Path $data,$logs,$keystoreDir
$keystore=Join-Path $keystoreDir 'Winlogbeat.keystore'
$common=@('-c',(Join-Path $destination 'winlogbeat.yml'),'--path.home',$destination,'--path.data',$data,'--path.logs',$logs,'-E',"keystore.path=$keystore")
function Invoke-Beat {
    param([string[]]$BeatArguments,[string]$Secret)
    $info=New-Object Diagnostics.ProcessStartInfo
    $info.FileName=Join-Path $destination 'winlogbeat.exe'
    $info.WorkingDirectory=$destination
    # Fixed arguments/OS paths only; secrets never appear in command-line arguments.
    $allArgs=@($BeatArguments)+$common
    foreach($value in $allArgs) { if($value.Contains('"') -or $value.EndsWith('\')) { throw 'Invalid process argument.' } }
    $info.Arguments=($allArgs | ForEach-Object {'"'+$_+'"'}) -join ' '
    $info.UseShellExecute=$false; $info.CreateNoWindow=$true
    $info.RedirectStandardInput=$true; $info.RedirectStandardOutput=$true; $info.RedirectStandardError=$true
    $process=New-Object Diagnostics.Process
    $process.StartInfo=$info
    try {
        $null=$process.Start()
        $stdout=$process.StandardOutput.ReadToEndAsync(); $stderr=$process.StandardError.ReadToEndAsync()
        if($Secret) { $process.StandardInput.WriteLine($Secret) }
        $process.StandardInput.Close()
        if(-not $process.WaitForExit(120000)) { $process.Kill(); throw 'Winlogbeat command timed out.' }
        $null=$stdout.GetAwaiter().GetResult(); $null=$stderr.GetAwaiter().GetResult()
        if($process.ExitCode -ne 0) { throw "Winlogbeat $($BeatArguments[0]) failed with exit code $($process.ExitCode). Service has not been started." }
    } finally { $process.Dispose() }
}
try {
    Invoke-Beat -BeatArguments @('keystore','create')
    Invoke-Beat -BeatArguments @('keystore','add','WINLOGBEAT_API_KEY','--stdin') -Secret $key
    Invoke-Beat -BeatArguments @('test','config')
    Invoke-Beat -BeatArguments @('test','output')
} finally { $key=$null }
# The verified 9.5.4 vendor installer uses these same explicit paths. No legacy data exists.
& (Join-Path $destination 'install-service-winlogbeat.ps1')
$service=Get-CimInstance Win32_Service -Filter "Name='winlogbeat'"
if ($service.StartName -notin @('LocalSystem','NT AUTHORITY\SYSTEM') -or -not $service.PathName.Contains($keystore) -or -not $service.PathName.Contains($data)) {
    throw 'Installed service identity/path does not match the verified keystore configuration. Service left stopped.'
}
Start-Service -Name winlogbeat
(Get-Service winlogbeat).WaitForStatus('Running',[TimeSpan]::FromSeconds(30))
Write-Output 'Winlogbeat installed; config/output tests passed; service is running.'
Write-Output 'Verify arrival of this endpoint''s events in Kibana before declaring success.'
Write-Output 'Remove the staged endpoint secret through the approved credential-handling procedure.'
