"""Extract one approved Agent tarball with its reviewed launcher symlink.
The caller verifies SHA-512 against the trusted offline release first.
"""
import argparse, hashlib, os, re, shutil, tarfile

def extract(archive, destination, version, verify_existing=False):
    if not re.fullmatch(r'\d+\.\d+\.\d+(?:\+build\d+)?', version):
        raise ValueError('Invalid Agent version')
    expected='elastic-agent-{}-linux-x86_64'.format(version)
    if os.path.lexists(destination) and not verify_existing:
        raise ValueError('Existing staging directory preserved')
    if verify_existing and (not os.path.isdir(destination) or os.path.realpath(destination) != os.path.abspath(destination)):
        raise ValueError('Existing staging must be a real directory')
    with tarfile.open(archive, 'r:gz') as source:
        members=source.getmembers()
        seen={}
        unique=[]
        total=0
        for item in members:
            name=item.name.rstrip('/')
            parts=name.split('/')
            if (parts[0] != expected or any(p in ('','.','..') for p in parts)
                    or '\\' in name or '\x00' in name):
                raise ValueError('Unsafe Agent archive path')
            if name in seen:
                # This vendor build repeats this ZIP with modes 0755 and 0644.
                # Admit only that reviewed path with identical regular-file bytes.
                previous=seen[name]
                if (not re.fullmatch(re.escape(expected)+r'/data/elastic-agent-[a-f0-9]+/components/endpoint-security-resources\.zip',name)
                        or not item.isfile() or not previous.isfile()
                        or item.size != previous.size or item.mode not in (0o644,0o755)
                        or previous.mode not in (0o644,0o755)):
                    raise ValueError('Unreviewed duplicate Agent archive path')
                def digest(member):
                    result=hashlib.sha256()
                    with source.extractfile(member) as stream:
                        for block in iter(lambda: stream.read(1024*1024),b''):
                            result.update(block)
                    return result.digest()
                if digest(previous) != digest(item):
                    raise ValueError('Duplicate Agent file has different content')
                previous.mode=0o644
                continue
            if item.issym():
                if (name != expected+'/elastic-agent' or not
                        re.fullmatch(r'data/elastic-agent-[a-f0-9]+/elastic-agent',item.linkname)):
                    raise ValueError('Unreviewed Agent symlink')
            elif not (item.isdir() or item.isfile()):
                raise ValueError('Agent archive links/special files require explicit review')
            seen[name]=item
            unique.append(item)
            total+=item.size
            if total>8*1024**3 or len(seen)>150000:
                raise ValueError('Unexpected Agent archive size')
        members=unique
        indexed={item.name.rstrip('/'):item for item in members}
        for item in members:
            parts=item.name.rstrip('/').split('/')
            for end in range(1,len(parts)):
                ancestor=indexed.get('/'.join(parts[:end]))
                if ancestor is not None and not ancestor.isdir():
                    raise ValueError('Archive ancestor is not a directory')
            if item.issym():
                target=indexed.get(expected+'/'+item.linkname)
                if target is None or not target.isfile() or not target.mode & 0o111:
                    raise ValueError('Agent launcher target must be a regular executable')
        launcher=indexed.get(expected+'/elastic-agent')
        if launcher is None or not (launcher.isfile() or launcher.issym()):
            raise ValueError('Agent executable is absent')
        if verify_existing:
            allowed=set()
            for item in members:
                name=item.name.rstrip('/')
                parts=name.split('/')
                allowed.update('/'.join(parts[:end]) for end in range(1,len(parts)+1))
                target=os.path.join(destination,*parts)
                if item.issym():
                    if not os.path.islink(target) or os.readlink(target) != item.linkname:
                        raise ValueError('Existing Agent launcher differs')
                elif os.path.islink(target):
                    raise ValueError('Existing extracted member became a link')
                elif item.isdir():
                    if not os.path.isdir(target): raise ValueError('Existing directory is missing')
                else:
                    if not os.path.isfile(target) or os.path.getsize(target) != item.size:
                        raise ValueError('Existing payload size/type differs')
                    hashes=[]
                    with source.extractfile(item) as original, open(target,'rb') as current:
                        for stream in (original,current):
                            digest=hashlib.sha256()
                            for block in iter(lambda:stream.read(1024*1024),b''):digest.update(block)
                            hashes.append(digest.digest())
                    if hashes[0] != hashes[1]: raise ValueError('Existing payload bytes differ')
            for folder,dirs,files in os.walk(destination,followlinks=False):
                for name in dirs+files:
                    full=os.path.join(folder,name)
                    relative=os.path.relpath(full,destination).replace(os.sep,'/')
                    if relative == expected+'/data/agent.lock':
                        import fcntl
                        if os.path.islink(full) or not os.path.isfile(full) or os.path.getsize(full) != 0:
                            raise ValueError('Unexpected Agent staging lock')
                        with open(full,'rb') as lock:
                            fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
                        continue
                    if relative not in allowed:
                        raise ValueError('Unreviewed extra file in existing staging')
            print('Existing extracted Agent payload matches verified vendor archive')
            return
        os.mkdir(destination,0o700)
        for item in members:
            if item.issym():
                continue
            target=os.path.join(destination,*item.name.rstrip('/').split('/'))
            if item.isdir():
                os.makedirs(target,mode=0o755,exist_ok=True)
            else:
                os.makedirs(os.path.dirname(target),mode=0o755,exist_ok=True)
                with source.extractfile(item) as original, open(target,'xb') as output:
                    shutil.copyfileobj(original,output,1024*1024)
                os.chmod(target,0o755 if item.mode & 0o111 else 0o644)
        for item in members:
            if item.issym():
                os.symlink(item.linkname,os.path.join(destination,*item.name.split('/')))
    if not os.path.isfile(os.path.join(destination,expected,'elastic-agent')):
        raise ValueError('Agent executable is absent')

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--archive',required=True)
    parser.add_argument('--destination',required=True)
    parser.add_argument('--version',required=True)
    parser.add_argument('--verify-existing',action='store_true')
    args=parser.parse_args()
    extract(args.archive,args.destination,args.version,args.verify_existing)
