#!/bin/bash
# Fresh-site PKI helper. Invoked by New-SiteCertificates.ps1 after checking the
# site's explicit certutil choice. Never invoke during image construction/restore.
set -euo pipefail
umask 077
export LC_ALL=C
[[ $(id -u) == 0 && $# == 6 ]] || { echo 'Expected root and: OUTPUT FQDN IPV4 SITE CERTUTIL LEAF_DAYS'; exit 2; }
requested=$1
fqdn=$2
ip=$3
site=$4
certutil=$5
days=$6
[[ "$requested" == /* && "$requested" != *$'\n'* ]] || { echo 'Output must be an absolute local path.'; exit 2; }
[[ ${#fqdn} -le 253 && "$fqdn" =~ ^([a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?$ ]] || { echo 'Invalid FQDN'; exit 2; }
[[ "$site" =~ ^[a-zA-Z0-9][a-zA-Z0-9_-]{0,63}$ ]] || { echo 'Invalid site name'; exit 2; }
[[ "$days" =~ ^[1-9][0-9]{0,3}$ && "$days" -le 1095 ]] || { echo 'Invalid leaf validity'; exit 2; }
[[ "$ip" =~ ^[0-9]{1,3}(\.[0-9]{1,3}){3}$ ]] || { echo 'Invalid IPv4 address'; exit 2; }
IFS=. read -r -a octets <<< "$ip"
for octet in "${octets[@]}"; do
  [[ "$octet" == 0 || "$octet" != 0* ]] || { echo 'Ambiguous IPv4 address'; exit 2; }
  [[ $octet -le 255 ]] || { echo 'Invalid IPv4 address'; exit 2; }
done
[[ ${octets[0]} -gt 0 && ${octets[0]} -lt 224 && ${octets[0]} -ne 127 ]] || { echo 'Invalid unicast IPv4 address'; exit 2; }
for tool in realpath stat openssl unzip sha256sum mkdir chmod; do command -v "$tool" >/dev/null || { echo "Missing image prerequisite: $tool"; exit 2; }; done
[[ "$certutil" == /* && -f "$certutil" && -x "$certutil" ]] || { echo 'Expected the installed Elasticsearch certutil executable.'; exit 2; }
[[ ! -e "$requested" && ! -L "$requested" ]] || { echo 'Existing certificate output preserved; refusing regeneration.'; exit 1; }
output=$(realpath -m -- "$requested")
parent=$(dirname -- "$output")
[[ -d "$parent" && $(stat -c %u -- "$parent") == 0 ]] || { echo 'Output parent must exist and belong to root.'; exit 2; }
parent_mode=$(stat -c %a -- "$parent")
(( (8#$parent_mode & 0022) == 0 )) || { echo 'Output parent must not be writable by group or others.'; exit 2; }
# mkdir without -p fails on an existing destination, including concurrent calls.
mkdir -m 0700 -- "$output"
trap 'echo "Certificate step failed. Incomplete output is preserved at: $output" >&2' ERR
[[ $(stat -c %a -- "$output") == 700 ]] || { echo 'Filesystem did not enforce private directory permissions.'; exit 1; }
mkdir -m 0700 -- "$output/http-ca" "$output/transport-ca"
write_instances() {
  local filename=$1; shift
  printf 'instances:\n' > "$filename"
  local service
  for service in "$@"; do
    printf '  - name: "%s"\n    filename: "%s"\n    dns: ["%s"]\n    ip: ["%s"]\n' "$fqdn" "$service" "$fqdn" "$ip" >> "$filename"
  done
}
write_instances "$output/http-instances.yml" elasticsearch-http kibana fleet-server artifacts
write_instances "$output/transport-instances.yml" elasticsearch-transport
# Separate transport CA prevents HTTPS service identities from being trusted as
# Elasticsearch nodes. No CA/private key is put into the distributable Winlogbeat folder.
for layer in http transport; do
  "$certutil" ca --silent --pem --keysize 3072 --days 3650 \
    --ca-dn "CN=Elastic Kit $site $layer CA" --out "$output/$layer-ca.zip" >> "$output/generation.log" 2>&1
  # Read only the known entry names; never extract archive-supplied paths.
  unzip -p "$output/$layer-ca.zip" ca/ca.crt > "$output/$layer-ca/ca.crt"
  unzip -p "$output/$layer-ca.zip" ca/ca.key > "$output/$layer-ca/ca.key"
  "$certutil" cert --silent --pem --keysize 3072 --days "$days" \
    --in "$output/$layer-instances.yml" --ca-cert "$output/$layer-ca/ca.crt" \
    --ca-key "$output/$layer-ca/ca.key" --out "$output/$layer-certificates.zip" >> "$output/generation.log" 2>&1
done
for service in elasticsearch-http elasticsearch-transport kibana fleet-server artifacts; do
  layer=http
  [[ "$service" != elasticsearch-transport ]] || layer=transport
  mkdir -m 0700 -- "$output/$service"
  crt="$output/$service/$service.crt"
  key="$output/$service/$service.key"
  unzip -p "$output/$layer-certificates.zip" "$service/$service.crt" > "$crt"
  unzip -p "$output/$layer-certificates.zip" "$service/$service.key" > "$key"
  chmod 0600 -- "$crt" "$key"
  [[ $(stat -c %a -- "$key") == 600 && -s "$key" && -s "$crt" ]] || { echo 'Certificate/key permissions or output are invalid'; exit 1; }
  openssl verify -CAfile "$output/$layer-ca/ca.crt" -purpose sslserver -verify_hostname "$fqdn" "$crt" >> "$output/generation.log" 2>&1
  openssl verify -CAfile "$output/$layer-ca/ca.crt" -purpose sslserver -verify_ip "$ip" "$crt" >> "$output/generation.log" 2>&1
  if [[ "$layer" == transport ]]; then
    openssl verify -CAfile "$output/$layer-ca/ca.crt" -purpose sslclient "$crt" >> "$output/generation.log" 2>&1
  fi
  cert_public=$(openssl x509 -in "$crt" -noout -pubkey | openssl pkey -pubin -outform DER | sha256sum)
  key_public=$(openssl pkey -in "$key" -pubout -outform DER | sha256sum)
  [[ "$cert_public" == "$key_public" ]] || { echo 'Certificate/private-key mismatch'; exit 1; }
done
# The marker is written only after every chain, SAN and matching key has passed.
cat > "$output/README.txt" <<'README'
Site-specific private PKI material; never bake this directory into a reusable image.
Certificates were generated with Elasticsearch certutil and checked with OpenSSL.
CA keys, service keys and ZIP archives are unencrypted, protected by root-only
0700 directories and 0600 files. Back up through an encrypted protected process.
Distribute ONLY http-ca/ca.crt to Winlogbeat. Keep all CA signing keys and service
private keys on the server or in the protected recovery backup.
This helper does not configure/start services, create tokens, install a retention
policy, or establish Elastic/JVM FIPS compliance. Leaf validity defaults to 365
days; certificate renewal and backed-up identities are separate lifecycle steps.
README
date -u +%FT%TZ > "$output/generation-complete.txt"
trap - ERR
printf 'Generated and validated site certificates: %s\n' "$output"
printf 'Public CA for Winlogbeat: %s/http-ca/ca.crt\n' "$output"
