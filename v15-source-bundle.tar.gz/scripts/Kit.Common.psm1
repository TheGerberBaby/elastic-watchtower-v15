#requires -Version 7.2
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Invoke-KitNative {
    param([Parameter(Mandatory)][string]$File, [string[]]$Arguments = @(),
          [AllowNull()][string]$InputText, [switch]$AllowFailure, [switch]$Sensitive,
          [int]$TimeoutSeconds = 900, [hashtable]$Environment = @{})
    $start = [Diagnostics.ProcessStartInfo]::new()
    $start.FileName = $File
    $start.UseShellExecute = $false
    $start.RedirectStandardOutput = $true
    $start.RedirectStandardError = $true
    $start.RedirectStandardInput = $true
    $start.CreateNoWindow = $true
    foreach ($argument in $Arguments) { $start.ArgumentList.Add($argument) }
    foreach ($key in $Environment.Keys) { $start.Environment[$key] = [string]$Environment[$key] }
    $process = [Diagnostics.Process]::new()
    $process.StartInfo = $start
    try {
        $null = $process.Start()
        $outTask = $process.StandardOutput.ReadToEndAsync()
        $errTask = $process.StandardError.ReadToEndAsync()
        if ($null -ne $InputText) { $process.StandardInput.Write($InputText) }
        $process.StandardInput.Close()
        if (-not $process.WaitForExit($TimeoutSeconds * 1000)) {
            $process.Kill($true)
            throw "Native step timed out: $File. Inspect its service state before retrying."
        }
        $result = [pscustomobject]@{ ExitCode=$process.ExitCode; Stdout=$outTask.GetAwaiter().GetResult(); Stderr=$errTask.GetAwaiter().GetResult() }
        if ($result.ExitCode -ne 0 -and -not $AllowFailure) {
            if ($Sensitive) { throw "Protected native step failed: $File (exit $($result.ExitCode))." }
            throw "Native step failed: $File (exit $($result.ExitCode)): $($result.Stderr.Trim())"
        }
        return $result
    } finally { $process.Dispose() }
}

function Assert-KitRoot {
    if (-not $IsLinux -or (Invoke-KitNative id @('-u')).Stdout.Trim() -ne '0') {
        throw 'This deployment command requires the RHEL root console or authorized sudo session.'
    }
}

function Resolve-KitMember {
    param([Parameter(Mandatory)][string]$Root, [Parameter(Mandatory)][string]$Relative,
          [switch]$MustExist)
    if (($Relative -ne '.build_hash.txt' -and $Relative -notmatch '^[A-Za-z0-9_-][A-Za-z0-9_./ +\-]*$') -or
        @($Relative.Split('/') | Where-Object { $_ -in @('','.','..') -or $_.EndsWith('.') -or $_.EndsWith(' ') }).Count) {
        throw 'Unsafe relative release path.'
    }
    $base = [IO.Path]::GetFullPath($Root).TrimEnd([IO.Path]::DirectorySeparatorChar)
    $full = [IO.Path]::GetFullPath((Join-Path $base $Relative))
    if (-not $full.StartsWith($base+[IO.Path]::DirectorySeparatorChar,[StringComparison]::Ordinal)) { throw 'Release member escapes root.' }
    $walk = $base
    foreach ($part in @('') + $Relative.Split('/')) {
        if ($part) { $walk=Join-Path $walk $part }
        if (Test-Path -LiteralPath $walk) {
            if ((Get-Item -Force -LiteralPath $walk).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Release links/reparse points are not accepted.' }
        }
    }
    if ($MustExist -and -not (Test-Path -LiteralPath $full -PathType Leaf)) { throw "Release file missing: $Relative" }
    return $full
}

function Read-KitRelease {
    param([Parameter(Mandatory)][string]$Directory,
          [Parameter(Mandatory)][ValidatePattern('^[a-fA-F0-9]{64}$')][string]$ExpectedManifestSHA256,
          [switch]$RequireFull)
    $manifestPath = Resolve-KitMember $Directory 'release-manifest.json' -MustExist
    if ((Get-FileHash -LiteralPath $manifestPath -Algorithm SHA256).Hash -ne $ExpectedManifestSHA256) { throw 'Release manifest hash mismatch.' }
    $manifest = Get-Content -Raw -LiteralPath $manifestPath | ConvertFrom-Json -AsHashtable
    if ($manifest.schema_version -ne 1 -or $manifest.version -notmatch '^\d+\.\d+\.\d+$' -or $manifest.release_id -notmatch '^[A-Za-z0-9_-]{1,80}$') { throw 'Unsupported release identity or schema.' }
    $allowed = @('elasticsearch_rpm','kibana_rpm','linux_agent','windows_agent','winlogbeat_zip','elastic_signing_key','integration','winlogbeat_template','winlogbeat_pipeline','agent_signature','agent_checksum','agent_pgp_key')
    $seen=[Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
    $roles=@{}
    if (@($manifest.files).Count -lt 1) { throw 'Empty release.' }
    foreach ($entry in $manifest.files) {
        if ($entry.role -notin $allowed -or $entry.sha512 -notmatch '^[a-fA-F0-9]{128}$' -or $entry.bytes -isnot [long] -and $entry.bytes -isnot [int]) { throw 'Invalid release file metadata.' }
        if (-not $seen.Add($entry.path)) { throw 'Duplicate release member.' }
        $full = Resolve-KitMember $Directory $entry.path -MustExist
        if ((Get-Item -LiteralPath $full).Length -ne $entry.bytes -or (Get-FileHash -LiteralPath $full -Algorithm SHA512).Hash -ne $entry.sha512) { throw "Release content mismatch: $($entry.path)" }
        $entry.full_path = $full
        if (-not $roles.ContainsKey($entry.role)) { $roles[$entry.role]=@() }
        $roles[$entry.role] += ,$entry
    }
    foreach ($role in @('elasticsearch_rpm','kibana_rpm','linux_agent','windows_agent','winlogbeat_zip','elastic_signing_key','winlogbeat_template','agent_pgp_key')) {
        if ($roles.ContainsKey($role) -and @($roles[$role]).Count -ne 1) { throw "Expected at most one $role input." }
        if ($RequireFull -and -not $roles.ContainsKey($role)) { throw "Full offline release missing: $role" }
    }
    if ($RequireFull -and (-not $roles.ContainsKey('integration') -or -not @($roles.integration | Where-Object { $_.Contains('package_name') -and $_.package_name -eq 'fleet_server' }).Count)) { throw 'Full release needs a pinned Fleet Server integration ZIP.' }
    if ($RequireFull) {
        $artifacts=[Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
        foreach($entry in $manifest.files) {
            if($entry.Contains('artifact_path')) {
                $null=Resolve-KitMember $Directory $entry.artifact_path
                if($entry.role -notin @('linux_agent','windows_agent','agent_signature','agent_checksum','agent_pgp_key') -or -not $artifacts.Add($entry.artifact_path)){throw 'Invalid or duplicate public artifact mapping.'}
            }
        }
        foreach($role in @('linux_agent','windows_agent')) {
            $agent=$roles[$role][0]
            if(-not $agent.Contains('package_version') -or $agent.package_version -notmatch ('^'+[regex]::Escape($manifest.version)+'(?:\+build[0-9]+)?$')){throw 'Agent build version must be pinned to this Stack release.'}
            if(-not $agent.Contains('artifact_path')){throw 'Agent download path is absent.'}
            foreach($suffix in @('.asc','.sha512')){if(-not $artifacts.Contains($agent.artifact_path+$suffix)){throw "Missing Agent verification companion: $role$suffix"}}
        }
        if(-not $roles.agent_pgp_key[0].Contains('artifact_path')){throw 'Agent public signing key download path is absent.'}
        foreach($name in @('fleet_server','elastic_agent')) {
            if(@($roles.integration | Where-Object {$_.Contains('package_name') -and $_.package_name -eq $name}).Count -ne 1){throw "Full release needs one pinned $name integration archive."}
        }
        if(-not $roles.ContainsKey('winlogbeat_pipeline') -or @($roles.winlogbeat_pipeline | Where-Object {$_.Contains('pipeline_id') -and $_.pipeline_id -eq ('winlogbeat-'+$manifest.version+'-routing')}).Count -ne 1){throw 'Vendor Winlogbeat routing pipeline is absent or duplicated.'}
    }
    return [pscustomobject]@{ Manifest=$manifest; Roles=$roles; Directory=[IO.Path]::GetFullPath($Directory); SHA256=$ExpectedManifestSHA256.ToLowerInvariant() }
}

function Write-KitPrivateFile {
    param([Parameter(Mandatory)][string]$Path, [Parameter(Mandatory)][AllowEmptyString()][string]$Text,
          [string]$Mode='0600', [switch]$CreateNew)
    Assert-KitRoot
    if (Test-Path -LiteralPath $Path) {
        if ($CreateNew) { throw "Existing file preserved: $Path" }
        if ((Get-Item -Force -LiteralPath $Path).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Refusing symbolic link destination.' }
    }
    $parent = Split-Path -Parent $Path
    if (-not (Test-Path -LiteralPath $parent -PathType Container)) { $null=Invoke-KitNative install @('-d','-m','0700','--',$parent) }
    $walk=[IO.Path]::GetFullPath($parent)
    while($walk) {
        if((Get-Item -Force -LiteralPath $walk).Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Private file parent cannot contain a symbolic link.'}
        $meta=(Invoke-KitNative stat @('-c','%u %a','--',$walk)).Stdout.Trim().Split(' ')
        if($meta[0] -ne '0' -or ([Convert]::ToInt32($meta[1],8) -band 18)){throw 'Private file parent must belong to root and forbid group/other writes.'}
        $walk=Split-Path -Parent $walk
    }
    $temporary=Join-Path $parent ('.kit-'+[Guid]::NewGuid().ToString('N'))
    $null=Invoke-KitNative install @('-m',$Mode,'/dev/null',$temporary)
    try {
        [IO.File]::WriteAllText($temporary,$Text,[Text.UTF8Encoding]::new($false))
        [IO.File]::Move($temporary,$Path,(-not [bool]$CreateNew))
    } finally { if (Test-Path -LiteralPath $temporary) { [IO.File]::Delete($temporary) } }
}

function New-KitSecret {
    $bytes=[byte[]]::new(48)
    [Security.Cryptography.RandomNumberGenerator]::Fill($bytes)
    return [Convert]::ToBase64String($bytes)
}

function Invoke-KitApi {
    param([Parameter(Mandatory)][System.Collections.IDictionary]$Profile,
          [ValidateSet('es','kibana')][string]$Service='es',
          [ValidateSet('GET','POST','PUT','DELETE')][string]$Method='GET',
          [Parameter(Mandatory)][string]$Path, [AllowNull()]$Body,
          [string]$BodyFile, [string]$ContentType='application/json',
          [string]$AuthFile='/etc/elastic-kit/secrets/admin.curl',
          [string]$CAFile='/etc/elastic-kit/pki/http-ca/ca.crt', [switch]$AllowFailure)
    Assert-KitRoot
    if ($Path -notmatch '^/[A-Za-z0-9_*/?.=,&%:+-]*$' -or $Path.Contains('..') -or $Path.StartsWith('//')) { throw 'Unsafe API path.' }
    $url=if($Service -eq 'es'){$Profile.elasticsearch_url}else{$Profile.kibana_url}
    $dir='/var/lib/elastic-kit/api'
    $null=Invoke-KitNative install @('-d','-m','0700',$dir)
    $stem=Join-Path $dir ([Guid]::NewGuid().ToString('N'))
    $response=$stem+'.response';$request=$stem+'.request'
    $null=Invoke-KitNative install @('-m','0600','/dev/null',$response)
    try {
        $arguments=@('--config',$AuthFile,'--cacert',$CAFile,'--silent','--show-error','--noproxy','*','--connect-timeout','10','--max-time','300','--request',$Method,'--output',$response,'--write-out','%{http_code}','--header','kbn-xsrf: elastic-kit','--header',"Content-Type: $ContentType")
        if ($null -ne $Body) {
            Write-KitPrivateFile $request ($Body | ConvertTo-Json -Depth 50 -Compress) -CreateNew
            $arguments+=@('--data-binary',('@'+$request))
        } elseif ($BodyFile) { $arguments+=@('--data-binary',('@'+$BodyFile)) }
        $arguments+=($url.TrimEnd('/')+$Path)
        $result=Invoke-KitNative curl $arguments -AllowFailure -Sensitive -TimeoutSeconds 320
        $status=0;$null=[int]::TryParse($result.Stdout.Trim(),[ref]$status)
        if ($result.ExitCode -ne 0 -or $status -lt 200 -or $status -ge 300) {
            if ($AllowFailure) { return [pscustomobject]@{ Success=$false;Status=$status;Data=$null } }
            # Keep diagnosis on the root-only VM; API errors can contain sensitive
            # request details and must never be echoed into a shared transcript.
            Write-KitPrivateFile "$dir/last-error.json" (@{service=$Service;method=$Method;path=$Path;status=$status;curl_exit=$result.ExitCode;response=[IO.File]::ReadAllText($response);stderr=$result.Stderr}|ConvertTo-Json -Depth 10)
            throw "Verified-TLS $Service API failed ($Method $Path, HTTP $status, curl $($result.ExitCode)); protected diagnostic: $dir/last-error.json."
        }
        $data=$null;$raw=[IO.File]::ReadAllText($response)
        if ($raw.Trim()) { $data=$raw | ConvertFrom-Json -AsHashtable }
        return [pscustomobject]@{ Success=$true;Status=$status;Data=$data }
    } finally {
        foreach ($file in @($response,$request)) { if (Test-Path -LiteralPath $file) { [IO.File]::Delete($file) } }
    }
}

function Wait-KitApi {
    param([Parameter(Mandatory)]$Profile,[ValidateSet('es','kibana')][string]$Service,[int]$Seconds=300)
    $stop=[DateTime]::UtcNow.AddSeconds($Seconds)
    do {
        $path=if($Service -eq 'es'){'/'}else{'/api/status'}
        $response=Invoke-KitApi -Profile $Profile -Service $Service -Path $path -AllowFailure
        if ($response.Success -and ($Service -eq 'es' -or $response.Data.status.overall.level -eq 'available')) { return $response.Data }
        Start-Sleep -Seconds 3
    } while ([DateTime]::UtcNow -lt $stop)
    throw "$Service did not pass authenticated HTTPS readiness within $Seconds seconds."
}

Export-ModuleMember -Function Invoke-KitNative,Assert-KitRoot,Resolve-KitMember,Read-KitRelease,Write-KitPrivateFile,New-KitSecret,Invoke-KitApi,Wait-KitApi
