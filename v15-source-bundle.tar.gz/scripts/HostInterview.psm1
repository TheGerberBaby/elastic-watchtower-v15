Set-StrictMode -Version Latest
function Read-CheckedAnswer([string]$Prompt,[string]$Default,[scriptblock]$Check,[string]$Hint){
    while($true){
        $answer=(Read-Host $(if($Default){"$Prompt [$Default]"}else{$Prompt})).Trim()
        if(-not $answer){$answer=$Default}
        if(& $Check $answer){return $answer}
        Write-Host $Hint -ForegroundColor Yellow
    }
}
function Test-InterviewIPv4([string]$Value){
    if($Value -notmatch '^\d{1,3}(\.\d{1,3}){3}$'){return $false}
    foreach($p in $Value.Split('.')){if([int]$p -gt 255 -or ($p.Length -gt 1 -and $p.StartsWith('0'))){return $false}}
    $first=[int]$Value.Split('.')[0]
    return $first -gt 0 -and $first -lt 224 -and $first -ne 127
}
function Test-InterviewName([string]$Value){
    if(-not $Value -or $Value.Length -gt 253){return $false}
    foreach($part in $Value.Split('.')){if($part -notmatch '^[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?$'){return $false}}
    return $true
}
function Test-SameIPv4Subnet([string]$Left,[string]$Right,[int]$Prefix){
    $a=[Net.IPAddress]::Parse($Left).GetAddressBytes();$b=[Net.IPAddress]::Parse($Right).GetAddressBytes()
    for($i=0;$i -lt 4;$i++){
        $bits=[Math]::Min(8,[Math]::Max(0,$Prefix-8*$i))
        $mask=if($bits){(255 -shl (8-$bits)) -band 255}else{0}
        if(($a[$i] -band $mask) -ne ($b[$i] -band $mask)){return $false}
    }
    return $true
}
function Read-FriendlyHostSettings([switch]$LineMode) {
    if($LineMode){return (Read-LineHostSettings)}
    $adapters=@(& nmcli -t -f UUID,DEVICE connection show --active | ForEach-Object {
        $parts=$_.Split(':')
        if($parts.Count -eq 2 -and $parts[1] -and $parts[1] -ne 'lo'){@{uuid=$parts[0];device=$parts[1]}}
    })
    if($LASTEXITCODE -ne 0 -or -not $adapters.Count){throw 'No active network adapter found. Connect the VM network adapter and retry.'}
    Import-Module (Join-Path $PSScriptRoot 'HostSetupForm.psm1') -Force
    return (Read-TabbedHostSettings -Adapters $adapters)
}
function Read-LineHostSettings {
    $adapters=@(& nmcli -t -f UUID,DEVICE connection show --active | ForEach-Object {
        $parts=$_.Split(':')
        if($parts.Count -eq 2 -and $parts[1] -and $parts[1] -ne 'lo'){@{uuid=$parts[0];device=$parts[1]}}
    })
    if($LASTEXITCODE -ne 0 -or -not $adapters.Count){throw 'No active network adapter found. Connect the VM network adapter and retry.'}
    if($adapters.Count -eq 1){$adapter=$adapters[0];Write-Host "Using network adapter $($adapter.device)."}
    else{
        for($i=0;$i -lt $adapters.Count;$i++){Write-Host "$($i+1). $($adapters[$i].device)"}
        do{
            $choice=(Read-Host 'Choose an adapter number or name').Trim();$adapter=$null
            for($i=0;$i -lt $adapters.Count;$i++){if($choice -in @([string]($i+1),$adapters[$i].device,$adapters[$i].uuid)){$adapter=$adapters[$i];break}}
            if(-not $adapter){Write-Host 'Choose one of the listed adapters.'}
        }until($adapter)
    }
    $current=@(& nmcli -g IP4.ADDRESS device show $adapter.device | Where-Object {$_ -match '^\d+\.\d+\.\d+\.\d+/\d+$'})
    $currentCidr=if($current.Count){$current[0]}else{''}
    $defaultIp=if($currentCidr){$currentCidr.Split('/')[0]}else{''}
    $defaultPrefix=if($currentCidr){$currentCidr.Split('/')[1]}else{'24'}
    Write-Host "Current network address: $currentCidr"
    Write-Host 'Host-only, NAT and bridged VMware networks can use different IP ranges. Match the range of the selected virtual network.'
    while($true){
        $ip=Read-CheckedAnswer 'IP address assigned to this VM (required)' '' {param($v) Test-InterviewIPv4 $v} 'Enter the address assigned to this VM on your actual LAN.'
        $prefix=Read-CheckedAnswer 'Subnet prefix: 24 means 255.255.255.0' $defaultPrefix {param($v) $v -match '^([1-9]|[12][0-9]|30)$'} 'Enter a prefix from 1 through 30.'
        if($currentCidr -and -not(Test-SameIPv4Subnet $ip $defaultIp ([int]$defaultPrefix))){
            Write-Host "You chose $ip but this adapter is currently on $currentCidr. Changing the IP does not change VMware's virtual network." -ForegroundColor Yellow
            if((Read-Host 'Type DIFFERENT NETWORK only if you have connected this VM to the intended network; Enter retries the IP') -cne 'DIFFERENT NETWORK'){continue}
        }
        break
    }
    $gatewayDefault=(@(& nmcli -g IP4.GATEWAY device show $adapter.device | Where-Object {$_}) -join '')
    if($gatewayDefault -and -not(Test-SameIPv4Subnet $ip $gatewayDefault ([int]$prefix))){$gatewayDefault=''}
    $gateway=Read-CheckedAnswer 'Gateway; enter none for an isolated network' $gatewayDefault {param($v) (-not $v) -or $v -eq 'none' -or ((Test-InterviewIPv4 $v) -and (Test-SameIPv4Subnet $ip $v ([int]$prefix)))} 'Use a gateway in the selected subnet, or enter none.'
    if($gateway -eq 'none'){$gateway=''}
    $dnsDefault=(@(& nmcli -g IP4.DNS device show $adapter.device | Where-Object {$_}) -join ',')
    $dns=Read-CheckedAnswer 'DNS server IPs, separated by commas' $dnsDefault {param($v) $list=@($v.Split(',') | ForEach-Object {$_.Trim()});$list.Count -ge 1 -and $list.Count -le 3 -and @($list | Where-Object {-not(Test-InterviewIPv4 $_)}).Count -eq 0} 'Enter one to three DNS IP addresses, separated by commas.'
    $domain=Read-CheckedAnswer 'AD domain, such as company.internal; blank skips AD' '' {param($v) -not $v -or ($v.Contains('.') -and (Test-InterviewName $v))} 'Enter the AD DNS domain, or leave blank.'
    $name=Read-CheckedAnswer 'Computer name: short names such as elk-rhel-dev are OK' 'elastic01' {param($v) Test-InterviewName $v} 'Use letters, digits and hyphens, without spaces.'
    if(-not $name.Contains('.')){
        $suffix=if($domain){$domain}else{Read-CheckedAnswer 'DNS suffix; home.arpa is a home-lab default' 'home.arpa' {param($v) $v.Contains('.') -and (Test-InterviewName $v)} 'Enter a DNS domain such as home.arpa or company.internal.'}
        $name="$name.$suffix"
    }
    Write-Host "Full hostname: $name. Clients must resolve this name to $ip before using Kibana."
    $user=Read-CheckedAnswer 'New local administrator username; blank keeps existing accounts' '' {param($v) -not $v -or ($v -ne 'root' -and $v -match '^[a-z_][a-z0-9_-]{0,30}$')} 'Use a lowercase account name such as jeremy; do not enter root.'
    $share=Read-CheckedAnswer 'Optional share, such as \\fileserver\software; blank skips' '' {param($v) -not $v -or $v -match '^\\\\[A-Za-z0-9][A-Za-z0-9.-]*\\[A-Za-z0-9_$.-]+$'} 'Use \\server\share, or leave blank.'
    $mount='/mnt/elastic-kit-share'
    if($share){$mount=Read-CheckedAnswer 'Mount directory' $mount {param($v) $v -match '^/mnt/[A-Za-z0-9_-]+$'} 'Use a directory under /mnt, such as /mnt/elastic-kit-share.'}
    return @{schema_version=1;connection_uuid=$adapter.uuid;hostname=$name.ToLowerInvariant();ipv4_address=$ip;ipv4_prefix=[int]$prefix;ipv4_gateway=$gateway;dns_servers=@($dns.Split(',')|ForEach-Object {$_.Trim()});ad_domain=$domain.ToLowerInvariant();local_user=$user;share_unc=$share;mount_point=$mount}
}
Export-ModuleMember -Function Read-FriendlyHostSettings,Read-CheckedAnswer,Test-SameIPv4Subnet,Test-InterviewIPv4,Test-InterviewName
