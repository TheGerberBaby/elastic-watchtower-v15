#requires -Version 7.2
[CmdletBinding()]
param(
    [Parameter(Mandatory)][string]$SiteProfile,
    [Parameter(Mandatory)][string]$VendorZip,
    [Parameter(Mandatory)][ValidatePattern('^[a-fA-F0-9]{128}$')][string]$ExpectedSHA512,
    [Parameter(Mandatory)][string]$CaCertificate,
    [Parameter(Mandatory)][string]$OutputZip,
    [string]$OutputDirectory
)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
Import-Module (Join-Path $PSScriptRoot 'SiteProfile.psm1') -Force
$profile = Get-Content -Raw -LiteralPath $SiteProfile | ConvertFrom-Json -AsHashtable
$null = Test-SiteProfile $profile
$zipPath = (Resolve-Path -LiteralPath $VendorZip).Path
$caPath = (Resolve-Path -LiteralPath $CaCertificate).Path
$outputPath = [IO.Path]::GetFullPath($OutputZip)
if (Test-Path -LiteralPath $outputPath) { throw 'Output already exists; it will not be overwritten.' }
if (-not $OutputDirectory) { $OutputDirectory = Join-Path ([IO.Path]::GetDirectoryName($outputPath)) ([IO.Path]::GetFileNameWithoutExtension($outputPath)) }
$folderPath = [IO.Path]::GetFullPath($OutputDirectory).TrimEnd([IO.Path]::DirectorySeparatorChar,[IO.Path]::AltDirectorySeparatorChar)
if (Test-Path -LiteralPath $folderPath) { throw 'Winlogbeat output folder already exists; it will not be overwritten.' }
if (-not (Test-Path -LiteralPath ([IO.Path]::GetDirectoryName($folderPath)) -PathType Container)) { throw 'Create the Winlogbeat output parent directory first.' }
if ($folderPath.Equals($outputPath,[StringComparison]::OrdinalIgnoreCase) -or $outputPath.StartsWith($folderPath+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)) { throw 'The archive must be outside the Winlogbeat output folder.' }
if ((Get-FileHash -LiteralPath $zipPath -Algorithm SHA512).Hash -ne $ExpectedSHA512) { throw 'Vendor ZIP hash mismatch. Obtain the expected hash from an authenticated approved release manifest.' }
$pem = [IO.File]::ReadAllText($caPath)
if ($pem -match 'PRIVATE KEY' -or $pem -notmatch '-----BEGIN CERTIFICATE-----') { throw 'Supply a public PEM CA certificate, never a private key.' }
$ca = [Security.Cryptography.X509Certificates.X509Certificate2]::CreateFromPem($pem)
try {
    $constraints = @($ca.Extensions | Where-Object { $_.Oid.Value -eq '2.5.29.19' })
    if ($constraints.Count -ne 1 -or -not $constraints[0].CertificateAuthority) { throw 'The supplied certificate must be a CA.' }
    if ($ca.NotAfter.ToUniversalTime() -le [DateTime]::UtcNow -or $ca.NotBefore.ToUniversalTime() -gt [DateTime]::UtcNow) { throw 'CA certificate is outside its validity period.' }
} finally { $ca.Dispose() }

$parent = [IO.Path]::GetDirectoryName($outputPath)
if (-not (Test-Path -LiteralPath $parent -PathType Container)) { throw 'Create the output directory first.' }
$scratch = Join-Path $parent ('.winlogbeat-build-' + [Guid]::NewGuid().ToString('N'))
$null = New-Item -ItemType Directory -Path $scratch
try {
    $archive = [IO.Compression.ZipFile]::OpenRead($zipPath)
    try {
        $size = [long]0
        $seen = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
        $roots = [Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
        foreach ($entry in $archive.Entries) {
            $name = $entry.FullName.Replace('\','/')
            if ($name.StartsWith('/') -or $name.Contains(':') -or $name -match '[\x00-\x1f]' -or $name.Split('/') -contains '..' -or $name.Split('/') -contains '.') { throw 'Unsafe ZIP entry path.' }
            if (-not $seen.Add($name)) { throw 'Duplicate ZIP entry path.' }
            if ((($entry.ExternalAttributes -shr 16) -band 0xF000) -eq 0xA000) { throw 'Symbolic links are not accepted in the Windows vendor ZIP.' }
            $rootName = $name.Split('/')[0]
            if ($rootName -ne 'winlogbeat-9.5.4-windows-x86_64') { throw 'This installer currently targets the inspected Winlogbeat 9.5.4 Windows x86_64 payload only.' }
            $null = $roots.Add($rootName)
            $size += $entry.Length
            if ($size -gt 2GB -or $archive.Entries.Count -gt 10000) { throw 'Archive exceeds the accepted bundle size.' }
        }
        if ($roots.Count -ne 1) { throw 'Expected one Winlogbeat version directory.' }
    } finally { $archive.Dispose() }
    [IO.Compression.ZipFile]::ExtractToDirectory($zipPath,$scratch)
    $payload = Join-Path $scratch (@($roots)[0])
    foreach ($name in @('winlogbeat.exe','install-service-winlogbeat.ps1')) {
        if (-not (Test-Path -LiteralPath (Join-Path $payload $name) -PathType Leaf)) { throw "Missing official vendor payload: $name" }
    }
    # Generated configuration contains endpoints and keystore references, no passwords/API keys.
    [IO.File]::WriteAllText((Join-Path $payload 'winlogbeat.yml'),(New-WinlogbeatConfig $profile),[Text.UTF8Encoding]::new($false))
    $null = New-Item -ItemType Directory -Force -Path (Join-Path $payload 'certs')
    Copy-Item -LiteralPath $caPath -Destination (Join-Path $payload 'certs/ca.crt')
    Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'Install-Winlogbeat.ps1') -Destination (Join-Path $payload 'Install-Winlogbeat.ps1')
    $instructions = @'
Offline Winlogbeat bundle - new Windows endpoints only

This archive contains the approved vendor payload, public CA and site config.
It contains no publishing API key, private TLS key, or enrolled machine state.
The input ZIP hash must have been approved through an authenticated release process.

1. Before deployment, test this exact Winlogbeat version with the destination stack
   and Windows versions. Complete index/template/pipeline/dashboard setup using a
   separately approved setup identity. Publishing credentials are not setup credentials.
2. Verify the delivered archive's SHA-256 against the protected release record.
3. Stage the complete versioned folder locally on the target under a protected
   directory such as C:\ProgramData\ElasticDeploy\payload. Do not overwrite an
   existing Winlogbeat installation. Only SYSTEM and Administrators may write it.
4. Stage this endpoint's least-privilege id:api_key in a separate local file whose
   ACL allows only SYSTEM and Administrators. Do not place keys in the shared
   payload or pass passwords/API keys as command-line arguments.
5. Use the approved, licensed PsExec from a domain administration workstation:
   PsExec.exe \\TARGET -s powershell.exe -NoLogo -NoProfile -NonInteractive -File C:\ProgramData\ElasticDeploy\payload\Install-Winlogbeat.ps1 -ApiKeyFile C:\ProgramData\ElasticDeploy\secrets\publisher.key -ExpectedManifestSHA256 HASH_FROM_PROTECTED_RELEASE_RECORD
   Use an already authorized administrative session. Sign the script through your
   organization's code-signing process if required; no execution-policy bypass is
   supplied. PsExec is not bundled. Its licensing and endpoint policy still apply.
6. The installer requires LocalSystem, refuses existing service/data, checks payload
   hashes, protects installation/data ACLs, creates the keystore via stdin, tests
   config/output with certificate verification, installs the service and starts it.
   Nonzero exit means failure. Do not automatically delete preserved data on retry.
7. Verify this endpoint's events in Kibana; then remove the separately staged secret
   using the approved process. Run first on one explicitly selected test endpoint.

This generated bundle is not an accepted release until the above checks are tested.
Existing endpoint upgrades must preserve registry/bookmarks, keystore and service
paths using a version-specific, tested upgrade procedure.
'@
    [IO.File]::WriteAllText((Join-Path $payload 'SITE-README.txt'),$instructions,[Text.UTF8Encoding]::new($false))
    $record = [ordered]@{
        schema_version=1; site=$profile.site_name; payload_directory=(@($roots)[0])
        vendor_zip_sha512=$ExpectedSHA512.ToLowerInvariant()
        public_ca_sha256=(Get-FileHash -LiteralPath $caPath -Algorithm SHA256).Hash.ToLowerInvariant()
        generated_utc=[DateTime]::UtcNow.ToString('o'); tested_release=$false
    }
    if ($profile.schema_version -in @(2,3,4)) {
        $record.topology = $profile.topology
        $record.windows_endpoint_count = $profile.windows_endpoint_count
        $record.requested_retention_days = $profile.retention_days
        $record.retention_policy_applied = $false
        $record.share_destination = $profile.share_unc + '\' + $profile.winlogbeat_relative_path.Replace('/','\')
    }
    if ($profile.schema_version -in @(3,4)) { $record.tls_mode = $profile.tls_mode }
    [IO.File]::WriteAllText((Join-Path $payload 'bundle-record.json'),($record | ConvertTo-Json),[Text.UTF8Encoding]::new($false))
    $files = @(Get-ChildItem -LiteralPath $payload -File -Recurse -Force | Sort-Object FullName | ForEach-Object {
        [ordered]@{path=$_.FullName.Substring($payload.Length+1).Replace('\','/'); sha256=(Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash.ToLowerInvariant()}
    })
    $manifestPath=Join-Path $payload 'payload-manifest.json'
    [IO.File]::WriteAllText($manifestPath,([ordered]@{schema_version=1;version='9.5.4';files=$files}|ConvertTo-Json -Depth 5),[Text.UTF8Encoding]::new($false))
    $manifestHash=(Get-FileHash -LiteralPath $manifestPath -Algorithm SHA256).Hash.ToLowerInvariant()
    [IO.Compression.ZipFile]::CreateFromDirectory($scratch,$outputPath,[IO.Compression.CompressionLevel]::Optimal,$false)
    $hash=(Get-FileHash -LiteralPath $outputPath -Algorithm SHA256).Hash.ToLowerInvariant()
    # CreateNew-style directory creation preserves an existing delivery. On a copy
    # failure, retain the partial folder for inspection; never claim it is ready.
    $null = New-Item -ItemType Directory -Path $folderPath -ErrorAction Stop
    foreach ($item in Get-ChildItem -LiteralPath $payload -Force) {
        Copy-Item -LiteralPath $item.FullName -Destination $folderPath -Recurse -ErrorAction Stop
    }
    foreach ($file in $files) {
        if ((Get-FileHash -LiteralPath (Join-Path $folderPath $file.path) -Algorithm SHA256).Hash.ToLowerInvariant() -ne $file.sha256) { throw 'Copied Winlogbeat folder failed verification. Preserve it for inspection; do not deploy it.' }
    }
    if ((Get-FileHash -LiteralPath (Join-Path $folderPath 'payload-manifest.json') -Algorithm SHA256).Hash.ToLowerInvariant() -ne $manifestHash) { throw 'Copied manifest failed verification. Do not deploy the folder.' }
    Write-Output "Created: $outputPath"
    Write-Output "Winlogbeat folder: $folderPath"
    Write-Output "SHA256: $hash"
    Write-Output "ExpectedManifestSHA256: $manifestHash"
    Write-Output 'Packaging only. Vendor execution, Windows service paths and delivery have not been tested by this command.'
} finally {
    # Remove only the newly created, resolved scratch directory under the output parent.
    $resolvedScratch=[IO.Path]::GetFullPath($scratch)
    if ([IO.Path]::GetDirectoryName($resolvedScratch) -eq $parent -and [IO.Path]::GetFileName($resolvedScratch).StartsWith('.winlogbeat-build-')) {
        Remove-Item -LiteralPath $resolvedScratch -Recurse -Force
    }
}
