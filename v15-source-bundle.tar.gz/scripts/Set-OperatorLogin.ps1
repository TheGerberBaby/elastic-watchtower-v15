#requires -Version 7.2
[CmdletBinding()]
param([string]$SiteProfile='/etc/elastic-kit/site/site.json')
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
Import-Module (Join-Path $PSScriptRoot 'Kit.Common.psm1') -Force
Assert-KitRoot
$marker='/etc/elastic-kit/site/operator-login.json'
if(Test-Path $marker){Write-Host ('Kibana operator: '+(Get-Content -Raw $marker|ConvertFrom-Json).username);return}
$profile=Get-Content -Raw $SiteProfile|ConvertFrom-Json -AsHashtable
$username=(Read-Host 'Choose your Kibana administrator username (not elastic)').Trim()
if($username -notmatch '^[a-zA-Z][a-zA-Z0-9_.-]{2,63}$' -or $username -eq 'elastic'){throw 'Use 3-64 characters and a separate administrator name.'}
$existing=Invoke-KitApi $profile -Path "/_security/user/$username" -AllowFailure
if($existing.Success -and $existing.Data.Contains($username)){throw 'Existing administrator preserved; choose a new name.'}
if(-not $existing.Success -and $existing.Status -ne 404){throw 'Could not check existing users.'}
$secure=Read-Host 'Kibana password' -AsSecureString
$confirm=Read-Host 'Repeat password' -AsSecureString
try {
    $password=[Net.NetworkCredential]::new('', $secure).Password
    $repeat=[Net.NetworkCredential]::new('', $confirm).Password
    if($password -cne $repeat -or $password.Length -lt 15){throw 'Passwords must match and contain at least 15 characters.'}
    $null=Invoke-KitApi $profile -Method PUT -Path "/_security/user/$username" -Body @{password=$password;roles=@('superuser');full_name='Appliance operator';enabled=$true}
    Write-KitPrivateFile $marker (@{username=$username;created_utc=[datetime]::UtcNow.ToString('o')}|ConvertTo-Json) -CreateNew
    Write-Host "Kibana administrator created: $username"
} finally {$password=$null;$repeat=$null;$secure.Dispose();$confirm.Dispose()}
