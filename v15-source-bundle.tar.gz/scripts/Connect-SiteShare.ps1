#requires -Version 7.2
[CmdletBinding()]
param([Parameter(Mandatory)][string]$SiteProfile,
      [string]$MountPoint='/mnt/elastic-kit-share',
      [ValidateSet('read','write')][string]$Access='read',
      [PSCredential]$Credential,
      [string]$CredentialDomain)
$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
Import-Module (Join-Path $PSScriptRoot 'SiteProfile.psm1') -Force
Import-Module (Join-Path $PSScriptRoot 'Kit.Common.psm1') -Force
$profile=Get-Content -Raw -LiteralPath $SiteProfile | ConvertFrom-Json -AsHashtable
$null=Test-SiteProfile $profile
Assert-KitRoot
if((Get-Content -Raw /proc/sys/crypto/fips_enabled).Trim() -eq '1'){
    throw 'FIPS mode cannot use this NTLM SMB login. Use a Windows transfer workstation, or an approved existing Kerberos SMB mount. FIPS is not disabled by this kit.'
}
if ($MountPoint -notmatch '^/mnt/[A-Za-z0-9_-]+$') { throw 'Use a dedicated directory directly below /mnt.' }
if ((Invoke-KitNative mountpoint @('-q',$MountPoint) -AllowFailure).ExitCode -eq 0) { throw 'Existing mount preserved. Inspect and unmount it before changing identity or access.' }
$null=Invoke-KitNative install @('-d','-m','0700',$MountPoint)
if (@(Get-ChildItem -Force -LiteralPath $MountPoint).Count) { throw 'Mount point is not empty.' }
if($Credential){
    $username=$Credential.UserName.Trim()
    $domain=$CredentialDomain.Trim()
    $secure=$Credential.Password.Copy()
}else{
    $username=(Read-Host 'SMB account name (without domain)').Trim()
    $domain=(Read-Host 'SMB domain / server account authority').Trim()
    $secure=Read-Host 'SMB password (hidden; not stored in the site profile)' -AsSecureString
}
foreach ($value in @($username,$domain)) { if (-not $value -or $value -match '[\r\n\x00=]') { throw 'Invalid SMB account/domain.' } }
$pointer=[Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
$credentials='/run/elastic-kit-smb-'+[Guid]::NewGuid().ToString('N')
try {
    $plain=[Runtime.InteropServices.Marshal]::PtrToStringBSTR($pointer)
    if ($plain -match '[\r\n\x00]') { throw 'The credential-file format cannot represent this password.' }
    Write-KitPrivateFile $credentials "username=$username`npassword=$plain`ndomain=$domain`n" -CreateNew
    $mode=if($Access -eq 'write'){'rw'}else{'ro'}
    $options="credentials=$credentials,vers=3.1.1,sec=ntlmssp,seal,$mode,nosuid,nodev,noexec,uid=0,gid=0,file_mode=0600,dir_mode=0700"
    $source=$profile.share_unc.Replace('\','/')
    $null=Invoke-KitNative mount @('-t','cifs',$source,$MountPoint,'-o',$options) -Sensitive
    Write-Output $MountPoint
} finally {
    $plain=$null
    [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($pointer)
    $secure.Dispose()
    if (Test-Path -LiteralPath $credentials) { [IO.File]::Delete($credentials) }
}
# This temporary staging mount is not put in fstab. Kerberos-only sites must use
# their approved sec=krb5i mount and point the installer at that existing mount.
