#requires -Version 7.2
[CmdletBinding()]
param([Parameter(Mandatory)][string]$SiteProfile,
      [string]$PrivateDirectory='/etc/elastic-kit/csr',
      [string]$PublicDirectory='/srv/elastic-output/certificate-requests')
$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
Import-Module (Join-Path $PSScriptRoot 'SiteProfile.psm1') -Force
Import-Module (Join-Path $PSScriptRoot 'Kit.Common.psm1') -Force
$profile=Get-Content -Raw -LiteralPath $SiteProfile | ConvertFrom-Json -AsHashtable
$null=Test-SiteProfile $profile
if ($profile.mode -ne 'fresh' -or $profile.tls_mode -ne 'csr') { throw 'The site must explicitly select CSR signing by its existing CA.' }
Assert-KitRoot
foreach ($dir in @($PrivateDirectory,$PublicDirectory)) {
    if (Test-Path -LiteralPath $dir) { throw "Existing request material preserved: $dir" }
}
$null=Invoke-KitNative install @('-d','-m','0700',$PrivateDirectory)
$null=Invoke-KitNative install @('-d','-m','0750',$PublicDirectory)
foreach ($service in @('elasticsearch-http','elasticsearch-transport','kibana','fleet-server','artifacts')) {
    $dir=Join-Path $PrivateDirectory $service
    $null=Invoke-KitNative install @('-d','-m','0700',$dir)
    $eku=if($service -eq 'elasticsearch-transport'){'serverAuth,clientAuth'}else{'serverAuth'}
    $null=Invoke-KitNative openssl @('req','-new','-newkey','rsa:3072','-nodes','-sha256',
        '-keyout',"$dir/$service.key",'-out',"$dir/$service.csr",'-subj',"/CN=$($profile.hostname)",
        '-addext',"subjectAltName=DNS:$($profile.hostname),IP:$($profile.ipv4_address)",'-addext',"extendedKeyUsage=$eku") -Sensitive
    $null=Invoke-KitNative chmod @('0600',"$dir/$service.key", "$dir/$service.csr")
    $null=Invoke-KitNative openssl @('req','-in',"$dir/$service.csr",'-verify','-noout')
    $null=Invoke-KitNative install @('-m','0640',"$dir/$service.csr","$PublicDirectory/$service.csr")
}
Write-KitPrivateFile "$PublicDirectory/README.txt" @"
Send only this public request folder to the CA administrator.
Issue certificates for $($profile.hostname), IP $($profile.ipv4_address).
Keep private keys on the kit in $PrivateDirectory.
Transport needs both serverAuth and clientAuth. Other services need serverAuth.
Return each certificate as SERVICE/SERVICE.crt plus transport-ca/ca.crt.
Supply complete public CA chain files. Preserve the keys until import succeeds.
Run Import-SiteCertificates.ps1 with -CsrKeyDirectory $PrivateDirectory.
"@ -Mode '0640' -CreateNew
Write-Output "Public CSRs ready: $PublicDirectory. Setup waits for signed certificates; no replacement CA was created."
