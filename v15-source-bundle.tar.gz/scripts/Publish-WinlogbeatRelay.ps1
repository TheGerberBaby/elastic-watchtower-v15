#requires -Version 7.2
<# Run on the approved Windows staging workstation. The RHEL kit produces this
ZIP; transfer it through the approved channel before starting. Use separately
recorded hashes from RHEL. This command never reads or publishes endpoint keys.
#>
[CmdletBinding()]
param([string]$ZipPath,[string]$ExpectedZipSHA256,[string]$ExpectedManifestSHA256,
      [string]$DestinationDirectory,[switch]$VerifyOnly)
$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
if(-not $IsWindows){throw 'Run the relay on the Windows staging workstation.'}
foreach($name in @('ZipPath','ExpectedZipSHA256','ExpectedManifestSHA256')){
    if(-not(Get-Variable $name -ValueOnly)){
        $prompt=switch($name){'ZipPath'{'Where is the RHEL-generated Winlogbeat ZIP?'};'ExpectedZipSHA256'{'What ZIP SHA-256 did RHEL report?'};default{'What payload manifest SHA-256 did RHEL report?'}}
        Set-Variable $name (Read-Host $prompt).Trim()
    }
}
if($ExpectedZipSHA256 -notmatch '^[a-fA-F0-9]{64}$' -or $ExpectedManifestSHA256 -notmatch '^[a-fA-F0-9]{64}$'){throw 'Both SHA-256 values must contain 64 hexadecimal characters.'}
if((Get-FileHash -LiteralPath $ZipPath -Algorithm SHA256).Hash -ne $ExpectedZipSHA256){throw 'ZIP hash mismatch; nothing published.'}
if(-not $VerifyOnly){
    if(-not $DestinationDirectory){$DestinationDirectory=(Read-Host 'What UNC folder should contain Winlogbeat? (example: \\fileserver\staging\site01\Winlogbeat)').Trim()}
    if($DestinationDirectory -notmatch '^\\\\[^\\]+\\[^\\]+\\.+$'){throw 'Use a dedicated UNC destination below a share, not the share root.'}
    if(Test-Path -LiteralPath $DestinationDirectory){throw 'Existing destination preserved. Choose a new versioned folder.'}
}
Add-Type -AssemblyName System.IO.Compression.FileSystem
$scratch=Join-Path ([IO.Path]::GetTempPath()) ('ElasticKitRelay-'+[Guid]::NewGuid().ToString('N'))
$null=New-Item -ItemType Directory -Path $scratch
function Safe-Member([string]$Root,[string]$Relative){
    if($Relative -ne '.build_hash.txt' -and $Relative -notmatch '^[A-Za-z0-9_-][A-Za-z0-9_./ +\-]*$'){throw 'Unsafe payload path.'}
    foreach($part in $Relative.Split('/')){
        if($part -in @('','.','..') -or $part.EndsWith('.') -or $part.EndsWith(' ') -or $part -match '^(?i:CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\.|$)'){throw 'Unsafe Windows payload member.'}
    }
    $base=[IO.Path]::GetFullPath($Root).TrimEnd('\')
    $result=[IO.Path]::GetFullPath((Join-Path $base $Relative))
    if(-not $result.StartsWith($base+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'Payload escaped its directory.'}
    $walk=$base
    foreach($part in @('')+$Relative.Split('/')){
        if($part){$walk=Join-Path $walk $part}
        if((Test-Path -LiteralPath $walk) -and ((Get-Item -LiteralPath $walk -Force).Attributes -band [IO.FileAttributes]::ReparsePoint)){throw 'Reparse points are not allowed.'}
    }
    return $result
}
try {
    $archive=[IO.Compression.ZipFile]::OpenRead((Resolve-Path -LiteralPath $ZipPath).Path)
    try{
        $seen=[Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
        $roots=[Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
        [long]$bytes=0
        foreach($entry in $archive.Entries){
            if($entry.FullName.EndsWith('/')){continue}
            $relative=$entry.FullName.Replace('\','/')
            # The vendor's one reviewed dotfile is below the ZIP's payload root.
            $parts=$relative.Split('/')
            if($parts.Count -lt 2){throw 'Expected a single payload root in the ZIP.'}
            $null=$roots.Add($parts[0])
            $root=Safe-Member $scratch $parts[0]
            $target=Safe-Member $root ($parts[1..($parts.Count-1)] -join '/')
            if(-not $seen.Add($relative)){throw 'Duplicate ZIP path.'}
            if((($entry.ExternalAttributes -shr 16) -band 0xF000) -eq 0xA000){throw 'ZIP links are not allowed.'}
            $bytes+=$entry.Length
            if($bytes -gt 1GB -or $seen.Count -gt 10000){throw 'Unexpected payload size.'}
            $null=New-Item -ItemType Directory -Path (Split-Path -Parent $target) -Force
            [IO.Compression.ZipFileExtensions]::ExtractToFile($entry,$target,$false)
        }
        if($roots.Count -ne 1){throw 'ZIP must contain one payload directory.'}
    }finally{$archive.Dispose()}
    $payload=Join-Path $scratch (@($roots)[0])
    $manifestPath=Join-Path $payload 'payload-manifest.json'
    if((Get-FileHash -LiteralPath $manifestPath -Algorithm SHA256).Hash -ne $ExpectedManifestSHA256){throw 'Payload manifest hash mismatch.'}
    $manifest=Get-Content -Raw -LiteralPath $manifestPath|ConvertFrom-Json
    if($manifest.schema_version -ne 1){throw 'Unsupported payload manifest.'}
    $listed=[Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
    foreach($file in $manifest.files){
        if($file.path -eq 'payload-manifest.json' -or -not $listed.Add($file.path)){throw 'Duplicate or recursive manifest entry.'}
        $path=Safe-Member $payload $file.path
        if($file.sha256 -notmatch '^[a-fA-F0-9]{64}$' -or (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash -ne $file.sha256){throw 'Payload file hash mismatch.'}
    }
    foreach($file in Get-ChildItem -LiteralPath $payload -Recurse -File -Force){
        $relative=$file.FullName.Substring($payload.Length+1).Replace('\','/')
        if($relative -ne 'payload-manifest.json' -and -not $listed.Contains($relative)){throw 'Unlisted file in payload.'}
    }
    if($VerifyOnly){Write-Host "PASS: ZIP and all $($listed.Count) manifest members verified, including hidden files.";return}
    $destination=[IO.Path]::GetFullPath($DestinationDirectory).TrimEnd('\')
    $parent=Split-Path -Parent $destination
    $leaf=Split-Path -Leaf $destination
    $partial=Join-Path $parent ('.'+$leaf+'.partial-'+[Guid]::NewGuid().ToString('N'))
    $null=Safe-Member $parent $leaf
    $null=New-Item -ItemType Directory -Path $partial
    foreach($file in $manifest.files){
        $target=Safe-Member $partial $file.path
        $null=New-Item -ItemType Directory -Path (Split-Path -Parent $target) -Force
        Copy-Item -LiteralPath (Join-Path $payload $file.path) -Destination $target
        if((Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash -ne $file.sha256){throw "Share copy verification failed; partial folder preserved: $partial"}
    }
    Copy-Item -LiteralPath $manifestPath -Destination (Join-Path $partial 'payload-manifest.json')
    if((Get-FileHash -LiteralPath (Join-Path $partial 'payload-manifest.json') -Algorithm SHA256).Hash -ne $ExpectedManifestSHA256){throw 'Copied manifest differs; partial folder preserved.'}
    # Rename only this newly generated directory within the same share parent.
    if([IO.Path]::GetDirectoryName($partial) -ne $parent -or [IO.Path]::GetDirectoryName($destination) -ne $parent){throw 'Publication escaped the reviewed share parent.'}
    if(Test-Path -LiteralPath $destination){throw 'Destination appeared during copying; preserved.'}
    Rename-Item -LiteralPath $partial -NewName $leaf
    Write-Host "Published verified Winlogbeat folder: $destination"
    Write-Host "ExpectedManifestSHA256: $ExpectedManifestSHA256"
    Write-Host 'Stage each endpoint key separately, then run Install-Winlogbeat.ps1 through PsExec LocalSystem.'
}finally{
    $resolved=[IO.Path]::GetFullPath($scratch)
    $temp=[IO.Path]::GetFullPath([IO.Path]::GetTempPath()).TrimEnd('\')
    if([IO.Path]::GetDirectoryName($resolved) -eq $temp -and [IO.Path]::GetFileName($resolved).StartsWith('ElasticKitRelay-')){Remove-Item -LiteralPath $resolved -Recurse -Force}
}
