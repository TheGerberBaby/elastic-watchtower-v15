#requires -Version 7.2
<# Read-only live acceptance evidence. This command never marks production release
approval, throughput sizing, reboot, restore, or upgrade tests as passed.
#>
[CmdletBinding()]
param([Parameter(Mandatory)][string]$SiteProfile,
      [string]$ExpectedWindowsHost,
      [string]$EvidenceDirectory='/var/lib/elastic-kit/evidence')
$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
Import-Module (Join-Path $PSScriptRoot 'SiteProfile.psm1') -Force
Import-Module (Join-Path $PSScriptRoot 'Kit.Common.psm1') -Force
Assert-KitRoot
$profile=Get-Content -Raw $SiteProfile | ConvertFrom-Json -AsHashtable
$null=Test-SiteProfile $profile
$checks=[Collections.Generic.List[object]]::new()
function Check([string]$Name,[scriptblock]$Action) {
    try {$detail=& $Action;$checks.Add(@{name=$Name;passed=$true;detail=$detail})}
    catch {$checks.Add(@{name=$Name;passed=$false;detail=$_.Exception.Message})}
}
foreach($service in @('elasticsearch','kibana','elastic-agent','elastic-kit-https','elastic-epr')){
    Check "service:$service" { $null=Invoke-KitNative systemctl @('is-active','--quiet',$service);'active' }
}
Check 'Embedded v15 payload ready' {
    if(-not(Test-Path '/var/lib/elastic-kit/v15-payload-ready')){throw 'The embedded payload has not passed staging verification.'}
    if(-not(Test-Path '/home/elastic/releases/elastic-kit-9.5.4-e2e/release-manifest.json')){throw 'Embedded vendor release is absent.'}
    'present'
}
Check 'Local curated EPR catalog' {
    $result=(Invoke-KitNative curl @('--fail','--silent','--show-error','--noproxy','*','--max-time','30','http://127.0.0.1:8080/search?kibana.version=9.5.4')).Stdout | ConvertFrom-Json -AsHashtable
    $wanted=Get-Content -Raw /home/elastic/integration-catalog.json | ConvertFrom-Json -AsHashtable
    foreach($package in $wanted){if(-not @($result|Where-Object {$_.name -eq $package.name -and $_.version -eq $package.version}).Count){throw ('Missing pinned integration: '+$package.name)}}
    if(@($result).Count -ne @($wanted).Count){throw 'Registry contains unexpected packages.'}
    @{packages=@($result).Count;registry='loopback'}
}
Check 'Elasticsearch authenticated TLS' {
    $info=(Invoke-KitApi $profile -Path '/').Data
    if($info.version.number -ne '9.5.4'){throw 'Unexpected Elasticsearch version.'}
    @{version=$info.version.number;cluster_uuid=$info.cluster_uuid}
}
Check 'Kibana authenticated TLS' {
    $info=(Invoke-KitApi $profile -Service kibana -Path '/api/status').Data
    if($info.status.overall.level -ne 'available'){throw 'Kibana overall status is not available.'}
    'available'
}
Check 'Elasticsearch primary availability' {
    $health=(Invoke-KitApi $profile -Path '/_cluster/health').Data
    if($health.status -eq 'red' -or $health.active_primary_shards -lt 1){throw 'Primary shards are unavailable.'}
    @{status=$health.status;active_primary_shards=$health.active_primary_shards;unassigned_shards=$health.unassigned_shards}
}
Check 'Fleet Server verified TLS' {
    $data=(Invoke-KitNative curl @('--silent','--show-error','--fail','--noproxy','*','--cacert','/etc/elastic-kit/pki/http-ca/ca.crt',($profile.fleet_url+'/api/status'))).Stdout | ConvertFrom-Json -AsHashtable
    if($data.status -ne 'HEALTHY'){throw 'Fleet Server status is not HEALTHY.'}
    'HEALTHY'
}
Check 'Fleet Server enrolled and healthy' {
    $data=(Invoke-KitApi $profile -Service kibana -Path '/api/fleet/agents?perPage=100').Data
    $agents=@($data.items | Where-Object {$_.policy_id -eq 'elastic-kit-server' -and $_.status -eq 'online'})
    if($agents.Count -ne 1){throw 'Expected one online Agent assigned to the kit server policy.'}
    @{agent_id=$agents[0].id;status=$agents[0].status}
}
Check 'Artifact HTTPS' {
    $value=(Invoke-KitNative curl @('--silent','--show-error','--fail','--noproxy','*','--cacert','/etc/elastic-kit/pki/http-ca/ca.crt',"https://$($profile.hostname):8443/healthz")).Stdout.Trim()
    if($value -ne 'ready'){throw 'Artifact service health response differs.'}
    'ready'
}
Check 'Winlogbeat lifecycle' {
    $policy='kit-'+$profile.site_name.ToLowerInvariant()+'-winlogbeat'
    $data=(Invoke-KitApi $profile -Path "/_ilm/policy/$policy").Data
    if($data[$policy].policy.phases.delete.min_age -ne ([string]$profile.retention_days+'d')){throw 'Deletion policy differs from the site profile.'}
    $managed=(Invoke-KitApi $profile -Path '/winlogbeat-*/_ilm/explain').Data
    foreach($index in $managed.indices.Values){if(-not $index.managed -or $index.policy -ne $policy){throw 'A Winlogbeat index is outside the expected lifecycle policy.'}}
    @{policy=$policy;retention_days=$profile.retention_days}
}
if($ExpectedWindowsHost){
    if($ExpectedWindowsHost -notmatch '^[A-Za-z0-9][A-Za-z0-9.-]{0,252}$'){throw 'Invalid endpoint name.'}
    Check 'Recent Windows endpoint event' {
        $query=@{size=0;query=@{bool=@{filter=@(@{term=@{'host.name'=$ExpectedWindowsHost}},@{range=@{'@timestamp'=@{gte='now-15m'}}},@{term=@{'agent.type'='winlogbeat'}})}}}
        $result=(Invoke-KitApi $profile -Method POST -Path '/winlogbeat-*/_search' -Body $query).Data
        if($result.hits.total.value -lt 1){throw 'No recent Winlogbeat event arrived from the selected host.'}
        @{host=$ExpectedWindowsHost;events=$result.hits.total.value;window='15m'}
    }
}
$passed=@($checks | Where-Object {-not $_.passed}).Count -eq 0
$report=@{schema_version=1;utc=[DateTime]::UtcNow.ToString('o');site=$profile.site_name;passed=$passed;endpoint_checked=[bool]$ExpectedWindowsHost;checks=@($checks.ToArray());remaining_gates=@('reboot','offline restart','snapshot restore with feature states','exact upgrade transition','capacity','STIG/ACAS','production identity review')}
$path=Join-Path $EvidenceDirectory ('acceptance-'+[DateTime]::UtcNow.ToString('yyyyMMddTHHmmssZ')+'.json')
Write-KitPrivateFile $path ($report|ConvertTo-Json -Depth 15) -CreateNew
foreach($check in $checks){$label=if($check.passed){'PASS'}else{'FAIL'};Write-Host ($label+': '+$check.name)}
Write-Host "Evidence: $path"
if(-not $passed){throw 'Live checks failed. Inspect the saved acceptance record.'}
if(-not $ExpectedWindowsHost){Write-Host 'Server checks only. Windows endpoint delivery has not been checked.'}
