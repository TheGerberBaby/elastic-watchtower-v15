#requires -Version 7.2
<# Fresh single-VM deployment. Existing stacks must use maintenance/recovery.
All application inputs are local and hash-verified. No DNF or network downloader.
#>
[CmdletBinding()]
param([Parameter(Mandatory)][string]$SiteProfile,
      [Parameter(Mandatory)][string]$ReleaseDirectory,
      [Parameter(Mandatory)][ValidatePattern('^[a-fA-F0-9]{64}$')][string]$ExpectedManifestSHA256,
      [string]$DataDirectory='/srv/elastic-data',
      [string]$CertificateDirectory, [string]$HttpCA, [string]$CsrKeyDirectory,
      [ValidateRange(512,16384)][int]$HeapMB=2048,
      [ValidateRange(1024,8192)][int]$KibanaHeapMB=1024,
      [string[]]$AllowedClientCIDRs,
      [Parameter(Mandatory)][ValidatePattern('^[a-zA-Z0-9_-]+$')][string]$FirewallZone,
      [switch]$Lab)
$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
Import-Module (Join-Path $PSScriptRoot 'SiteProfile.psm1') -Force
Import-Module (Join-Path $PSScriptRoot 'Kit.Common.psm1') -Force
$profile=Get-Content -Raw -LiteralPath $SiteProfile | ConvertFrom-Json -AsHashtable
$null=Test-SiteProfile $profile
if ($profile.schema_version -ne 4 -or $profile.mode -ne 'fresh') { throw 'Fresh installer requires a schema-4 fresh profile. Recovery never runs this path.' }
Assert-KitRoot
if ($DataDirectory -notmatch '^/srv/[A-Za-z0-9_-]+$') { throw 'Choose a dedicated data directory directly below /srv.' }
$release=Read-KitRelease $ReleaseDirectory $ExpectedManifestSHA256 -RequireFull
if ($release.Manifest.version -ne '9.5.4') { throw 'This release runner currently targets the inspected 9.5.4 vendor payload.' }
$version=$release.Manifest.version
foreach($cidr in $AllowedClientCIDRs) {
    if($cidr -notmatch '^(\d{1,3}\.){3}\d{1,3}/([1-9]|[12][0-9]|3[0-2])$'){throw 'Client access must use explicit IPv4 CIDRs; /0 is refused.'}
    foreach($part in $cidr.Split('/')[0].Split('.')){if([int]$part -gt 255){throw 'Invalid client network.'}}
}
if (-not $AllowedClientCIDRs) { throw 'Provide the approved endpoint/operator source CIDRs. No broad service exposure is assumed.' }
if ((Invoke-KitNative getenforce).Stdout.Trim() -ne 'Enforcing') { throw 'SELinux must remain enforcing.' }
if ((Invoke-KitNative systemctl @('is-active','firewalld') -AllowFailure).ExitCode -ne 0) { throw 'The expected firewalld service is not active.' }
$null=Invoke-KitNative firewall-cmd @("--zone=$FirewallZone",'--list-all')
if (-not (Test-Path -LiteralPath $DataDirectory -PathType Container)) { throw 'Provision and mount the data filesystem before installation.' }
if (-not $Lab -and (Invoke-KitNative mountpoint @('-q',$DataDirectory) -AllowFailure).ExitCode -ne 0) { throw 'Production requires a separately mounted data filesystem.' }
$available=[long]((Invoke-KitNative df @('--output=avail','-B1',$DataDirectory)).Stdout.Trim().Split("`n")[-1].Trim())
if ($available -lt 6GB) { throw 'Insufficient free data space for installation and offline artifacts.' }
$memoryLine=(Get-Content /proc/meminfo | Where-Object { $_ -match '^MemTotal:' })
$totalMB=[long]([regex]::Match($memoryLine,'\d+').Value)/1024
if (-not $Lab -and $totalMB -lt 8192) { throw 'Production sizing acceptance is required; less than 8 GiB RAM is refused.' }
if (($HeapMB+$KibanaHeapMB+1536) -gt $totalMB) { throw 'Heap settings leave insufficient capacity for the OS and Fleet Server.' }
$stateRoot='/var/lib/elastic-kit'
$null=Invoke-KitNative install @('-d','-m','0700',$stateRoot,'/etc/elastic-kit/secrets')
$lock=[IO.File]::Open("$stateRoot/install.lock",[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
$statePath="$stateRoot/install-state.json"
try {
    $profileHash=(Get-FileHash -LiteralPath $SiteProfile -Algorithm SHA256).Hash
    if (Test-Path -LiteralPath $statePath) {
        $state=Get-Content -Raw -LiteralPath $statePath | ConvertFrom-Json -AsHashtable
        if ($state.profile_sha256 -ne $profileHash -or $state.release_sha256 -ne $release.SHA256 -or $state.data_directory -ne $DataDirectory) { throw 'This machine belongs to another profile/release. Existing state is preserved.' }
    } else {
        foreach($name in @('elasticsearch','kibana','elastic-agent')) {
            if((Invoke-KitNative rpm @('-q',$name) -AllowFailure).ExitCode -eq 0){throw "Existing $name package detected. Fresh setup stopped before changing it."}
        }
        foreach($path in @('/etc/elasticsearch','/etc/kibana','/opt/Elastic/Agent',"$DataDirectory/elasticsearch",'/etc/elastic-kit/pki')) {
            if(Test-Path -LiteralPath $path){throw "Existing identity/data preserved: $path"}
        }
        $state=@{schema_version=1;profile_sha256=$profileHash;release_sha256=$release.SHA256;version=$version;data_directory=$DataDirectory;completed=@();status='in-progress';lab=[bool]$Lab}
        Write-KitPrivateFile $statePath ($state | ConvertTo-Json -Depth 10) -CreateNew
    }
    function Step([string]$Name,[scriptblock]$Action) {
        if($state.completed -contains $Name){Write-Host "Already completed: $Name";return}
        Write-Host "Running: $Name"
        $state.current=$Name;$state.status='in-progress'
        Write-KitPrivateFile $statePath ($state | ConvertTo-Json -Depth 10)
        & $Action
        $state.completed+=,$Name
        $state.updated_utc=[DateTime]::UtcNow.ToString('o')
        Write-KitPrivateFile $statePath ($state | ConvertTo-Json -Depth 10)
    }
    Step 'local-rpms' {
        $null=Invoke-KitNative rpm @('--import',$release.Roles.elastic_signing_key[0].full_path)
        foreach($name in @('elasticsearch','kibana')) {
            $input=$release.Roles[$name+'_rpm'][0].full_path
            $metadata=(Invoke-KitNative rpm @('-qp','--qf','%{NAME}|%{VERSION}|%{ARCH}',$input)).Stdout.Trim()
            if($metadata -ne "$name|$version|x86_64"){throw 'RPM identity differs from the approved manifest.'}
            $check=Invoke-KitNative rpm @('--checksig',$input)
            if($check.Stdout -notmatch 'signatures OK'){throw 'RPM signature check did not confirm a trusted signature.'}
            $installed=Invoke-KitNative rpm @('-q','--qf','%{VERSION}',$name) -AllowFailure
            if($installed.ExitCode -eq 0){if($installed.Stdout.Trim() -ne $version){throw 'Unexpected installed version.'};continue}
            $null=Invoke-KitNative systemctl @('mask',$name)
            $null=Invoke-KitNative rpm @('-Uvh','--test',$input)
            $null=Invoke-KitNative rpm @('-Uvh',$input) -Sensitive
        }
        $null=Invoke-KitNative fapolicyd-cli @('--update')
    }
    Step 'rpm-runtime-trust' {
        # RHEL's default RPM trust filter excludes native binaries/libraries under
        # /usr/share. Include only these signed RPM trees; do not add allow-all rules.
        $filter='/etc/fapolicyd/fapolicyd-filter.conf'
        $original=[IO.File]::ReadAllText($filter)
        if(-not(Test-Path "$stateRoot/original-fapolicyd-filter.conf")) {
            Write-KitPrivateFile "$stateRoot/original-fapolicyd-filter.conf" $original -CreateNew
        }
        $wanted=@('+ /usr/share/elasticsearch/','+ /usr/share/kibana/')
        $missing=@($wanted | Where-Object {$_ -notin $original.Split("`n").TrimEnd("`r")})
        if($missing.Count){Write-KitPrivateFile $filter (($missing -join "`n")+"`n"+$original) -Mode '0644'}
        $null=Invoke-KitNative restorecon @($filter)
        $null=Invoke-KitNative systemctl @('restart','fapolicyd')
        $null=Invoke-KitNative systemctl @('is-active','fapolicyd')
        $null=Invoke-KitNative '/usr/share/elasticsearch/jdk/bin/java' @('-version')
    }
    Step 'site-certificates' {
        $pki='/etc/elastic-kit/pki'
        if(Test-Path "$pki/generation-complete.txt"){return}
        if(Test-Path "$pki/import-complete.json"){return}
        if($profile.tls_mode -eq 'certutil') {
            & (Join-Path $PSScriptRoot 'New-SiteCertificates.ps1') -SiteProfile $SiteProfile
        } elseif($CertificateDirectory -and $HttpCA) {
            & (Join-Path $PSScriptRoot 'Import-SiteCertificates.ps1') -SiteProfile $SiteProfile -CertificateDirectory $CertificateDirectory -HttpCA $HttpCA -CsrKeyDirectory $CsrKeyDirectory
        } elseif($profile.tls_mode -eq 'csr') {
            if(-not(Test-Path '/etc/elastic-kit/csr')){& (Join-Path $PSScriptRoot 'New-SiteCertificateRequests.ps1') -SiteProfile $SiteProfile}
            throw 'WAITING FOR CA SIGNING: public requests are ready. Resume with signed certificates and -CsrKeyDirectory /etc/elastic-kit/csr.'
        } else { throw 'Existing CA was selected. Supply its public chain and the issued service certificate directory.' }
    }
    Step 'elasticsearch-configuration' {
        $null=Invoke-KitNative install @('-d','-m','0750','-o','elasticsearch','-g','elasticsearch',"$DataDirectory/elasticsearch")
        $null=Invoke-KitNative install @('-d','-m','0750','-o','root','-g','elasticsearch','/etc/elasticsearch/certs')
        foreach($service in @('elasticsearch-http','elasticsearch-transport')) {
            foreach($suffix in @('crt','key')) {
                $null=Invoke-KitNative install @('-m','0640','-o','root','-g','elasticsearch',"/etc/elastic-kit/pki/$service/$service.$suffix","/etc/elasticsearch/certs/$service.$suffix")
            }
        }
        foreach($layer in @('http','transport')){$null=Invoke-KitNative install @('-m','0640','-g','elasticsearch',"/etc/elastic-kit/pki/$layer-ca/ca.crt","/etc/elasticsearch/certs/$layer-ca.crt")}
        if(-not(Test-Path "$stateRoot/original-elasticsearch.yml")){$null=Invoke-KitNative cp @('-a','/etc/elasticsearch/elasticsearch.yml',"$stateRoot/original-elasticsearch.yml")}
        $yaml=@"
cluster.name: $($profile.site_name)
node.name: $($profile.hostname)
path.data: $DataDirectory/elasticsearch
path.logs: /var/log/elasticsearch
network.host: $($profile.ipv4_address)
transport.host: $($profile.ipv4_address)
discovery.type: single-node
xpack.security.enabled: true
xpack.security.autoconfiguration.enabled: false
xpack.security.http.ssl.enabled: true
xpack.security.http.ssl.certificate: certs/elasticsearch-http.crt
xpack.security.http.ssl.key: certs/elasticsearch-http.key
xpack.security.http.ssl.certificate_authorities: [certs/http-ca.crt]
xpack.security.transport.ssl.enabled: true
xpack.security.transport.ssl.verification_mode: full
xpack.security.transport.ssl.certificate: certs/elasticsearch-transport.crt
xpack.security.transport.ssl.key: certs/elasticsearch-transport.key
xpack.security.transport.ssl.certificate_authorities: [certs/transport-ca.crt]
ingest.geoip.downloader.enabled: false
"@
        if($Lab){$yaml+="`nxpack.ml.enabled: false`n"}
        Write-KitPrivateFile '/etc/elasticsearch/elasticsearch.yml' ($yaml+"`n") -Mode '0640'
        $null=Invoke-KitNative chown @('root:elasticsearch','/etc/elasticsearch/elasticsearch.yml')
        $list=(Invoke-KitNative '/usr/share/elasticsearch/bin/elasticsearch-keystore' @('list')).Stdout.Split("`n") | ForEach-Object {$_.Trim()}
        foreach($setting in @('xpack.security.http.ssl.keystore.secure_password','xpack.security.transport.ssl.keystore.secure_password','xpack.security.transport.ssl.truststore.secure_password')) {
            if($list -contains $setting){$null=Invoke-KitNative '/usr/share/elasticsearch/bin/elasticsearch-keystore' @('remove',$setting)}
        }
        Write-KitPrivateFile '/etc/elasticsearch/jvm.options.d/elastic-kit.options' "-Xms${HeapMB}m`n-Xmx${HeapMB}m`n" -Mode '0640'
        $null=Invoke-KitNative chown @('root:elasticsearch','/etc/elasticsearch/jvm.options.d/elastic-kit.options')
        Write-KitPrivateFile '/etc/sysctl.d/90-elastic-kit.conf' "vm.max_map_count = 1048576`n" -Mode '0644'
        $null=Invoke-KitNative sysctl @('-p','/etc/sysctl.d/90-elastic-kit.conf')
        $labels=(Invoke-KitNative semanage @('fcontext','-l','-C')).Stdout
        if($labels -notmatch [regex]::Escape("$DataDirectory/elasticsearch")) {
            $null=Invoke-KitNative semanage @('fcontext','-a','-e','/var/lib/elasticsearch',"$DataDirectory/elasticsearch")
        }
        $null=Invoke-KitNative restorecon @('-RF','/etc/elasticsearch',"$DataDirectory/elasticsearch")
        Write-KitPrivateFile '/etc/systemd/system/elasticsearch.service.d/elastic-kit.conf' "[Unit]`nRequiresMountsFor=$DataDirectory`n" -Mode '0644'
        $null=Invoke-KitNative systemctl @('daemon-reload')
        $null=Invoke-KitNative systemctl @('unmask','elasticsearch')
        $null=Invoke-KitNative systemctl @('enable','--now','elasticsearch')
    }
    Step 'elasticsearch-credential' {
        if(-not(Test-Path '/etc/elastic-kit/secrets/admin.curl')) {
            $password=(Invoke-KitNative '/usr/share/elasticsearch/bin/elasticsearch-reset-password' @('--username','elastic','--auto','--batch','--silent','--url',$profile.elasticsearch_url) -Sensitive -TimeoutSeconds 180).Stdout.Trim()
            if($password.Length -lt 12 -or $password -match '[\r\n\x00]'){throw 'Password utility returned unexpected output; no credential was saved.'}
            Write-KitPrivateFile '/etc/elastic-kit/secrets/elastic.password' ($password+"`n") -CreateNew
            $escaped=$password.Replace('\','\\').Replace('"','\"')
            Write-KitPrivateFile '/etc/elastic-kit/secrets/admin.curl' ("user = `"elastic:$escaped`"`n") -CreateNew
            $password=$null;$escaped=$null
        }
        $null=Wait-KitApi $profile 'es'
    }
    Step 'kibana-configuration' {
        $null=Invoke-KitNative install @('-d','-m','0750','-g','kibana','/etc/kibana/certs')
        foreach($suffix in @('crt','key')){$null=Invoke-KitNative install @('-m','0640','-g','kibana',"/etc/elastic-kit/pki/kibana/kibana.$suffix","/etc/kibana/certs/kibana.$suffix")}
        $null=Invoke-KitNative install @('-m','0640','-g','kibana','/etc/elastic-kit/pki/http-ca/ca.crt','/etc/kibana/certs/http-ca.crt')
        $tokenPath='/etc/elastic-kit/secrets/kibana.token'
        if(-not(Test-Path $tokenPath)) {
            $token=(Invoke-KitApi $profile -Method POST -Path '/_security/service/elastic/kibana/credential/token/elastic-kit').Data.token.value
            Write-KitPrivateFile $tokenPath ($token+"`n") -CreateNew
        }
        if(-not(Test-Path '/etc/kibana/kibana.keystore')){$null=Invoke-KitNative '/usr/share/kibana/bin/kibana-keystore' @('create') -Environment @{KBN_PATH_CONF='/etc/kibana'}}
        $null=Invoke-KitNative '/usr/share/kibana/bin/kibana-keystore' @('add','elasticsearch.serviceAccountToken','--stdin','--force') -InputText ([IO.File]::ReadAllText($tokenPath)) -Sensitive -Environment @{KBN_PATH_CONF='/etc/kibana'}
        foreach($setting in @('xpack.security.encryptionKey','xpack.encryptedSavedObjects.encryptionKey','xpack.reporting.encryptionKey')) {
            $secretPath='/etc/elastic-kit/secrets/'+$setting
            if(-not(Test-Path $secretPath)){Write-KitPrivateFile $secretPath ((New-KitSecret)+"`n") -CreateNew}
            $null=Invoke-KitNative '/usr/share/kibana/bin/kibana-keystore' @('add',$setting,'--stdin','--force') -InputText ([IO.File]::ReadAllText($secretPath)) -Sensitive -Environment @{KBN_PATH_CONF='/etc/kibana'}
        }
        $yaml=@"
server.host: $($profile.ipv4_address)
server.port: 5601
server.publicBaseUrl: $($profile.kibana_url)
server.ssl.enabled: true
server.ssl.certificate: /etc/kibana/certs/kibana.crt
server.ssl.key: /etc/kibana/certs/kibana.key
elasticsearch.hosts: ["$($profile.elasticsearch_url)"]
elasticsearch.ssl.certificateAuthorities: [/etc/kibana/certs/http-ca.crt]
elasticsearch.ssl.verificationMode: full
xpack.fleet.isAirGapped: true
xpack.fleet.registryUrl: "http://127.0.0.1:8080"
telemetry.enabled: false
telemetry.optIn: false
"@
        if(-not(Test-Path "$stateRoot/original-kibana.yml")){$null=Invoke-KitNative cp @('-a','/etc/kibana/kibana.yml',"$stateRoot/original-kibana.yml")}
        Write-KitPrivateFile '/etc/kibana/kibana.yml' ($yaml+"`n") -Mode '0640'
        $null=Invoke-KitNative chown @('root:kibana','/etc/kibana/kibana.yml','/etc/kibana/kibana.keystore')
        $null=Invoke-KitNative chmod @('0640','/etc/kibana/kibana.keystore')
        Write-KitPrivateFile '/etc/kibana/node.options' "--max-old-space-size=$KibanaHeapMB`n" -Mode '0644'
        $null=Invoke-KitNative restorecon @('-RF','/etc/kibana')
        $null=Invoke-KitNative systemctl @('unmask','kibana')
        $null=Invoke-KitNative systemctl @('enable','--now','kibana')
        $null=Wait-KitApi $profile 'kibana' -Seconds 600
    }
    Step 'winlogbeat-server-assets' {
        $policy='kit-'+$profile.site_name.ToLowerInvariant()+'-winlogbeat'
        $body=@{policy=@{phases=@{hot=@{actions=@{rollover=@{max_primary_shard_size='30gb';max_age='1d'}}};delete=@{min_age=([string]$profile.retention_days+'d');actions=@{delete=@{}}}}}}
        $null=Invoke-KitApi $profile -Method PUT -Path "/_ilm/policy/$policy" -Body $body
        $template=Get-Content -Raw -LiteralPath $release.Roles.winlogbeat_template[0].full_path | ConvertFrom-Json -AsHashtable
        if(-not $template.Contains('data_stream') -or @($template.index_patterns).Count -ne 1 -or $template.index_patterns[0] -ne "winlogbeat-$version"){throw 'Unexpected vendor template shape.'}
        if(-not $template.template.Contains('settings')){$template.template.settings=@{}}
        $settings=$template.template.settings
        foreach($flat in @('index.lifecycle.name','index.number_of_replicas','index.number_of_shards')) {$settings.Remove($flat)}
        if(-not $settings.Contains('index')){$settings.index=@{}}
        if(-not $settings.index.Contains('lifecycle')){$settings.index.lifecycle=@{}}
        $settings.index.lifecycle.name=$policy
        $settings.index.number_of_replicas=0
        $settings.index.number_of_shards=1
        $null=Invoke-KitApi $profile -Method PUT -Path "/_index_template/winlogbeat-$version" -Body $template
        if(-not $release.Roles.ContainsKey('winlogbeat_pipeline')){throw 'Release has no exported Winlogbeat pipelines.'}
        foreach($input in ($release.Roles.winlogbeat_pipeline | Sort-Object @{Expression={if($_.pipeline_id -match '-routing$'){2}elseif($_.pipeline_id -match '-security$'){1}else{0}}})) {
            if($input.pipeline_id -notmatch '^winlogbeat-9\.5\.4-[a-z_]+$'){throw 'Invalid exported pipeline ID.'}
            $null=Invoke-KitApi $profile -Method PUT -Path ("/_ingest/pipeline/"+$input.pipeline_id) -BodyFile $input.full_path
        }
        $exists=Invoke-KitApi $profile -Path "/_data_stream/winlogbeat-$version" -AllowFailure
        if($exists.Status -eq 404){$null=Invoke-KitApi $profile -Method PUT -Path "/_data_stream/winlogbeat-$version"}
        elseif(-not $exists.Success){throw 'Could not inspect Winlogbeat data stream.'}
        $null=Invoke-KitApi $profile -Path '/winlogbeat-*/_ilm/explain'
        $view=Invoke-KitApi $profile -Service kibana -Path '/api/data_views/data_view/elastic-kit-winlogbeat' -AllowFailure
        if($view.Status -eq 404){
            $null=Invoke-KitApi $profile -Service kibana -Method POST -Path '/api/data_views/data_view' -Body @{data_view=@{id='elastic-kit-winlogbeat';title='winlogbeat-*';name='Windows event logs';timeFieldName='@timestamp'};override=$false}
        } elseif(-not $view.Success -or $view.Data.data_view.title -ne 'winlogbeat-*'){throw 'Existing data view differs or cannot be inspected.'}
    }
    Step 'fleet-and-artifacts' {
        & (Join-Path $PSScriptRoot 'Install-KitFleet.ps1') -SiteProfile $SiteProfile -ReleaseDirectory $ReleaseDirectory -ExpectedManifestSHA256 $ExpectedManifestSHA256 -DataDirectory $DataDirectory
    }
    Step 'client-firewall' {
        foreach($source in $AllowedClientCIDRs){foreach($port in @(9200,5601,8220,8443)){
            $rule="rule family=`"ipv4`" source address=`"$source`" port port=`"$port`" protocol=`"tcp`" accept"
            $null=Invoke-KitNative firewall-cmd @('--permanent',"--zone=$FirewallZone",'--add-rich-rule',$rule)
        }}
        $null=Invoke-KitNative firewall-cmd @('--reload')
    }
    Step 'winlogbeat-payload' {
        $output="$DataDirectory/output"
        $null=Invoke-KitNative install @('-d','-m','0750',$output)
        $vendor=$release.Roles.winlogbeat_zip[0]
        & (Join-Path $PSScriptRoot 'Build-WinlogbeatBundle.ps1') -SiteProfile $SiteProfile -VendorZip $vendor.full_path -ExpectedSHA512 $vendor.sha512 -CaCertificate '/etc/elastic-kit/pki/http-ca/ca.crt' -OutputZip "$output/Winlogbeat.zip" -OutputDirectory "$output/Winlogbeat"
    }
    $state.status='services-configured-endpoint-acceptance-pending';$state.current='complete'
    $state.updated_utc=[DateTime]::UtcNow.ToString('o')
    Write-KitPrivateFile $statePath ($state | ConvertTo-Json -Depth 10)
    Write-Host "Server setup finished. Kibana: $($profile.kibana_url)"
    Write-Host "Winlogbeat folder: $DataDirectory/output/Winlogbeat"
    Write-Host 'Administrator credential: protected /etc/elastic-kit/secrets/elastic.password on this VM.'
    Write-Host 'Next: create per-host publishing keys, publish the folder, and prove new events from one test endpoint.'
} catch {
    if($null -ne (Get-Variable state -ErrorAction SilentlyContinue)){
        $state.status='stopped';Write-KitPrivateFile $statePath ($state | ConvertTo-Json -Depth 10)
    }
    throw
} finally { $lock.Dispose() }
