#requires -Version 7.2
<# Same-version full recovery onto a separately provisioned, disposable kit target.
The source must be offline. Original target files are preserved under protected
rollback paths; Elasticsearch data is recovered through its snapshot API only.
#>
[CmdletBinding()]
param([Parameter(Mandatory)][string]$StagingDirectory,
      [Parameter(Mandatory)][string]$ReleaseDirectory,
      [Parameter(Mandatory)][string]$ExpectedTargetClusterUUID,
      [Parameter(Mandatory)][string]$ExpectedSourceClusterUUID,
      [Parameter(Mandatory)][ValidatePattern('^[a-fA-F0-9]{64}$')][string]$ExpectedCiphertextSHA256,
      [switch]$SourceIsolated,[switch]$ReplaceFreshTarget,[switch]$ResumeVerification)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
Import-Module (Join-Path $PSScriptRoot 'Kit.Common.psm1') -Force
Assert-KitRoot
if(-not $SourceIsolated -or -not $ReplaceFreshTarget){throw 'Isolate the source and explicitly select a disposable fresh recovery target before proceeding.'}
if($StagingDirectory -notmatch '^/srv/[A-Za-z0-9_-]+/recovery-stage-[a-z0-9-]+$'){throw 'Invalid recovery staging path.'}
if((Invoke-KitNative realpath @('-e',$StagingDirectory)).Stdout.Trim() -ne $StagingDirectory){throw 'Staging path cannot traverse links.'}
$stage=Get-Content -Raw "$StagingDirectory/stage.json"|ConvertFrom-Json -AsHashtable
$record=$stage.record;$tree="$StagingDirectory/tree"
if($stage.status -ne 'verified-staged-not-restored' -or $stage.tree -ne $tree -or $stage.ciphertext_sha256 -ne $ExpectedCiphertextSHA256.ToLowerInvariant()){throw 'Staging identity or authenticated ciphertext hash differs.'}
if($record.cluster_uuid -ne $ExpectedSourceClusterUUID -or $ExpectedSourceClusterUUID -eq $ExpectedTargetClusterUUID){throw 'Source and fresh target UUIDs must be distinct and explicitly verified.'}
$journal='/var/lib/elastic-kit/restore-state.json'
$resumeState=$null
if($ResumeVerification){
    if(-not(Test-Path $journal)){throw 'No saved recovery journal exists to resume.'}
    $resumeState=Get-Content -Raw $journal|ConvertFrom-Json -AsHashtable
    if($resumeState.status -ne 'failed-inspect-preserved-journal' -or $resumeState.current -ne 'restart-and-verify-restored-fleet' -or 'restore-global-state-and-all-features' -notin $resumeState.completed){throw 'Only post-snapshot Fleet verification can resume through this option.'}
    if($resumeState.source_cluster_uuid -ne $ExpectedSourceClusterUUID -or $resumeState.old_target_cluster_uuid -ne $ExpectedTargetClusterUUID -or $resumeState.ciphertext_sha256 -ne $ExpectedCiphertextSHA256){throw 'Saved recovery identity does not match the explicit request.'}
}elseif(Test-Path $journal){throw 'Existing restore journal preserved. Inspect it before starting another recovery.'}
$targetProfile=Get-Content -Raw '/etc/elastic-kit/site/site.json'|ConvertFrom-Json -AsHashtable
$sourceProfile=Get-Content -Raw "$tree/etc/elastic-kit/site/site.json"|ConvertFrom-Json -AsHashtable
foreach($field in @('hostname','ipv4_address','elasticsearch_url','kibana_url','fleet_url')){
    if($targetProfile[$field] -ne $sourceProfile[$field]){throw "This recovery runner requires the original site address/name: $field"}
}
$current=(Invoke-KitApi $targetProfile -Path '/').Data
$liveExpected=if($ResumeVerification){$resumeState.new_target_cluster_uuid}else{$ExpectedTargetClusterUUID}
if($current.cluster_uuid -ne $liveExpected -or $current.version.number -ne $record.version -or $record.version -ne '9.5.4'){throw 'Target UUID or reviewed same-version restore requirement failed.'}
$install=Get-Content -Raw '/var/lib/elastic-kit/install-state.json'|ConvertFrom-Json -AsHashtable
$data=$install.data_directory
if($data -notmatch '^/srv/[A-Za-z0-9_-]+$' -or $data -ne $record.data_directory -or $install.release_sha256 -ne $record.release_sha256){throw 'Target release or data mount differs from the recovery record.'}
$release=Read-KitRelease $ReleaseDirectory $record.release_sha256 -RequireFull
if($release.Manifest.version -ne $record.version){throw 'Verified recovery release version differs from the snapshot.'}
if(-not $ResumeVerification -and (Invoke-KitApi $targetProfile -Path '/winlogbeat-*/_count').Data.count -ne 0){throw 'Target contains Windows events. Existing data was preserved; use a fresh recovery target.'}
if((Invoke-KitApi $targetProfile -Path '/_cluster/health').Data.number_of_nodes -ne 1){throw 'This runner is limited to the one-node kit.'}
if($ResumeVerification){
    $state=$resumeState;$rollback=$state.rollback
    if($rollback -notmatch ('^'+[regex]::Escape($data)+'/recovery-rollback-[0-9]{8}-[0-9]{6}-[a-f0-9]{8}$') -or (Invoke-KitNative realpath @('-e',$rollback)).Stdout.Trim() -ne $rollback){throw 'Preserved rollback directory identity failed.'}
    if($targetProfile.mode -ne 'recovery' -or $targetProfile.tls_mode -ne 'restore'){throw 'Recovered profile is not marked for recovery.'}
    $state.status='in-progress'
}else{
    $id=[DateTime]::UtcNow.ToString('yyyyMMdd-HHmmss')+'-'+[Guid]::NewGuid().ToString('N').Substring(0,8)
    $rollback="$data/recovery-rollback-$id"
    $null=Invoke-KitNative install @('-d','-m','0700',$rollback)
    $state=@{schema_version=1;source_cluster_uuid=$ExpectedSourceClusterUUID;old_target_cluster_uuid=$ExpectedTargetClusterUUID;ciphertext_sha256=$ExpectedCiphertextSHA256;rollback=$rollback;current='preflight';status='in-progress';completed=@()}
}
function Save-State {Write-KitPrivateFile $journal ($state|ConvertTo-Json -Depth 12)}
Save-State
function Step([string]$Name,[scriptblock]$Action){
    if($ResumeVerification){
        if($Name -in $state.completed){return}
        if($Name -notin @('restart-and-verify-restored-fleet','rebuild-winlogbeat-with-restored-ca')){throw 'Resume cannot repeat data or identity restoration.'}
    }
    $state.current=$Name;Save-State
    Write-Host "Recovery: $Name"
    & $Action
    $state.completed+=,$Name;Save-State
}
function Replace-FromStage([string]$Relative){
    $source="$tree/$Relative";$target='/'+$Relative
    if(-not(Test-Path -LiteralPath $source)){return}
    if((Get-Item -Force -LiteralPath $source).Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Top-level restore sources must not be links.'}
    $saved="$rollback/$Relative"
    $null=Invoke-KitNative install @('-d','-m','0700',(Split-Path -Parent $saved))
    if(Test-Path -LiteralPath $target){
        if((Get-Item -Force -LiteralPath $target).Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Existing top-level restore target is a link; preserved.'}
        $null=Invoke-KitNative mv @('--',$target,$saved)
    }
    $null=Invoke-KitNative cp @('-a','--reflink=auto','--',$source,$target) -Sensitive -TimeoutSeconds 900
}
$auth='/var/lib/elastic-kit/recovery-auth.curl'
$user='kit_recovery_'+[Guid]::NewGuid().ToString('N').Substring(0,12)
$role='kit_recovery_role_'+[Guid]::NewGuid().ToString('N').Substring(0,12)
$recovery=@{roles_before=$null;user_created=$false}
try{
    Step 'stop-clients-and-server' {
        $null=Invoke-KitNative systemctl @('stop','kibana','elastic-agent','elastic-kit-https')
        $null=Invoke-KitNative systemctl @('stop','elasticsearch')
    }
    Step 'preserve-target-data' {
        $old="$data/elasticsearch"
        if((Invoke-KitNative realpath @('-e',$old)).Stdout.Trim() -ne $old){throw 'Unexpected Elasticsearch data link.'}
        $null=Invoke-KitNative mv @('--',$old,"$rollback/elasticsearch-data")
        $null=Invoke-KitNative install @('-d','-m','0750','-o','elasticsearch','-g','elasticsearch',$old)
    }
    Step 'restore-protected-config-and-agent' {
        foreach($relative in @('etc/elasticsearch','etc/kibana','etc/elastic-kit',
                'etc/systemd/system/elasticsearch.service.d','etc/systemd/system/kibana.service.d',
                'etc/systemd/system/elastic-kit-https.service','etc/systemd/system/elastic-agent.service',
                'etc/sysconfig/elastic-agent','var/lib/elastic-kit/install-state.json',
                'var/lib/elastic-kit/fleet-state.json',($data.TrimStart('/')+'/Elastic/Agent'))){
            Replace-FromStage $relative
        }
        # Restore account names through the fresh RPM identities, not old numeric IDs.
        $null=Invoke-KitNative chown @('-R','root:elasticsearch','/etc/elasticsearch')
        $null=Invoke-KitNative chown @('-R','root:kibana','/etc/kibana')
        $null=Invoke-KitNative chown @('-R','root:root','/etc/elastic-kit',"$data/Elastic/Agent")
        $null=Invoke-KitNative restorecon @('-RF','/etc/elasticsearch','/etc/kibana','/etc/elastic-kit','/etc/systemd/system',"$data/elasticsearch","$data/Elastic/Agent")
        $null=Invoke-KitNative '/usr/libexec/platform-python' @((Join-Path $PSScriptRoot 'write-agent-trust.py'),'--root',"$data/Elastic/Agent",'--name','elastic-kit-agent')
        $null=Invoke-KitNative fapolicyd-cli @('--update')
        $null=Invoke-KitNative systemctl @('daemon-reload')
    }
    Step 'mark-recovered-profile' {
        $sourceProfile.mode='recovery';$sourceProfile.tls_mode='restore'
        $sourceProfile.ca_certificate_relative_path='';$sourceProfile.server_certificates_relative_path=''
        Import-Module (Join-Path $PSScriptRoot 'SiteProfile.psm1') -Force
        $null=Test-SiteProfile $sourceProfile
        Write-KitPrivateFile '/etc/elastic-kit/site/site.json' ($sourceProfile|ConvertTo-Json -Depth 12)
        $recoveredInstall=Get-Content -Raw '/var/lib/elastic-kit/install-state.json'|ConvertFrom-Json -AsHashtable
        $recoveredInstall.profile_sha256=(Get-FileHash '/etc/elastic-kit/site/site.json' -Algorithm SHA256).Hash.ToLowerInvariant()
        $recoveredInstall.status='recovery-in-progress';$recoveredInstall.current='snapshot-restore'
        Write-KitPrivateFile '/var/lib/elastic-kit/install-state.json' ($recoveredInstall|ConvertTo-Json -Depth 12)
    }
    Step 'restore-readonly-repository' {
        if(Test-Path $record.repository_location){throw 'Existing target repository preserved.'}
        $null=Invoke-KitNative install @('-d','-m','0755',$record.repository_root)
        $null=Invoke-KitNative cp @('-a','--reflink=auto',"$tree$($record.repository_location)",$record.repository_location) -Sensitive -TimeoutSeconds 900
        $null=Invoke-KitNative chown @('-R','elasticsearch:elasticsearch',$record.repository_location)
        $labels=(Invoke-KitNative semanage @('fcontext','-l','-C')).Stdout
        if($labels -notmatch [regex]::Escape($record.repository_root)){$null=Invoke-KitNative semanage @('fcontext','-a','-e','/var/lib/elasticsearch',$record.repository_root)}
        $null=Invoke-KitNative restorecon @('-RF',$record.repository_root)
    }
    Step 'temporary-file-realm-recovery-access' {
        $recovery.roles_before=[IO.File]::ReadAllText('/etc/elasticsearch/roles.yml')
        Write-KitPrivateFile '/etc/elasticsearch/roles.yml' ($recovery.roles_before+"`n${role}:`n  cluster: [ 'all' ]`n  indices:`n    - names: [ '*' ]`n      privileges: [ 'all' ]`n      allow_restricted_indices: true`n") -Mode '0640'
        $null=Invoke-KitNative chown @('root:elasticsearch','/etc/elasticsearch/roles.yml')
        $password=New-KitSecret
        # RPM configuration is root-owned with a non-writable group directory.
        # Run its writer as root, then explicitly preserve service-readable ACLs.
        $null=Invoke-KitNative '/usr/share/elasticsearch/bin/elasticsearch-users' @('useradd',$user,'-r',$role) -InputText ($password+"`n"+$password+"`n") -Sensitive
        $recovery.user_created=$true
        $null=Invoke-KitNative chown @('root:elasticsearch','/etc/elasticsearch/users','/etc/elasticsearch/users_roles')
        $null=Invoke-KitNative chmod @('0660','/etc/elasticsearch/users','/etc/elasticsearch/users_roles')
        Write-KitPrivateFile $auth ("user = `"${user}:$password`"`n") -CreateNew
        $password=$null
        $null=Invoke-KitNative restorecon @('-RF','/etc/elasticsearch')
        $null=Invoke-KitNative systemctl @('start','elasticsearch')
        $deadline=[DateTime]::UtcNow.AddMinutes(8)
        do{
            $probe=Invoke-KitApi $sourceProfile -Path '/' -AuthFile $auth -AllowFailure
            if($probe.Success){break};Start-Sleep 3
        }while([DateTime]::UtcNow -lt $deadline)
        if(-not $probe.Success){throw 'Recovery file-realm access did not become ready.'}
        $state.new_target_cluster_uuid=$probe.Data.cluster_uuid;Save-State
    }
    Step 'restore-global-state-and-all-features' {
        $body=@{type='fs';settings=@{location=$record.repository_location;readonly=$true}}
        $null=Invoke-KitApi $sourceProfile -Method PUT -Path ('/_snapshot/'+$record.repository_name) -Body $body -AuthFile $auth
        $snapshot=(Invoke-KitApi $sourceProfile -Path ('/_snapshot/'+$record.repository_name+'/'+$record.snapshot) -AuthFile $auth).Data.snapshots[0]
        if($snapshot.state -ne 'SUCCESS' -or -not $snapshot.include_global_state){throw 'Snapshot is not complete with global state.'}
        foreach($feature in @('fleet','kibana','security')){if($feature -notin @($snapshot.feature_states.feature_name)){throw 'Snapshot feature state is missing.'}}
        $null=Invoke-KitApi $sourceProfile -Method POST -Path '/_ilm/stop' -AuthFile $auth
        $null=Invoke-KitApi $sourceProfile -Method PUT -Path '/_cluster/settings' -AuthFile $auth -Body @{persistent=@{'ingest.geoip.downloader.enabled'=$false;'indices.lifecycle.history_index_enabled'=$false}}
        $restored=(Invoke-KitApi $sourceProfile -Method POST -Path ('/_snapshot/'+$record.repository_name+'/'+$record.snapshot+'/_restore?wait_for_completion=true') -AuthFile $auth -Body @{indices='*';include_global_state=$true;feature_states=@($snapshot.feature_states.feature_name)}).Data
        if(-not $restored.Contains('snapshot') -or $restored.snapshot.shards.failed -ne 0){throw 'Restore did not confirm zero failed shards; inspect before continuing.'}
        $null=Wait-KitApi $sourceProfile es -Seconds 600
        $null=Invoke-KitApi $sourceProfile -Method POST -Path '/_ilm/start'
        $null=Invoke-KitApi $sourceProfile -Method PUT -Path '/_cluster/settings' -Body @{persistent=@{'indices.lifecycle.history_index_enabled'=$null}}
    }
    Step 'restart-and-verify-restored-fleet' {
        $null=Invoke-KitNative systemctl @('start','kibana','elastic-agent','elastic-kit-https')
        $null=Wait-KitApi $sourceProfile kibana -Seconds 600
        $deadline=[DateTime]::UtcNow.AddMinutes(5)
        $missing=@($record.fleet_agents)
        do{
            $fleetResponse=Invoke-KitApi $sourceProfile -Service kibana -Path '/api/fleet/agents?perPage=100' -AllowFailure
            if($fleetResponse.Success){
                $agents=$fleetResponse.Data.items
                $missing=@($record.fleet_agents|Where-Object { $_.id -notin @($agents|Where-Object {$_.status -eq 'online'}|ForEach-Object {$_.id}) })
                if(-not $missing.Count){break}
            }elseif($fleetResponse.Status -notin @(0,429,502,503,504)){throw "Fleet readiness failed with HTTP $($fleetResponse.Status)."}
            Start-Sleep 5
        }while([DateTime]::UtcNow -lt $deadline)
        if($missing.Count){throw 'Backed-up Fleet identity has not returned online. Enrollment preservation is not proven.'}
        & (Join-Path $PSScriptRoot 'Test-ElasticKit.ps1') -SiteProfile '/etc/elastic-kit/site/site.json'
    }
    Step 'rebuild-winlogbeat-with-restored-ca' {
        $output="$data/output"
        if((Invoke-KitNative realpath @('-e',$output)).Stdout.Trim() -ne $output){throw 'Winlogbeat output parent cannot traverse links.'}
        $null=Invoke-KitNative install @('-d','-m','0700',"$rollback/output")
        foreach($name in @('Winlogbeat','Winlogbeat.zip')){
            $old="$output/$name"
            if(Test-Path -LiteralPath $old){
                if((Get-Item -Force -LiteralPath $old).Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Existing Winlogbeat output is a link; preserved.'}
                $null=Invoke-KitNative mv @('--',$old,"$rollback/output/$name")
            }
        }
        $vendor=$release.Roles.winlogbeat_zip[0]
        & (Join-Path $PSScriptRoot 'Build-WinlogbeatBundle.ps1') -SiteProfile '/etc/elastic-kit/site/site.json' -VendorZip $vendor.full_path -ExpectedSHA512 $vendor.sha512 -CaCertificate '/etc/elastic-kit/pki/http-ca/ca.crt' -OutputZip "$output/Winlogbeat.zip" -OutputDirectory "$output/Winlogbeat"
        $recoveredInstall=Get-Content -Raw '/var/lib/elastic-kit/install-state.json'|ConvertFrom-Json -AsHashtable
        $recoveredInstall.status='recovered-endpoint-acceptance-pending';$recoveredInstall.current='complete'
        Write-KitPrivateFile '/var/lib/elastic-kit/install-state.json' ($recoveredInstall|ConvertTo-Json -Depth 12)
    }
    $state.status='restored-server-accepted-endpoint-resume-test-pending';Save-State
    $stage.status='restored';Write-KitPrivateFile "$StagingDirectory/stage.json" ($stage|ConvertTo-Json -Depth 14)
    Write-Host "Recovered snapshot $($record.snapshot). Fleet identity is online. Prove endpoint publishing before declaring disaster recovery complete."
    Write-Host "Preserved fresh target files: $rollback"
}catch{
    $state.status='failed-inspect-preserved-journal';Save-State
    throw
}finally{
    if($recovery.user_created){
        $cleanup=Invoke-KitNative '/usr/share/elasticsearch/bin/elasticsearch-users' @('userdel',$user) -AllowFailure -Sensitive
        if($cleanup.ExitCode -eq 0){
            $null=Invoke-KitNative chown @('root:elasticsearch','/etc/elasticsearch/users','/etc/elasticsearch/users_roles')
            $null=Invoke-KitNative chmod @('0660','/etc/elasticsearch/users','/etc/elasticsearch/users_roles')
            if($null -ne $recovery.roles_before){Write-KitPrivateFile '/etc/elasticsearch/roles.yml' $recovery.roles_before -Mode '0640';$null=Invoke-KitNative chown @('root:elasticsearch','/etc/elasticsearch/roles.yml')}
            if(Test-Path $auth){[IO.File]::Delete($auth)}
        }else{Write-Warning 'Temporary recovery account cleanup requires attention; protected recovery auth retained.'}
    }elseif($null -ne $recovery.roles_before){
        Write-KitPrivateFile '/etc/elasticsearch/roles.yml' $recovery.roles_before -Mode '0640'
        $null=Invoke-KitNative chown @('root:elasticsearch','/etc/elasticsearch/roles.yml')
    }
}
