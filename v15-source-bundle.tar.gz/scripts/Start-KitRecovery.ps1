#requires -Version 7.2
<# Interactive front end for the accepted staging and restoration commands.
The replacement must already be an empty, separately provisioned same-version
kit at the original site name/address. No source shutdown is inferred.
#>
[CmdletBinding()]
param([string]$SiteProfile='/etc/elastic-kit/site/site.json')
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
Import-Module (Join-Path $PSScriptRoot 'Kit.Common.psm1') -Force
Assert-KitRoot
Write-Host 'Recover an offline Elastic kit'
Write-Host 'The original VM must be powered off or isolated from all clients.'
Write-Host 'Use an empty replacement kit with the same version, release, DNS name and IP.'
Write-Host 'The saved CA, credentials, Fleet identity and data will replace its temporary identity.'
if(-not(Test-Path '/var/lib/elastic-kit/install-state.json')){
    throw 'Provision the empty replacement first using the Fresh installation procedure and the original site address. Do not point Windows clients at it. Then run Start-KitRecovery.ps1. Existing recovery settings are preserved.'
}
$profile=Get-Content -Raw -LiteralPath $SiteProfile|ConvertFrom-Json -AsHashtable
$identity=(Invoke-KitApi $profile -Path '/').Data
Write-Host "Connected replacement: $($profile.hostname); version $($identity.version.number); UUID $($identity.cluster_uuid)"
$journal='/var/lib/elastic-kit/restore-state.json'
if(Test-Path $journal){
    $saved=Get-Content -Raw $journal|ConvertFrom-Json -AsHashtable
    if($saved.status -eq 'restored-server-accepted-endpoint-resume-test-pending'){
        & (Join-Path $PSScriptRoot 'Test-ElasticKit.ps1') -SiteProfile $SiteProfile
        Write-Host 'Recovery is already recorded. Prove a NEW event from a Windows endpoint before rollout.'
        return
    }
    throw 'An earlier recovery journal exists. Inspect it and use the documented narrowly guarded ResumeVerification option if applicable. This wizard will not repeat a restore.'
}
if((Read-Host 'Is the original VM powered off or fully isolated? Type SOURCE ISOLATED').Trim() -cne 'SOURCE ISOLATED'){throw 'Source isolation was not confirmed. No restore started.'}
$confirmed=(Read-Host 'Type the replacement cluster UUID shown above to select this empty target').Trim()
if($confirmed -cne $identity.cluster_uuid){throw 'Target UUID did not match. No restore started.'}
$stagePath=(Read-Host 'Path to a previously verified recovery-stage directory (blank to decrypt a backup now)').Trim()
if(-not $stagePath){
    $bundle=(Read-Host 'Full path to the encrypted recovery.kitbackup file').Trim()
    $cipherHash=(Read-Host 'Its SHA-256 from the independently kept backup record').Trim()
    $certificate=(Read-Host 'Full path to the backup recipient certificate').Trim()
    $key=(Read-Host 'Full path to the separately held recipient private-key file (never paste the key)').Trim()
    $stagePath=(Read-Host 'New protected staging directory, for example /srv/elastic-data/recovery-stage-site01').Trim()
    & (Join-Path $PSScriptRoot 'Stage-KitRecovery.ps1') -RecoveryBundle $bundle -ExpectedCiphertextSHA256 $cipherHash -RecipientCertificate $certificate -RecipientPrivateKey $key -Destination $stagePath
}else{
    $cipherHash=(Read-Host 'Encrypted backup SHA-256 from the independently kept backup record').Trim()
}
if($stagePath -notmatch '^/srv/[A-Za-z0-9_-]+/recovery-stage-[a-z0-9-]+$'){throw 'Invalid recovery stage path.'}
$stage=Get-Content -Raw -LiteralPath "$stagePath/stage.json"|ConvertFrom-Json -AsHashtable
if($cipherHash -notmatch '^[a-fA-F0-9]{64}$' -or $stage.ciphertext_sha256 -ne $cipherHash.ToLowerInvariant() -or $stage.status -ne 'verified-staged-not-restored'){throw 'Stage and independently kept backup hash do not match.'}
$sourceUUID=(Read-Host 'Original/source cluster UUID from the backup record').Trim()
if($sourceUUID -cne $stage.record.cluster_uuid){throw 'Source UUID does not match the authenticated backup.'}
$release=(Read-Host 'Full path to the original approved offline release directory').Trim()
Write-Host "Restore source $sourceUUID into empty target $confirmed. The original target files will be preserved."
if((Read-Host 'Type RESTORE to begin this replacement').Trim() -cne 'RESTORE'){throw 'Restore not requested. Verified staging remains available.'}
& (Join-Path $PSScriptRoot 'Restore-ElasticKit.ps1') -StagingDirectory $stagePath -ReleaseDirectory $release -ExpectedTargetClusterUUID $confirmed -ExpectedSourceClusterUUID $sourceUUID -ExpectedCiphertextSHA256 $cipherHash -SourceIsolated -ReplaceFreshTarget
Write-Host 'Server restoration finished. Prove a NEW Windows event, then reboot and repeat the acceptance checks.'
