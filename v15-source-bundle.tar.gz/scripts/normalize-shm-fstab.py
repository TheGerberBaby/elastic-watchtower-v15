#!/usr/bin/env python3
"""Remove an unsupported tmpfs option emitted by the RHEL 8 image build."""
import os
from pathlib import Path
import re
import shutil
import tempfile


def normalize(text):
    lines = text.splitlines(keepends=True)
    matches = []
    for i, line in enumerate(lines):
        if not line.strip() or line.lstrip().startswith('#'):
            continue
        fields = list(re.finditer(r'\S+', line))
        if len(fields) >= 2 and fields[1].group() == '/dev/shm':
            if len(fields) < 6 or fields[2].group() != 'tmpfs':
                raise ValueError('Unexpected /dev/shm fstab entry; preserved for review.')
            matches.append((i, fields[3]))
    if len(matches) != 1:
        raise ValueError('Expected exactly one /dev/shm tmpfs entry; preserved for review.')
    i, field = matches[0]
    options = [item for item in field.group().split(',') if item != 'inode64']
    for required in ('nodev', 'nosuid', 'noexec'):
        if required not in options:
            raise ValueError('Missing /dev/shm hardening option; preserved for review: '+required)
    lines[i] = lines[i][:field.start()] + ','.join(options) + lines[i][field.end():]
    return ''.join(lines)


def main():
    if os.geteuid() != 0:
        raise SystemExit('Run as root.')
    path = Path('/etc/fstab')
    if path.is_symlink() or not path.is_file():
        raise SystemExit('Unexpected fstab file type.')
    original = path.read_text()
    updated = normalize(original)
    if updated == original:
        print('/dev/shm fstab needs no compatibility correction.')
        return
    backup = Path('/var/lib/elastic-kit/fstab-before-shm-compatibility')
    # A power loss after backup creation must not prevent a safe retry.
    try:
        with backup.open('x') as stream:
            stream.write(original)
            stream.flush()
            os.fsync(stream.fileno())
        os.chmod(backup, 0o600)
    except FileExistsError:
        if backup.is_symlink() or not backup.is_file() or backup.read_text() != original:
            raise ValueError('Existing fstab backup differs; preserved for review.')
    descriptor, name = tempfile.mkstemp(prefix='.fstab-elastic-kit-', dir='/etc')
    try:
        with os.fdopen(descriptor, 'w') as stream:
            stream.write(updated)
            stream.flush()
            os.fsync(stream.fileno())
        shutil.copystat(path, name)
        os.replace(name, path)
    finally:
        if os.path.exists(name):
            os.unlink(name)
    print('Removed unsupported inode64 from /dev/shm tmpfs; other mount settings preserved.')


if __name__ == '__main__':
    main()
