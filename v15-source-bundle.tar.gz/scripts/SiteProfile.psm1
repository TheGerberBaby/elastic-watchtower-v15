Set-StrictMode -Version Latest

function Test-SiteProfile {
    param([Parameter(Mandatory)][System.Collections.IDictionary]$Profile)
    $required = @('schema_version','site_name','mode','hostname','ipv4_address','ipv4_prefix','ipv4_gateway','dns_servers','ad_domain','share_unc','bundle_relative_path','elasticsearch_url','kibana_url')
    if ($Profile.Contains('schema_version') -and $Profile.schema_version -in @(2,3,4)) {
        $required += @('topology','fleet_url','winlogbeat_relative_path','windows_endpoint_count','retention_days')
    }
    if ($Profile.Contains('schema_version') -and $Profile.schema_version -in @(3,4)) { $required += @('tls_mode') }
    if ($Profile.Contains('schema_version') -and $Profile.schema_version -eq 4) { $required += @('ca_certificate_relative_path','server_certificates_relative_path') }
    foreach ($key in $required) {
        if (-not $Profile.Contains($key)) { throw "Missing setting: $key" }
    }
    foreach ($key in $Profile.Keys) {
        if ($key -notin $required) { throw "Unknown setting: $key. Secrets must not be placed in a site profile." }
    }
    if ($Profile.schema_version -notin @(1,2,3,4)) { throw 'Unsupported site profile version.' }
    foreach ($key in $required | Where-Object { $_ -notin @('schema_version','ipv4_prefix','dns_servers','windows_endpoint_count','retention_days') }) {
        if ($Profile[$key] -isnot [string]) { throw "$key must be text." }
    }
    if ($Profile.site_name -notmatch '^[a-zA-Z0-9][a-zA-Z0-9_-]{0,63}$') { throw 'Site name must be 1-64 letters, digits, hyphens or underscores.' }
    if ($Profile.mode -notin @('fresh','recovery')) { throw 'Mode must be fresh or recovery.' }
    $dnsPattern = '^(?=.{1,253}$)(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?$'
    if ($Profile.hostname -notmatch $dnsPattern) { throw 'Hostname must be a fully qualified DNS name.' }
    if ($Profile.ad_domain -and $Profile.ad_domain -notmatch $dnsPattern) { throw 'AD domain must be a DNS name or blank.' }
    function Test-IPv4([string]$Value) {
        if ($Value -notmatch '^(?:\d{1,3}\.){3}\d{1,3}$') { return $false }
        $parts = $Value.Split('.')
        foreach ($part in $parts) { if ([int]$part -gt 255 -or ($part.Length -gt 1 -and $part[0] -eq '0')) { return $false } }
        $ip = [Net.IPAddress]::Parse($Value)
        return $ip.AddressFamily -eq [Net.Sockets.AddressFamily]::InterNetwork -and [int]$parts[0] -gt 0 -and [int]$parts[0] -lt 224 -and [int]$parts[0] -ne 127
    }
    if (-not (Test-IPv4 $Profile.ipv4_address)) { throw 'Invalid unicast IPv4 address.' }
    if ($Profile.ipv4_prefix -isnot [int] -and $Profile.ipv4_prefix -isnot [long]) { throw 'IPv4 prefix must be an integer.' }
    if ($Profile.ipv4_prefix -lt 1 -or $Profile.ipv4_prefix -gt 30) { throw 'This setup supports IPv4 prefixes 1 through 30.' }
    if ($Profile.ipv4_gateway -and -not (Test-IPv4 $Profile.ipv4_gateway)) { throw 'Invalid IPv4 gateway.' }
    if ($Profile.dns_servers -is [string] -or @($Profile.dns_servers).Count -lt 1 -or @($Profile.dns_servers).Count -gt 3) { throw 'Provide one to three DNS server addresses.' }
    foreach ($server in $Profile.dns_servers) { if (-not (Test-IPv4 $server)) { throw 'Invalid IPv4 DNS server.' } }
    if ($Profile.share_unc -and $Profile.share_unc -notmatch '^\\\\[a-zA-Z0-9][a-zA-Z0-9.-]*\\[a-zA-Z0-9][a-zA-Z0-9 _.$-]*$') { throw 'Share must be \\server\share; enter the bundle subfolder separately.' }
    if ($Profile.bundle_relative_path -notmatch '^[a-zA-Z0-9_-]+(?:/[a-zA-Z0-9_. -]+)*$' -or $Profile.bundle_relative_path.Split('/') -contains '..') { throw 'Bundle path must be a relative folder, without traversal.' }
    foreach ($key in @('elasticsearch_url','kibana_url')) {
        $uri = $null
        if (-not [Uri]::TryCreate([string]$Profile[$key],[UriKind]::Absolute,[ref]$uri) -or $uri.Scheme -ne 'https' -or $uri.UserInfo -or $uri.Query -or $uri.Fragment -or $uri.AbsolutePath -ne '/' -or $uri.Host -notmatch $dnsPattern) {
            throw "$key must be an HTTPS DNS endpoint without credentials, path or query."
        }
    }
    if ($Profile.schema_version -in @(2,3,4)) {
        if ($Profile.topology -cne 'single-vm') { throw 'This kit runs Elasticsearch, Kibana and Fleet Server on one RHEL VM.' }
        $expected = Get-SingleVmEndpoints -Hostname $Profile.hostname
        foreach ($key in @('elasticsearch_url','kibana_url','fleet_url')) {
            if ($Profile[$key] -cne $expected[$key]) { throw "$key must match this kit's VM hostname and service port." }
        }
        if ($Profile.windows_endpoint_count -isnot [int] -and $Profile.windows_endpoint_count -isnot [long]) { throw 'Windows endpoint count must be an integer.' }
        if ($Profile.windows_endpoint_count -lt 1 -or $Profile.windows_endpoint_count -gt 100000) { throw 'Enter the planned number of Windows endpoints.' }
        if ($Profile.retention_days -isnot [int] -and $Profile.retention_days -isnot [long]) { throw 'Retention days must be an integer.' }
        if ($Profile.retention_days -lt 1 -or $Profile.retention_days -gt 3650) { throw 'Retention must be 1 through 3650 days.' }
        $export = $Profile.winlogbeat_relative_path
        if ($export -notmatch '^[a-zA-Z0-9_-]+(?:/[a-zA-Z0-9_. -]+)*$' -or $export.Split('/') -contains '..') { throw 'Winlogbeat output must be a relative folder without traversal.' }
        foreach ($folder in @($Profile.bundle_relative_path,$export)) {
            if (@($folder.Split('/') | Where-Object { $_.EndsWith('.') -or $_.EndsWith(' ') }).Count) { throw 'Share folder names cannot end with a dot or space.' }
        }
        $release = $Profile.bundle_relative_path.TrimEnd('/')
        if ($export.Equals($release,[StringComparison]::OrdinalIgnoreCase) -or $export.StartsWith($release+'/',[StringComparison]::OrdinalIgnoreCase) -or $release.StartsWith($export+'/',[StringComparison]::OrdinalIgnoreCase)) {
            throw 'Keep the generated Winlogbeat folder separate from the source release folder.'
        }
    }
    if ($Profile.schema_version -in @(3,4)) {
        $tlsChoices = @('certutil','provided')
        if ($Profile.schema_version -eq 4) { $tlsChoices += 'csr' }
        if ($Profile.mode -eq 'fresh' -and $Profile.tls_mode -notin $tlsChoices) { throw 'Fresh setup must explicitly select how certificates will be supplied.' }
        if ($Profile.mode -eq 'recovery' -and $Profile.tls_mode -cne 'restore') { throw 'Recovery must preserve the backed-up certificate identity; do not generate a new CA.' }
    }
    if ($Profile.schema_version -eq 4) {
        foreach ($key in @('ca_certificate_relative_path','server_certificates_relative_path')) {
            $path = $Profile[$key]
            if ($path -and ($path -notmatch '^[a-zA-Z0-9_-]+(?:[a-zA-Z0-9_. -]*)(?:/[a-zA-Z0-9_. -]+)*$' -or @($path.Split('/') | Where-Object { $_ -in @('.','..') -or $_.EndsWith('.') -or $_.EndsWith(' ') }).Count)) { throw "$key must be a relative path inside the selected file share, without traversal." }
        }
        if ($Profile.tls_mode -in @('provided','csr')) {
            if (-not $Profile.ca_certificate_relative_path) { throw 'An existing CA selection requires its public certificate path.' }
            if ($Profile.tls_mode -eq 'provided' -and -not $Profile.server_certificates_relative_path) { throw 'Supplied server certificates require their protected folder path.' }
            if ($Profile.tls_mode -eq 'csr' -and $Profile.server_certificates_relative_path) { throw 'CSR mode must not claim signed server certificates are already supplied.' }
        } elseif ($Profile.ca_certificate_relative_path -or $Profile.server_certificates_relative_path) {
            throw 'New-CA generation and backup recovery must not override an existing CA selection.'
        }
    }
    return $true
}

function Get-SingleVmEndpoints {
    param([Parameter(Mandatory)][string]$Hostname)
    $dnsPattern = '^(?=.{1,253}$)(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?$'
    if ($Hostname -notmatch $dnsPattern) { throw 'Hostname must be a fully qualified DNS name.' }
    $name = $Hostname.ToLowerInvariant()
    return [ordered]@{
        elasticsearch_url = "https://${name}:9200"
        kibana_url = "https://${name}:5601"
        fleet_url = "https://${name}:8220"
    }
}

function New-WinlogbeatConfig {
    param([Parameter(Mandatory)][System.Collections.IDictionary]$Profile)
    $null = Test-SiteProfile $Profile
    # Endpoints are validated; authentication is added to each endpoint's keystore.
    @'
# Generated site configuration. Supply the approved public CA as certs/ca.crt.
# Each Windows machine needs its own least-privilege publishing API key.
# Run setup separately with an approved setup identity before deploying publishers.
winlogbeat.event_logs:
  - name: Application
  - name: Security
  - name: System
output.elasticsearch:
  hosts: ["__ELASTICSEARCH__"]
  api_key: "${WINLOGBEAT_API_KEY}"
  pipeline: "winlogbeat-%{[agent.version]}-routing"
  ssl.certificate_authorities: ["${path.config}/certs/ca.crt"]
  ssl.verification_mode: full
setup.template.enabled: false
setup.ilm.enabled: true
setup.ilm.policy_name: "__ILM_POLICY__"
setup.ilm.check_exists: true
setup.ilm.overwrite: false
processors:
  - add_host_metadata: ~
setup.kibana:
  host: "__KIBANA__"
  ssl.certificate_authorities: ["${path.config}/certs/ca.crt"]
  ssl.verification_mode: full
'@.Replace('__ELASTICSEARCH__',$Profile.elasticsearch_url).Replace('__KIBANA__',$Profile.kibana_url).Replace('__ILM_POLICY__',('kit-'+$Profile.site_name.ToLowerInvariant()+'-winlogbeat'))
}

Export-ModuleMember -Function Test-SiteProfile,New-WinlogbeatConfig,Get-SingleVmEndpoints
