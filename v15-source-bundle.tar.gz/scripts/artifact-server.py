#!/usr/libexec/platform-python
"""Allowlisted, read-only HTTPS artifact service (Python 3.6+).

Files and TLS material are supplied locally by the verified release installer.
No proxying, directory indexes, upload handlers or Internet requests exist here.
"""
import argparse
import http.server
import json
import os
import re
import socketserver
import ssl
import stat
from urllib.parse import unquote, urlsplit


def resolve_member(root, relative):
    if not isinstance(relative, str) or not re.match(r'^[A-Za-z0-9_-][A-Za-z0-9_./+\-]*$', relative):
        raise ValueError('Invalid artifact path')
    if any(p in ('', '.', '..') for p in relative.split('/')):
        raise ValueError('Invalid path segment')
    root = os.path.realpath(root)
    current = root
    for part in relative.split('/'):
        current = os.path.join(current, part)
        if os.path.islink(current):
            raise ValueError('Symlinks are not served')
    if os.path.commonpath([root, os.path.realpath(current)]) != root:
        raise ValueError('Path escaped artifact directory')
    mode = os.stat(current).st_mode
    if not stat.S_ISREG(mode):
        raise ValueError('Only regular files are served')
    return current


class ArtifactHandler(http.server.BaseHTTPRequestHandler):
    server_version = 'ElasticKitArtifacts'
    sys_version = ''
    protocol_version = 'HTTP/1.1'

    def do_GET(self):
        self._respond(False)

    def do_HEAD(self):
        self._respond(True)

    def _respond(self, head):
        parsed = urlsplit(self.path)
        if parsed.query or parsed.fragment:
            self.send_error(400)
            return
        if parsed.path == '/healthz':
            data = b'ready\n'
            self.send_response(200)
            self.send_header('Content-Type', 'text/plain')
            self.send_header('Content-Length', str(len(data)))
            self.end_headers()
            if not head:
                self.wfile.write(data)
            return
        path = unquote(parsed.path)
        if not path.startswith('/') or path.startswith('//') or path[1:] not in self.server.allowed:
            self.send_error(404)
            return
        try:
            filename = resolve_member(self.server.root, path[1:])
            length = os.path.getsize(filename)
            if length != self.server.allowed[path[1:]]:
                self.send_error(503)
                return
            start, end, status = 0, length - 1, 200
            value = self.headers.get('Range')
            if value:
                match = re.match(r'^bytes=(\d+)-(\d*)$', value)
                if not match:
                    self.send_error(416)
                    return
                start = int(match.group(1))
                end = int(match.group(2)) if match.group(2) else end
                if start >= length or end >= length or end < start:
                    self.send_error(416)
                    return
                status = 206
            self.send_response(status)
            self.send_header('Content-Type', 'application/octet-stream')
            self.send_header('Content-Length', str(end - start + 1))
            self.send_header('Accept-Ranges', 'bytes')
            self.send_header('X-Content-Type-Options', 'nosniff')
            if status == 206:
                self.send_header('Content-Range', 'bytes {}-{}/{}'.format(start, end, length))
            self.end_headers()
            if not head:
                with open(filename, 'rb') as source:
                    source.seek(start)
                    remaining = end - start + 1
                    while remaining:
                        chunk = source.read(min(1024 * 1024, remaining))
                        if not chunk:
                            break
                        self.wfile.write(chunk)
                        remaining -= len(chunk)
        except (ValueError, OSError):
            self.close_connection = True

    def log_message(self, format_string, *args):
        # Do not write caller-supplied request paths or headers into the journal.
        if len(args) > 1 and str(args[1]).isdigit():
            print('artifact request status={}'.format(args[1]), flush=True)


class ThreadedServer(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True
    request_queue_size = 32


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', required=True)
    args = parser.parse_args()
    with open(args.config) as source:
        config = json.load(source)
    root = config['root']
    allowed = {}
    for entry in config['files']:
        relative = entry['path']
        if relative in allowed:
            raise ValueError('Duplicate artifact')
        filename = resolve_member(root, relative)
        if os.path.getsize(filename) != entry['bytes']:
            raise ValueError('Artifact size mismatch')
        allowed[relative] = entry['bytes']
    server = ThreadedServer((config['bind'], config['port']), ArtifactHandler)
    server.root, server.allowed = root, allowed
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    context.options |= ssl.OP_NO_TLSv1 | ssl.OP_NO_TLSv1_1
    context.load_cert_chain(config['certificate'], config['key'])
    server.socket = context.wrap_socket(server.socket, server_side=True)
    server.serve_forever()


if __name__ == '__main__':
    main()
