#!/usr/bin/python3
"""Validate an authenticated kit recovery tar before native tar extracts it.

Does not extract or execute archive contents. Python 3.6 compatible.
"""
import argparse
import json
import posixpath
import re
import tarfile


def validate(path, expected_version='9.5.4'):
    if expected_version not in ('9.5.3', '9.5.4'):
        raise ValueError('Unreviewed expected backup version')
    with tarfile.open(path, 'r:gz') as archive:
        members = archive.getmembers()
        if len(members) > 250000:
            raise ValueError('Too many archive members')
        entries = {}
        for member in members:
            name = member.name.rstrip('/')
            if (not name or name.startswith('/') or '\\' in name
                    or any(p in ('', '.', '..') for p in name.split('/'))
                    or any(ord(c) < 32 for c in name) or name in entries):
                raise ValueError('Unsafe or duplicate archive path')
            if not (member.isfile() or member.isdir() or member.issym() or member.islnk()):
                raise ValueError('Special files are not allowed in recovery archives')
            entries[name] = member
        record_name = 'var/lib/elastic-kit/recovery-record.json'
        record_member = entries.get(record_name)
        if record_member is None or not record_member.isfile() or record_member.size > 1048576:
            raise ValueError('Missing recovery record')
        record = json.load(archive.extractfile(record_member))
        if record.get('schema_version') != 1 or record.get('version') != expected_version:
            raise ValueError('Unreviewed recovery schema/version')
        data = record.get('data_directory', '')
        repo = record.get('repository_location', '')
        root = record.get('repository_root', '')
        if not re.fullmatch(r'/srv/[A-Za-z0-9_-]+', data):
            raise ValueError('Invalid data root')
        if not re.fullmatch(r'/srv/[A-Za-z0-9_/-]+', root) or '..' in root.split('/'):
            raise ValueError('Invalid repository root')
        if not re.fullmatch(r'[a-z][a-z0-9_-]{1,40}', record.get('repository_name', '')):
            raise ValueError('Invalid repository name')
        if repo != root.rstrip('/') + '/' + record['repository_name']:
            raise ValueError('Repository location mismatch')
        if not re.fullmatch(r'kit-[a-z0-9-]+', record.get('snapshot', '')):
            raise ValueError('Invalid snapshot name')
        if not {'fleet', 'kibana', 'security'}.issubset(set(record.get('feature_states', []))):
            raise ValueError('Recovery record lacks required feature states')
        trees = ['etc/elasticsearch', 'etc/kibana', 'etc/elastic-kit',
                 'etc/systemd/system/elasticsearch.service.d',
                 'etc/systemd/system/kibana.service.d', 'etc/fapolicyd/trust.d',
                 data.lstrip('/') + '/Elastic/Agent', repo.lstrip('/')]
        singles = {record_name, 'var/lib/elastic-kit/install-state.json',
                   'var/lib/elastic-kit/fleet-state.json',
                   'etc/systemd/system/elastic-kit-https.service',
                   'etc/systemd/system/elastic-agent.service',
                   'etc/fapolicyd/fapolicyd-filter.conf', 'etc/sysconfig/elastic-agent'}

        def tree_for(name):
            return next((t for t in trees if name == t or name.startswith(t + '/')), None)

        for name, member in entries.items():
            tree = tree_for(name)
            if tree is None and name not in singles:
                raise ValueError('Archive member is outside the reviewed kit paths')
            parent = posixpath.dirname(name)
            while parent:
                if parent in entries and not entries[parent].isdir():
                    raise ValueError('Archive member traverses a non-directory')
                parent = posixpath.dirname(parent)
            if member.issym() or member.islnk():
                link = member.linkname
                if not link or link.startswith('/') or '\\' in link:
                    raise ValueError('Unsafe archive link')
                target = (posixpath.normpath(posixpath.join(posixpath.dirname(name), link))
                          if member.issym() else posixpath.normpath(link))
                if not tree or tree_for(target) != tree:
                    raise ValueError('Archive link escapes its kit tree')
                if member.islnk() and (target not in entries or not entries[target].isfile()):
                    raise ValueError('Hard link target is not a regular archived file')
        # Native tar extracts only after all entries pass this structural review.
        return {'record': record, 'members': len(members),
                'regular_file_bytes': sum(m.size for m in members if m.isfile())}


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--archive', required=True)
    parser.add_argument('--expected-version', choices=('9.5.3', '9.5.4'), default='9.5.4')
    args = parser.parse_args()
    print(json.dumps(validate(args.archive, args.expected_version), sort_keys=True))
