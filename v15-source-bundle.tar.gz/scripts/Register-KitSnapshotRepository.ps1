#requires -Version 7.2
[CmdletBinding()]
param([Parameter(Mandatory)][string]$SiteProfile,
      [Parameter(Mandatory)][ValidatePattern('^/srv/[A-Za-z0-9_/-]+$')][string]$RepositoryRoot,
      [ValidatePattern('^[a-z][a-z0-9_-]{1,40}$')][string]$RepositoryName='elastic-kit-backups',
      [Parameter(Mandatory)][string]$ExpectedClusterUUID,[switch]$RestartElasticsearch,[switch]$Lab)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
Import-Module (Join-Path $PSScriptRoot 'Kit.Common.psm1') -Force
Assert-KitRoot
$p=Get-Content -Raw $SiteProfile|ConvertFrom-Json -AsHashtable
$identity=(Invoke-KitApi $p -Path '/').Data
if($identity.cluster_uuid -ne $ExpectedClusterUUID){throw 'Cluster UUID mismatch; repository configuration not changed.'}
if($RepositoryRoot.Split('/') -contains '..' -or $RepositoryRoot -match '(^|/)artifacts(/|$)'){throw 'Choose protected backup storage outside the artifact service.'}
if(-not(Test-Path -LiteralPath $RepositoryRoot -PathType Container)){throw 'Prepare and mount the backup filesystem before registering it.'}
if(-not $Lab -and (Invoke-KitNative mountpoint @('-q',$RepositoryRoot) -AllowFailure).ExitCode -ne 0){throw 'Use a separately mounted backup filesystem. Same-disk backups are allowed only for the lab test.'}
$resolved=(Invoke-KitNative realpath @('-e',$RepositoryRoot)).Stdout.Trim()
if($resolved -ne $RepositoryRoot.TrimEnd('/')){throw 'Repository root must not contain symbolic links.'}
$config='/etc/elasticsearch/elasticsearch.yml';$before=[IO.File]::ReadAllText($config)
$line='path.repo: ['+($resolved|ConvertTo-Json -Compress)+']'
$existing=@($before.Split("`n")|Where-Object {$_ -match '^\s*path\.repo\s*:'})
if($existing.Count -and ($existing.Count -ne 1 -or $existing[0].Trim() -ne $line)){throw 'Existing path.repo setting preserved; reconcile it before using this runner.'}
if(-not $existing.Count){
    if(-not $RestartElasticsearch){throw 'Adding path.repo requires a maintenance restart; rerun with -RestartElasticsearch.'}
    $backup='/var/lib/elastic-kit/elasticsearch-before-snapshot-repository.yml'
    if(-not(Test-Path $backup)){Write-KitPrivateFile $backup $before -CreateNew}
    Write-KitPrivateFile $config ($before.TrimEnd()+"`n"+$line+"`n") -Mode '0640'
    $null=Invoke-KitNative chown @('root:elasticsearch',$config)
    $null=Invoke-KitNative restorecon @($config)
}
$location=$resolved+'/'+$RepositoryName
$null=Invoke-KitNative install @('-d','-m','0750','-o','elasticsearch','-g','elasticsearch',$location)
$labels=(Invoke-KitNative semanage @('fcontext','-l','-C')).Stdout
if($labels -notmatch [regex]::Escape($resolved)){$null=Invoke-KitNative semanage @('fcontext','-a','-e','/var/lib/elasticsearch',$resolved)}
$null=Invoke-KitNative restorecon @('-RF',$resolved)
if(-not $existing.Count){
    $paused=@()
    try{
        foreach($service in @('kibana','elastic-agent')){
            if((Invoke-KitNative systemctl @('is-active','--quiet',$service) -AllowFailure).ExitCode -eq 0){
                $paused+=,$service
                $null=Invoke-KitNative systemctl @('stop',$service)
            }
        }
        $null=Invoke-KitNative systemctl @('restart','elasticsearch')
        $null=Wait-KitApi $p es -Seconds 600
    }finally{
        $failed=@()
        foreach($service in $paused){
            if((Invoke-KitNative systemctl @('start',$service) -AllowFailure).ExitCode -ne 0){$failed+=,$service}
        }
        if($failed.Count){Write-Warning ('Services requiring attention: '+($failed -join ', '))}
    }
}
$found=Invoke-KitApi $p -Path ('/_snapshot/'+$RepositoryName) -AllowFailure
if($found.Success -and ($found.Data[$RepositoryName].type -ne 'fs' -or $found.Data[$RepositoryName].settings.location -ne $location)){throw 'Existing repository points elsewhere; preserved.'}
$body=@{type='fs';settings=@{location=$location;compress=$true}}
$null=Invoke-KitApi $p -Method PUT -Path ('/_snapshot/'+$RepositoryName) -Body $body
$verified=(Invoke-KitApi $p -Method POST -Path ('/_snapshot/'+$RepositoryName+'/_verify')).Data
if($verified.nodes.Count -ne 1){throw 'Expected the single kit node to verify the repository.'}
$record=@{schema_version=1;cluster_uuid=$ExpectedClusterUUID;name=$RepositoryName;root=$resolved;location=$location;body=$body;lab=[bool]$Lab}
Write-KitPrivateFile '/etc/elastic-kit/snapshot-repository.json' ($record|ConvertTo-Json -Depth 8)
Write-Host "Registered and verified repository: $RepositoryName"
Write-Host 'Keep a protected copy outside this VM. A second directory on the same disk is not disaster protection.'
