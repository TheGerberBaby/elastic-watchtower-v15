#requires -Version 7.2
[CmdletBinding()]
param([string]$OutputDirectory = '/etc/elastic-kit/site')
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
Import-Module (Join-Path $PSScriptRoot 'SiteProfile.psm1') -Force
if (-not $IsLinux -or (& id -u) -ne '0') { throw 'Run this setup at the RHEL root console.' }
Write-Host 'Offline Elastic site setup'
Write-Host 'This stage records settings and creates the Winlogbeat configuration.'
Write-Host 'It does not yet apply networking, join AD, mount SMB or install Elastic.'
Write-Host 'Do not enter passwords into any of the following fields.'
$profilePath = Join-Path $OutputDirectory 'site.json'
if (Test-Path -LiteralPath $profilePath) { throw "Existing profile preserved: $profilePath. Review it before replacing settings." }
do {
    $prefixText = ''
    $site = [ordered]@{
        schema_version = 4
        topology = 'single-vm'
        site_name = (Read-Host 'What is this site/stack called? (example: site01)').Trim()
        mode = (Read-Host 'Fresh installation or recovery? Enter fresh or recovery').Trim().ToLowerInvariant()
        hostname = (Read-Host 'What is this machine''s full DNS name? (example: elastic01.example.internal)').Trim().ToLowerInvariant()
        ipv4_address = (Read-Host 'What IPv4 address should it use?').Trim()
        ipv4_prefix = 0
        ipv4_gateway = ''
        dns_servers = @()
        ad_domain = ''
        share_unc = ''
        bundle_relative_path = ''
        elasticsearch_url = ''
        kibana_url = ''
        fleet_url = ''
        winlogbeat_relative_path = ''
        windows_endpoint_count = 0
        retention_days = 180
        tls_mode = ''
        ca_certificate_relative_path = ''
        server_certificates_relative_path = ''
    }
    $prefixText = (Read-Host 'What network prefix length? (example: 24)').Trim()
    $prefix = 0
    $null = [int]::TryParse($prefixText,[ref]$prefix)
    $site.ipv4_prefix = $prefix
    $site.ipv4_gateway = (Read-Host 'What is the gateway IPv4 address? (blank for no gateway)').Trim()
    $site.dns_servers = @(((Read-Host 'What are the DNS server IPv4 addresses? Separate with commas') -split ',') | ForEach-Object { $_.Trim() })
    $site.ad_domain = (Read-Host 'Which AD DNS domain will this machine join? (blank to skip)').Trim().ToLowerInvariant()
    $site.share_unc = (Read-Host 'What Windows file share holds the release bundle? (\\server\share)').Trim()
    $site.bundle_relative_path = (Read-Host 'What folder inside that share contains the release? (example: releases/approved01)').Trim().Replace('\','/')
    $site.winlogbeat_relative_path = (Read-Host 'Where inside that share should the ready-to-push Winlogbeat folder go? (example: deployments/site01/Winlogbeat)').Trim().Replace('\','/')
    $endpointCount = 0
    $null = [int]::TryParse((Read-Host 'How many Windows computers will this kit collect from? (planned range: 26-100)').Trim(),[ref]$endpointCount)
    $site.windows_endpoint_count = $endpointCount
    $retentionText = (Read-Host 'How many days should logs stay searchable? (Enter for 180)').Trim()
    if ($retentionText) {
        $retentionDays = 0
        $null = [int]::TryParse($retentionText,[ref]$retentionDays)
        $site.retention_days = $retentionDays
    }
    if ($site.mode -eq 'fresh') {
        do { $hasCa = (Read-Host 'Does this site already have a CA certificate to use? (yes/no)').Trim().ToLowerInvariant() } until ($hasCa -in @('yes','no'))
        if ($hasCa -eq 'yes') {
            $site.ca_certificate_relative_path = (Read-Host 'Where is the public CA certificate inside your file share? (example: pki/site01/ca.crt)').Trim().Replace('\','/')
            do { $hasServerCerts = (Read-Host 'Do you also have server certificates and their matching private keys issued by that CA? (yes/no)').Trim().ToLowerInvariant() } until ($hasServerCerts -in @('yes','no'))
            if ($hasServerCerts -eq 'yes') {
                $site.tls_mode = 'provided'
                $site.server_certificates_relative_path = (Read-Host 'What protected folder inside the share holds those server certificates and keys? (example: protected-pki/site01)').Trim().Replace('\','/')
            } else {
                $site.tls_mode = 'csr'
                Write-Host 'This site needs certificate requests signed by the existing CA. Keep its signing key with the CA administrator.'
                Write-Host 'The kit must wait for signed server certificates; it will not create a replacement CA.'
            }
        } else {
            $site.tls_mode = 'certutil'
            Write-Host 'The kit will generate a unique site CA and server certificates using Elasticsearch certutil.'
        }
    } elseif ($site.mode -eq 'recovery') {
        Write-Host 'Recovery will use backed-up certificates and keys. It must not create a new site CA.'
        $site.tls_mode = 'restore'
    }
    $valid = $false
    try {
        $endpoints = Get-SingleVmEndpoints -Hostname $site.hostname
        foreach ($key in $endpoints.Keys) { $site[$key] = $endpoints[$key] }
        $valid = Test-SiteProfile $site
    } catch { Write-Host $_.Exception.Message -ForegroundColor Yellow }
} until ($valid)

Write-Host ($site | ConvertTo-Json -Depth 5)
if ((Read-Host 'Save these settings? Type SAVE').Trim() -cne 'SAVE') { Write-Host 'Nothing saved.'; exit 0 }
# Only local configuration metadata is saved. Credentials belong in a separate secret flow.
& install -d -m 0700 -- $OutputDirectory
if ($LASTEXITCODE -ne 0) { throw 'Could not create protected site directory.' }
$json = $site | ConvertTo-Json -Depth 5
$stream = [IO.File]::Open($profilePath,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
try {
    $bytes = [Text.Encoding]::UTF8.GetBytes($json + "`n")
    $stream.Write($bytes,0,$bytes.Length)
} finally { $stream.Dispose() }
& chmod 0600 -- $profilePath
if ($LASTEXITCODE -ne 0) { throw 'Could not set site profile permissions.' }
$configPath = Join-Path $OutputDirectory 'winlogbeat.yml'
if (Test-Path -LiteralPath $configPath) { throw 'Existing Winlogbeat configuration preserved; site profile saved.' }
[IO.File]::WriteAllText($configPath,(New-WinlogbeatConfig $site),[Text.UTF8Encoding]::new($false))
& chmod 0600 -- $configPath
if ($LASTEXITCODE -ne 0) { throw 'Could not set configuration permissions.' }
Write-Host "Saved: $profilePath"
Write-Host "Saved: $configPath"
Write-Host 'Configuration captured. Deployment is NOT complete. No credentials or enrolled endpoint state were generated.'
if ($site.tls_mode -eq 'csr') { Write-Host 'Existing CA recorded. The deployment runner will prepare certificate requests and wait for signed certificates.' }
