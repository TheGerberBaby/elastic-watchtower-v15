#requires -Version 7.2
[CmdletBinding()]
param([Parameter(Mandatory)][string]$VendorZip,
      [Parameter(Mandatory)][ValidatePattern('^[A-Fa-f0-9]{128}$')][string]$ExpectedSHA512,
      [Parameter(Mandatory)][string]$OutputDirectory)
$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
if (-not $IsWindows) { throw 'Run this preparation step on Windows; it does not install a service or collect events.' }
Import-Module (Join-Path $PSScriptRoot 'Kit.Common.psm1') -Force
if ((Get-FileHash -LiteralPath $VendorZip -Algorithm SHA512).Hash -ne $ExpectedSHA512) { throw 'Vendor archive hash mismatch.' }
if (Test-Path -LiteralPath $OutputDirectory) { throw 'Existing export preserved.' }
$root='winlogbeat-9.5.4-windows-x86_64'
$zip=[IO.Compression.ZipFile]::OpenRead($VendorZip)
try {
    $seen=[Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
    foreach($entry in $zip.Entries) {
        if (-not $entry.FullName.StartsWith($root+'/') -or $entry.FullName -match '(^|/)\.\.?(/|$)|:|\\|[\x00-\x1f]' -or -not $seen.Add($entry.FullName) -or ((($entry.ExternalAttributes -shr 16) -band 0xF000) -eq 0xA000)) { throw 'Unsafe archive entry.' }
    }
} finally { $zip.Dispose() }
$null=New-Item -ItemType Directory -Path $OutputDirectory
$scratch=Join-Path $OutputDirectory 'vendor-source'
[IO.Compression.ZipFile]::ExtractToDirectory($VendorZip,$scratch)
$vendor=Join-Path $scratch $root
$exe=Join-Path $vendor 'winlogbeat.exe'
$template=Invoke-KitNative $exe @('export','template','--es.version','9.5.4','--path.home',$vendor,'--path.config',$vendor,'--path.data',(Join-Path $OutputDirectory 'runtime-data'),'--path.logs',(Join-Path $OutputDirectory 'runtime-logs'))
$null=$template.Stdout | ConvertFrom-Json -AsHashtable
[IO.File]::WriteAllText((Join-Path $OutputDirectory 'winlogbeat-template.json'),$template.Stdout,[Text.UTF8Encoding]::new($false))
$pipelines=Join-Path $OutputDirectory 'pipelines'
$null=New-Item -ItemType Directory -Path $pipelines
$null=Invoke-KitNative $exe @('export','pipelines','--es.version','9.5.4','--dir',$pipelines,'--path.home',$vendor,'--path.config',$vendor,'--path.data',(Join-Path $OutputDirectory 'runtime-data'),'--path.logs',(Join-Path $OutputDirectory 'runtime-logs'))
$files=@(Get-ChildItem -LiteralPath $pipelines -Recurse -File -Filter '*.json')
if (-not $files.Count) { throw 'Vendor export produced no pipeline JSON files.' }
foreach($file in $files){$null=Get-Content -Raw -LiteralPath $file.FullName | ConvertFrom-Json -AsHashtable}
Write-Output "Exported vendor template and $($files.Count) pipeline files. Include their checked hashes in the release plan."
