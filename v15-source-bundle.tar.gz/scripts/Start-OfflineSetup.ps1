#requires -Version 7.2
[CmdletBinding()]
param()
$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
Import-Module (Join-Path $PSScriptRoot 'Kit.Common.psm1') -Force
Import-Module (Join-Path $PSScriptRoot 'SiteProfile.psm1') -Force
Assert-KitRoot
if($env:SSH_CONNECTION){throw 'Run initial setup at the VM console.'}
if(-not(Test-Path '/var/lib/elastic-kit/v15-payload-ready')){throw 'Embedded payload staging is incomplete; inspect custom-first-boot.service.'}
if(-not(Test-Path '/var/lib/elastic-kit/host-interview-complete')){
    & (Join-Path $PSScriptRoot 'Start-HostSetup.ps1')
}
if(-not(Test-Path '/var/lib/elastic-kit/host-interview-complete')){throw 'Complete the host interview before continuing.'}
$hostSettings=Get-Content -Raw /etc/elastic-kit/host-settings.json | ConvertFrom-Json -AsHashtable
$release='/home/elastic/releases/elastic-kit-9.5.4-e2e'
$releaseHash='04fa5e413b60088c676b6ff414f667bf08828409bb6717f45b73047ebf212ddb'
$null=Read-KitRelease $release $releaseHash -RequireFull
$sitePath='/etc/elastic-kit/site/site.json'
$planPath='/etc/elastic-kit/site/v15-deployment.json'
$null=Invoke-KitNative install @('-d','-m','0700','/etc/elastic-kit/site')
if(-not(Test-Path $sitePath)){
    $siteName=(Read-Host 'Site name (letters, numbers, hyphens)').Trim()
    $count=0; do {$text=Read-Host 'Planned Windows computers';$ok=[int]::TryParse($text,[ref]$count)} until($ok -and $count -ge 1 -and $count -le 100000)
    $days=0; do {$text=Read-Host 'Retention days (Enter for 30)';if(-not $text){$text='30'};$ok=[int]::TryParse($text,[ref]$days)} until($ok -and $days -ge 1 -and $days -le 3650)
    $profile=[ordered]@{schema_version=4;topology='single-vm';site_name=$siteName;mode='fresh';hostname=$hostSettings.hostname;ipv4_address=$hostSettings.ipv4_address;ipv4_prefix=[int]$hostSettings.ipv4_prefix;ipv4_gateway=$hostSettings.ipv4_gateway;dns_servers=@($hostSettings.dns_servers);ad_domain=$hostSettings.ad_domain;share_unc=$hostSettings.share_unc;bundle_relative_path='releases/elastic-kit-9.5.4-e2e';winlogbeat_relative_path='kits/Winlogbeat';windows_endpoint_count=$count;retention_days=$days;tls_mode='certutil';ca_certificate_relative_path='';server_certificates_relative_path=''}
    foreach($entry in (Get-SingleVmEndpoints $profile.hostname).GetEnumerator()){$profile[$entry.Key]=$entry.Value}
    $null=Test-SiteProfile $profile
    Write-Host 'A unique local CA and service certificates will be generated; no internet connection is needed.'
    Write-KitPrivateFile $sitePath ($profile|ConvertTo-Json -Depth 8) -CreateNew
    Write-KitPrivateFile '/etc/elastic-kit/site/winlogbeat.yml' (New-WinlogbeatConfig $profile) -CreateNew
}
$profile=Get-Content -Raw $sitePath | ConvertFrom-Json -AsHashtable
if($profile.hostname -ne $hostSettings.hostname -or $profile.ipv4_address -ne $hostSettings.ipv4_address){throw 'Saved application identity differs from the host; preserve it and review before continuing.'}
if(-not(Test-Path $planPath)){
    $ntp=@(((Read-Host 'Internal NTP servers, separated by commas') -split ',')|ForEach-Object {$_.Trim()}|Where-Object {$_})
    if(-not $ntp.Count -or @($ntp|Where-Object {$_ -notmatch '^[A-Za-z0-9][A-Za-z0-9.-]{0,252}$'}).Count){throw 'Enter valid internal time-server addresses.'}
    Write-Host (Invoke-KitNative firewall-cmd @('--get-active-zones')).Stdout
    $zone=(Read-Host 'Active firewall zone for the LAN connection').Trim()
    if($zone -notmatch '^[A-Za-z0-9_-]+$'){throw 'Invalid firewall zone.'}
    $cidrs=@(((Read-Host 'Allowed operator/client IPv4 networks, comma-separated, e.g. 192.168.1.0/24') -split ',')|ForEach-Object {$_.Trim()})
    foreach($cidr in $cidrs){
        if($cidr -notmatch '^(\d{1,3}\.){3}\d{1,3}/([1-9]|[12][0-9]|3[0-2])$'){throw 'Use explicit IPv4 CIDRs, not /0.'}
        foreach($part in $cidr.Split('/')[0].Split('.')){if([int]$part -gt 255){throw 'Invalid client network.'}}
    }
    $plan=@{profile_sha256=(Get-FileHash $sitePath).Hash;firewall_zone=$zone;allowed_client_cidrs=$cidrs;ntp_servers=$ntp}
    Write-KitPrivateFile $planPath ($plan|ConvertTo-Json -Depth 8) -CreateNew
}
$plan=Get-Content -Raw $planPath | ConvertFrom-Json -AsHashtable
if($plan.profile_sha256 -ne (Get-FileHash $sitePath).Hash){throw 'Saved deployment plan does not match the site profile.'}
$chrony="driftfile /var/lib/chrony/drift`nmakestep 1.0 3`nrtcsync`n"+(@($plan.ntp_servers|ForEach-Object {"server $_ iburst"}) -join "`n")+"`n"
if(-not(Test-Path '/var/lib/elastic-kit/chrony-before-v15.conf')){$null=Invoke-KitNative cp @('-a','/etc/chrony.conf','/var/lib/elastic-kit/chrony-before-v15.conf')}
Write-KitPrivateFile '/etc/chrony.conf' $chrony -Mode '0644'
$null=Invoke-KitNative restorecon @('/etc/chrony.conf')
$null=Invoke-KitNative systemctl @('enable','--now','chronyd')
$null=Invoke-KitNative systemctl @('restart','chronyd')
# Service TLS URLs must resolve locally even before the site's DNS record propagates.
$hosts=[IO.File]::ReadAllText('/etc/hosts')
$marker='# elastic-watchtower-v15'
$line="$($profile.ipv4_address) $($profile.hostname) $marker"
$old=@($hosts.Split("`n")|Where-Object {$_ -like "*$marker*"})
if($old.Count -and ($old.Count -ne 1 -or $old[0].Trim() -cne $line)){throw 'Existing appliance host mapping differs; preserved.'}
if(-not $old.Count){Write-KitPrivateFile '/etc/hosts' ($hosts.TrimEnd()+"`n"+$line+"`n") -Mode '0644';$null=Invoke-KitNative restorecon @('/etc/hosts')}
$null=Invoke-KitNative systemctl @('enable','--now','elastic-epr')
$null=Invoke-KitNative curl @('--fail','--silent','--show-error','--retry','20','--retry-connrefused','--retry-delay','2','--max-time','10','http://127.0.0.1:8080/health')
& (Join-Path $PSScriptRoot 'Install-ElasticKit.ps1') -SiteProfile $sitePath -ReleaseDirectory $release -ExpectedManifestSHA256 $releaseHash -DataDirectory '/srv/elastic-data' -AllowedClientCIDRs $plan.allowed_client_cidrs -FirewallZone $plan.firewall_zone
$null=Invoke-KitNative install @('-d','-m','0700','/home/elastic/kits')
$null=Invoke-KitNative install @('-m','0600','/srv/elastic-data/output/Winlogbeat.zip','/home/elastic/kits/Winlogbeat.zip')
$null=Invoke-KitNative install @('-m','0600','/home/elastic/tools/PSTools.zip','/home/elastic/kits/PSTools.zip')
& (Join-Path $PSScriptRoot 'Set-OperatorLogin.ps1') -SiteProfile $sitePath
& (Join-Path $PSScriptRoot 'Test-ElasticKit.ps1') -SiteProfile $sitePath
Write-Host "Kibana: $($profile.kibana_url)"
Write-Host 'Winlogbeat bundle: /home/elastic/kits/Winlogbeat.zip'
Write-Host 'Microsoft PsExec is in the adjacent PSTools.zip archive; review its included license before using it on Windows.'
Write-Host 'The public CA is /etc/elastic-kit/pki/http-ca/ca.crt; distribute it to clients through your approved trust process.'
Write-Host 'Use New-WinlogbeatKey.ps1 for a separate publishing key per computer.'
