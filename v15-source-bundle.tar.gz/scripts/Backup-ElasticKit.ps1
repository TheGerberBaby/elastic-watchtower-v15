#requires -Version 7.2
<# One encrypted recovery bundle: snapshot repository plus the independently
required configuration, encryption keys, certificates and stopped Agent state.
The recipient private key must be held separately from this VM and this bundle.
#>
[CmdletBinding()]
param([Parameter(Mandatory)][string]$SiteProfile,
      [Parameter(Mandatory)][string]$RecipientCertificate,
      [Parameter(Mandatory)][ValidatePattern('^/srv/[A-Za-z0-9_/-]+$')][string]$OutputDirectory,
      [Parameter(Mandatory)][string]$ExpectedClusterUUID,[switch]$MaintenanceWindow)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
Import-Module (Join-Path $PSScriptRoot 'Kit.Common.psm1') -Force
Assert-KitRoot
if(-not $MaintenanceWindow){throw 'This backup briefly stops Kibana and Fleet Server. Use -MaintenanceWindow during the approved window.'}
if($OutputDirectory -match '(^|/)artifacts(/|$)' -or $OutputDirectory.Split('/') -contains '..'){throw 'Backups cannot enter the public artifact directory.'}
$p=Get-Content -Raw $SiteProfile|ConvertFrom-Json -AsHashtable
$identity=(Invoke-KitApi $p -Path '/').Data
if($identity.cluster_uuid -ne $ExpectedClusterUUID){throw 'Cluster UUID mismatch; no service was stopped.'}
$repo=Get-Content -Raw '/etc/elastic-kit/snapshot-repository.json'|ConvertFrom-Json -AsHashtable
if($repo.cluster_uuid -ne $ExpectedClusterUUID){throw 'Repository journal belongs to another cluster.'}
if($OutputDirectory.StartsWith($repo.root.TrimEnd('/')+'/') -or $repo.location.StartsWith($OutputDirectory.TrimEnd('/')+'/')){throw 'Keep encrypted output and the live snapshot repository in separate directories.'}
$null=Invoke-KitNative openssl @('x509','-in',$RecipientCertificate,'-noout','-checkend','86400')
$public=(Invoke-KitNative openssl @('x509','-in',$RecipientCertificate,'-noout','-text')).Stdout
if($public -notmatch 'Public Key Algorithm: rsaEncryption' -or $public -notmatch 'Public-Key: \((3072|4096|8192) bit\)'){throw 'Use a dedicated RSA recipient certificate with at least 3072 bits.'}
$recipientHash=(Get-FileHash $RecipientCertificate -Algorithm SHA256).Hash.ToLowerInvariant()
$null=Invoke-KitNative '/usr/libexec/platform-python' @('-c','from cryptography.hazmat.primitives.ciphers.aead import AESGCM')
$null=Invoke-KitNative install @('-d','-m','0700',$OutputDirectory)
$id='kit-'+[DateTime]::UtcNow.ToString('yyyyMMdd-HHmmss')+'-'+[Guid]::NewGuid().ToString('N').Substring(0,8)
$folder=$OutputDirectory+'/'+$id
$null=Invoke-KitNative install @('-d','-m','0700',$folder)
$lock=[IO.File]::Open('/var/lib/elastic-kit/backup.lock',[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
$paused=@();$unregistered=$false
try{
    $install=Get-Content -Raw '/var/lib/elastic-kit/install-state.json'|ConvertFrom-Json -AsHashtable
    $agents=(Invoke-KitApi $p -Service kibana -Path '/api/fleet/agents?perPage=100').Data.items
    foreach($service in @('kibana','elastic-agent')){
        if((Invoke-KitNative systemctl @('is-active','--quiet',$service) -AllowFailure).ExitCode -eq 0){$paused+=,$service;$null=Invoke-KitNative systemctl @('stop',$service)}
    }
    $null=Invoke-KitApi $p -Method PUT -Path ('/_snapshot/'+$repo.name) -Body $repo.body
    $null=Invoke-KitApi $p -Method PUT -Path ('/_snapshot/'+$repo.name+'/'+$id) -Body @{include_global_state=$true;metadata=@{kit_backup=$id;site=$p.site_name}}
    $deadline=[DateTime]::UtcNow.AddMinutes(30)
    do{
        $snapshot=(Invoke-KitApi $p -Path ('/_snapshot/'+$repo.name+'/'+$id)).Data.snapshots[0]
        if($snapshot.state -eq 'SUCCESS'){break}
        if($snapshot.state -in @('FAILED','PARTIAL')){throw 'Snapshot did not complete successfully; partial backup preserved.'}
        Start-Sleep 5
    }while([DateTime]::UtcNow -lt $deadline)
    if($snapshot.state -ne 'SUCCESS'){throw 'Snapshot timed out; inspect it before retrying.'}
    foreach($required in @('fleet','kibana','security')){
        if($required -notin @($snapshot.feature_states.feature_name)){throw "Snapshot is missing required feature state: $required"}
    }
    if(-not $snapshot.include_global_state -or $snapshot.shards.failed -ne 0){throw 'Snapshot metadata or shard acceptance failed.'}
    # Repository files are copied only after unregistering this sole writer.
    $null=Invoke-KitApi $p -Method DELETE -Path ('/_snapshot/'+$repo.name)
    $unregistered=$true
    $record=@{schema_version=1;id=$id;snapshot=$id;repository_name=$repo.name;repository_root=$repo.root;repository_location=$repo.location;cluster_uuid=$identity.cluster_uuid;version=$identity.version.number;site=$p.site_name;data_directory=$install.data_directory;release_sha256=$install.release_sha256;recipient_certificate_sha256=$recipientHash;utc=[DateTime]::UtcNow.ToString('o');feature_states=@($snapshot.feature_states.feature_name);fleet_agents=@($agents|ForEach-Object {@{id=$_.id;policy_id=$_.policy_id;status=$_.status}});contains_sensitive_data=$true;acceptance='snapshot-complete-restore-test-required'}
    $recordPath='/var/lib/elastic-kit/recovery-record.json'
    $record.encryption_format='ELKITBK2-AES256GCM-RSAOAEP-SHA256'
    Write-KitPrivateFile $recordPath ($record|ConvertTo-Json -Depth 12)
    $paths=@('etc/elasticsearch','etc/kibana','etc/elastic-kit','etc/systemd/system/elasticsearch.service.d','etc/systemd/system/elastic-kit-https.service','etc/systemd/system/elastic-agent.service','etc/fapolicyd/fapolicyd-filter.conf','etc/fapolicyd/trust.d','var/lib/elastic-kit/install-state.json','var/lib/elastic-kit/fleet-state.json','var/lib/elastic-kit/recovery-record.json',($install.data_directory.TrimStart('/')+'/Elastic/Agent'),$repo.location.TrimStart('/'))
    foreach($optional in @('etc/systemd/system/kibana.service.d','etc/sysconfig/elastic-agent')){if(Test-Path ('/'+$optional)){$paths+=,$optional}}
    $pathsFile='/var/lib/elastic-kit/backup-paths.json'
    Write-KitPrivateFile $pathsFile ($paths|ConvertTo-Json)
    $cipher=$folder+'/recovery.kitbackup'
    $null=Invoke-KitNative '/usr/libexec/platform-python' @((Join-Path $PSScriptRoot 'recovery-crypto.py'),'encrypt-tar','--paths-json',$pathsFile,'--certificate',$RecipientCertificate,'--output',$cipher) -Sensitive -TimeoutSeconds 86400
    $record.ciphertext_sha256=(Get-FileHash $cipher -Algorithm SHA256).Hash.ToLowerInvariant()
    $record.ciphertext_bytes=(Get-Item $cipher).Length
    Write-KitPrivateFile ($folder+'/backup-record.json') ($record|ConvertTo-Json -Depth 12) -CreateNew
    Write-Host "Encrypted recovery bundle: $cipher"
    Write-Host "SHA256: $($record.ciphertext_sha256)"
    Write-Host "Snapshot SUCCESS; feature states: $($record.feature_states -join ', ')"
    Write-Host 'Keep the hash record authenticated and the recipient private key separately. Restore acceptance is still required.'
}finally{
    try{if($unregistered){$null=Invoke-KitApi $p -Method PUT -Path ('/_snapshot/'+$repo.name) -Body $repo.body}}
    finally{
        try{
            $failed=@()
            foreach($service in $paused){
                if((Invoke-KitNative systemctl @('start',$service) -AllowFailure).ExitCode -ne 0){$failed+=,$service}
            }
            if($failed.Count){throw ('Services requiring attention after backup: '+($failed -join ', '))}
        }
        finally{$lock.Dispose()}
    }
}
