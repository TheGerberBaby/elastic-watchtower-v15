#requires -Version 7.2
[CmdletBinding()]
param([Parameter(Mandatory)][string]$SiteProfile,
      [Parameter(Mandatory)][string]$ConnectionUUID,
      [string[]]$NtpServers,
      [switch]$JoinDomain)
$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
Import-Module (Join-Path $PSScriptRoot 'SiteProfile.psm1') -Force
Import-Module (Join-Path $PSScriptRoot 'Kit.Common.psm1') -Force
$profile=Get-Content -Raw -LiteralPath $SiteProfile | ConvertFrom-Json -AsHashtable
$null=Test-SiteProfile $profile
Assert-KitRoot
if ($ConnectionUUID -notmatch '^[0-9a-fA-F-]{36}$') { throw 'Select a connection UUID shown by nmcli connection show.' }
$null=Invoke-KitNative nmcli @('connection','show','uuid',$ConnectionUUID)
$backup='/var/lib/elastic-kit/network-before-'+[DateTime]::UtcNow.ToString('yyyyMMddTHHmmssZ')
$null=Invoke-KitNative install @('-d','-m','0700',$backup)
$null=Invoke-KitNative cp @('-a','/etc/NetworkManager/system-connections',"$backup/")
if(Test-Path '/etc/sysconfig/network-scripts'){$null=Invoke-KitNative cp @('-a','/etc/sysconfig/network-scripts',"$backup/")}
Write-KitPrivateFile "$backup/nmcli.txt" (Invoke-KitNative nmcli @('connection','show','uuid',$ConnectionUUID)).Stdout
# Once the operator selects a site's static settings, cloud-init must not
# replace them with fallback DHCP during a later boot. Keep its other modules.
if(Test-Path '/etc/cloud/cloud.cfg.d'){
    $cloudFile='/etc/cloud/cloud.cfg.d/90-elastic-kit-site.cfg'
    $cloudText="# Elastic kit: preserve operator-selected site settings.`nnetwork:`n  config: disabled`npreserve_hostname: true`n"
    if(Test-Path $cloudFile){
        if([IO.File]::ReadAllText($cloudFile) -cne $cloudText){throw 'Existing kit cloud-init override differs; preserved for review.'}
    }else{Write-KitPrivateFile $cloudFile $cloudText -Mode '0644' -CreateNew}
    $null=Invoke-KitNative restorecon @($cloudFile)
}
$null=Invoke-KitNative hostnamectl @('set-hostname',$profile.hostname)
$args=@('connection','modify','uuid',$ConnectionUUID,'ipv4.method','manual','ipv4.addresses',"$($profile.ipv4_address)/$($profile.ipv4_prefix)",
        'ipv4.gateway',$profile.ipv4_gateway,'ipv4.dns',($profile.dns_servers -join ','),'ipv4.ignore-auto-dns','yes','connection.autoconnect','yes')
$null=Invoke-KitNative nmcli $args
# Apply only the operator-selected connection. IPv6 settings are preserved.
$null=Invoke-KitNative nmcli @('connection','up','uuid',$ConnectionUUID)
if ($NtpServers) {
    foreach ($name in $NtpServers) { if ($name -notmatch '^[A-Za-z0-9][A-Za-z0-9.-]{0,252}$') { throw 'Invalid NTP host.' } }
    $chrony=[IO.File]::ReadAllText('/etc/chrony.conf')
    if ($chrony.Contains('# elastic-kit time sources')) { throw 'Existing managed NTP section preserved; inspect before replacing.' }
    $null=Invoke-KitNative cp @('-a','/etc/chrony.conf',"$backup/chrony.conf")
    # Explicit site time sources replace public server/pool directives.
    $chrony=[regex]::Replace($chrony,'(?m)^\s*(server|pool)\s+[^\r\n]*$','# Previous time source disabled by site setup')
    $chrony+="`n# elastic-kit time sources`n"+(($NtpServers | ForEach-Object { "server $_ iburst" }) -join "`n")+"`n"
    Write-KitPrivateFile '/etc/chrony.conf' $chrony -Mode '0644'
    $null=Invoke-KitNative restorecon @('/etc/chrony.conf')
    $null=Invoke-KitNative systemctl @('restart','chronyd')
}
$null=Invoke-KitNative getent @('ahostsv4',$profile.hostname)
if ($JoinDomain -and $profile.ad_domain) {
    $already=(Invoke-KitNative realm @('list','--name-only')).Stdout.Trim()
    if ($already -and $already -ne $profile.ad_domain) { throw 'Already joined to another domain; existing membership preserved.' }
    if (-not $already) {
        $config=if(Test-Path /etc/realmd.conf){[IO.File]::ReadAllText('/etc/realmd.conf')}else{''}
        if ($config -match '(?m)^\s*\[service\]') {
            if ($config -notmatch '(?m)^\s*automatic-install\s*=\s*no\s*$') { throw 'Set [service] automatic-install = no in /etc/realmd.conf before offline joining.' }
        } else { Write-KitPrivateFile '/etc/realmd.conf' ($config+"`n[service]`nautomatic-install = no`n") -Mode '0644' }
        $null=Invoke-KitNative realm @('discover',$profile.ad_domain)
        $joinUser=(Read-Host 'AD account authorized to join this computer').Trim()
        if ($joinUser -notmatch '^[A-Za-z0-9_.@\\-]{1,200}$') { throw 'Invalid AD account name.' }
        Write-Host 'Enter the AD password only at realm''s protected prompt.'
        & realm join '--client-software=sssd' '--membership-software=adcli' '--user' $joinUser $profile.ad_domain
        if ($LASTEXITCODE -ne 0) { throw 'Domain join failed. No package download was requested by this kit.' }
        $null=Invoke-KitNative realm @('list')
    }
    $loginGroup=(Read-Host 'AD group permitted to sign into this VM').Trim()
    if (-not $loginGroup -or $loginGroup -match '[\r\n\x00]') { throw 'An explicit permitted domain group is required.' }
    $null=Invoke-KitNative realm @('deny','--all')
    $null=Invoke-KitNative realm @('permit','--groups',$loginGroup)
}
Write-Host 'Network changes applied. Verify DNS, domain access and time synchronization before continuing.'
