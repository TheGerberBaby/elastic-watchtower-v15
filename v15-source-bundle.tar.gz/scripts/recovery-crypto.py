#!/usr/libexec/platform-python
"""Bounded-memory authenticated backup envelope; Python cryptography 3.2+.

RSA-OAEP-SHA256 wraps a fresh 256-bit key. Each <=1 MiB AES-GCM record uses
a unique counter nonce, header-bound AAD and a full 128-bit tag. A mandatory
authenticated empty final record detects truncation. Never extract until the
entire envelope, including final record and EOF, has verified successfully.
"""
import argparse
import base64
import hashlib
import json
import os
import struct
import subprocess
import tempfile

from cryptography import x509
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

MAGIC = b'ELKITBK2'
BLOCK = 1024 * 1024
OAEP = padding.OAEP(mgf=padding.MGF1(hashes.SHA256()), algorithm=hashes.SHA256(), label=b'ElasticKitBackupV2')


def read_exact(stream, size):
    value = stream.read(size)
    if len(value) != size:
        raise ValueError('Truncated recovery envelope')
    return value


def private_output(path):
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, 'O_NOFOLLOW', 0)
    return os.fdopen(os.open(path, flags, 0o600), 'wb')


def encrypt(stream, certificate, destination):
    certificate_bytes = open(certificate, 'rb').read()
    public = x509.load_pem_x509_certificate(certificate_bytes, default_backend()).public_key()
    if not isinstance(public, rsa.RSAPublicKey) or public.key_size < 3072:
        raise ValueError('RSA recipient of at least 3072 bits required')
    key = os.urandom(32)
    prefix = os.urandom(4)
    header = {'version': 2, 'cipher': 'AES-256-GCM-RECORDS', 'wrap': 'RSA-OAEP-SHA256',
              'block_bytes': BLOCK, 'nonce_prefix': base64.b64encode(prefix).decode('ascii'),
              'recipient_sha256': hashlib.sha256(certificate_bytes).hexdigest(),
              'wrapped_key': base64.b64encode(public.encrypt(key, OAEP)).decode('ascii')}
    raw = json.dumps(header, sort_keys=True, separators=(',', ':')).encode('ascii')
    preamble = MAGIC + struct.pack('>I', len(raw)) + raw
    aad = hashlib.sha256(preamble).digest()
    aes = AESGCM(key)
    created = False
    try:
        with private_output(destination) as output:
            created = True
            output.write(preamble)
            counter = 0
            while True:
                block = stream.read(BLOCK)
                final = 0 if block else 1
                identity = struct.pack('>QB', counter, final)
                encrypted = aes.encrypt(prefix + struct.pack('>Q', counter), block, aad + identity)
                output.write(struct.pack('>BI', final, len(encrypted)))
                output.write(encrypted)
                if final:
                    break
                counter += 1
            output.flush()
            os.fsync(output.fileno())
    except BaseException:
        if created:
            os.unlink(destination)
        raise


def decrypt(source, certificate, private_key, destination):
    certificate_bytes = open(certificate, 'rb').read()
    private = serialization.load_pem_private_key(open(private_key, 'rb').read(), password=None, backend=default_backend())
    if not isinstance(private, rsa.RSAPrivateKey) or private.key_size < 3072:
        raise ValueError('RSA recovery key of at least 3072 bits required')
    created = False
    try:
        with open(source, 'rb') as stream:
            if read_exact(stream, len(MAGIC)) != MAGIC:
                raise ValueError('Unsupported recovery envelope')
            size = struct.unpack('>I', read_exact(stream, 4))[0]
            if not 1 <= size <= 16384:
                raise ValueError('Invalid recovery header size')
            raw = read_exact(stream, size)
            header = json.loads(raw.decode('ascii'))
            if (header.get('version') != 2 or header.get('cipher') != 'AES-256-GCM-RECORDS'
                    or header.get('wrap') != 'RSA-OAEP-SHA256' or header.get('block_bytes') != BLOCK
                    or header.get('recipient_sha256') != hashlib.sha256(certificate_bytes).hexdigest()):
                raise ValueError('Recovery envelope/recipient mismatch')
            prefix = base64.b64decode(header['nonce_prefix'], validate=True)
            wrapped = base64.b64decode(header['wrapped_key'], validate=True)
            if len(prefix) != 4 or len(wrapped) != private.key_size // 8:
                raise ValueError('Invalid recovery key envelope')
            key = private.decrypt(wrapped, OAEP)
            if len(key) != 32:
                raise ValueError('Invalid recovered key length')
            aes = AESGCM(key)
            aad = hashlib.sha256(MAGIC + struct.pack('>I', size) + raw).digest()
            with private_output(destination) as output:
                created = True
                counter = 0
                while True:
                    final, length = struct.unpack('>BI', read_exact(stream, 5))
                    if final not in (0, 1) or not 16 <= length <= BLOCK + 16:
                        raise ValueError('Invalid recovery record length')
                    if (final and length != 16) or (not final and length == 16):
                        raise ValueError('Invalid final recovery record')
                    identity = struct.pack('>QB', counter, final)
                    plain = aes.decrypt(prefix + struct.pack('>Q', counter), read_exact(stream, length), aad + identity)
                    if final:
                        if plain or stream.read(1):
                            raise ValueError('Trailing recovery data')
                        break
                    output.write(plain)
                    counter += 1
                output.flush()
                os.fsync(output.fileno())
    except BaseException:
        if created:
            os.unlink(destination)
        raise


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('mode', choices=('encrypt-file', 'encrypt-tar', 'decrypt'))
    parser.add_argument('--certificate', required=True)
    parser.add_argument('--key')
    parser.add_argument('--input')
    parser.add_argument('--output', required=True)
    parser.add_argument('--paths-json')
    args = parser.parse_args()
    if os.geteuid() != 0:
        raise ValueError('Root required for recovery operations')
    if args.mode == 'decrypt':
        decrypt(args.input, args.certificate, args.key, args.output)
    elif args.mode == 'encrypt-file':
        with open(args.input, 'rb') as source:
            encrypt(source, args.certificate, args.output)
    else:
        paths = json.load(open(args.paths_json))
        if not isinstance(paths, list) or not paths or any(not isinstance(p, str) or p.startswith('/') or '..' in p.split('/') for p in paths):
            raise ValueError('Invalid backup path inventory')
        command = ['tar', '--xattrs', '--acls', '--selinux', '--exclude=*.sock', '--exclude=*.lock',
                   '--exclude=*.ndjson', '--exclude=*/run/*', '-czf', '-', '-C', '/', '--'] + paths
        with tempfile.TemporaryFile() as errors:
            process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=errors)
            try:
                encrypt(process.stdout, args.certificate, args.output)
                if process.wait() != 0:
                    os.unlink(args.output)
                    raise ValueError('Snapshot/config archive creation failed')
            finally:
                process.stdout.close()
                if process.poll() is None:
                    process.terminate()
                    process.wait()
    print('Authenticated streaming recovery operation completed')


if __name__ == '__main__':
    main()
