#requires -Version 7.2
<# Verify and decrypt a recovery bundle into a new, protected directory only.
This command does not replace service configuration or Elasticsearch data.
#>
[CmdletBinding()]
param([Parameter(Mandatory)][string]$RecoveryBundle,
      [Parameter(Mandatory)][ValidatePattern('^[a-fA-F0-9]{64}$')][string]$ExpectedCiphertextSHA256,
      [Parameter(Mandatory)][string]$RecipientCertificate,
      [Parameter(Mandatory)][string]$RecipientPrivateKey,
      [Parameter(Mandatory)][ValidatePattern('^/srv/[A-Za-z0-9_-]+/recovery-stage-[a-z0-9-]+$')][string]$Destination,
      [switch]$VerifyOnly,
      [ValidateSet('9.5.3','9.5.4')][string]$ExpectedVersion='9.5.4')
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
Import-Module (Join-Path $PSScriptRoot 'Kit.Common.psm1') -Force
Assert-KitRoot
if($ExpectedVersion -eq '9.5.3' -and -not $VerifyOnly){throw '9.5.3 is limited to pre-upgrade backup verification. Its restore path is not accepted.'}
if(Test-Path -LiteralPath $Destination){throw 'Existing recovery staging is preserved. Choose a new destination.'}
if((Get-FileHash -LiteralPath $RecoveryBundle -Algorithm SHA256).Hash -ne $ExpectedCiphertextSHA256){throw 'Ciphertext SHA256 does not match the independently authenticated record.'}
$parent=Split-Path -Parent $Destination
if(-not(Test-Path $parent -PathType Container)){throw 'Prepare the data filesystem first.'}
if((Invoke-KitNative realpath @('-e',$parent)).Stdout.Trim() -ne $parent){throw 'Recovery staging must not traverse links.'}
$null=Invoke-KitNative install @('-d','-m','0700',$Destination)
$plain="$Destination/recovery.tar.gz"
$null=Invoke-KitNative '/usr/libexec/platform-python' @((Join-Path $PSScriptRoot 'recovery-crypto.py'),'decrypt','--input',$RecoveryBundle,'--certificate',$RecipientCertificate,'--key',$RecipientPrivateKey,'--output',$plain) -Sensitive -TimeoutSeconds 86400
$inspection=(Invoke-KitNative '/usr/libexec/platform-python' @((Join-Path $PSScriptRoot 'validate-recovery-archive.py'),'--archive',$plain,'--expected-version',$ExpectedVersion) -Sensitive).Stdout | ConvertFrom-Json -AsHashtable
$record=$inspection.record
if((Get-FileHash $RecipientCertificate -Algorithm SHA256).Hash.ToLowerInvariant() -ne $record.recipient_certificate_sha256){throw 'Recovery recipient certificate does not match the protected record.'}
if($VerifyOnly){
    [IO.File]::Delete($plain)
    $verified=@{schema_version=1;ciphertext_sha256=$ExpectedCiphertextSHA256.ToLowerInvariant();record=$record;members=$inspection.members;regular_file_bytes=$inspection.regular_file_bytes;status='verified-not-extracted'}
    Write-KitPrivateFile "$Destination/verification.json" ($verified|ConvertTo-Json -Depth 14) -CreateNew
    Write-Host "Authenticated and archive-validated: $($record.snapshot); $($inspection.members) members."
    Write-Host 'Verification only: no files extracted or services changed. This does not establish restore acceptance.'
    return
}
$available=[long]((Invoke-KitNative df @('--output=avail','-B1',$Destination)).Stdout.Trim().Split("`n")[-1].Trim())
if($available -lt ([long]$inspection.regular_file_bytes+1GB)){throw 'Insufficient recovery staging space; decrypted archive retained in the protected directory.'}
$tree="$Destination/tree"
$null=Invoke-KitNative install @('-d','-m','0700',$tree)
$null=Invoke-KitNative tar @('--xattrs','--acls','--selinux','--numeric-owner','-xzf',$plain,'-C',$tree) -Sensitive -TimeoutSeconds 900
[IO.File]::Delete($plain)
$stage=@{schema_version=1;ciphertext_sha256=$ExpectedCiphertextSHA256.ToLowerInvariant();tree=$tree;record=$record;members=$inspection.members;regular_file_bytes=$inspection.regular_file_bytes;status='verified-staged-not-restored'}
Write-KitPrivateFile "$Destination/stage.json" ($stage|ConvertTo-Json -Depth 14) -CreateNew
Write-Host "Verified recovery staging: $Destination"
Write-Host "Source site $($record.site), version $($record.version), snapshot $($record.snapshot)"
Write-Host 'No live configuration or Elasticsearch data was replaced.'
