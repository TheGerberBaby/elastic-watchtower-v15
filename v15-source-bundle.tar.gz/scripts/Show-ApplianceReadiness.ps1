$ErrorActionPreference='Stop'
Write-Host ('Embedded payload verified: '+[bool](Test-Path '/var/lib/elastic-kit/v15-payload-ready'))
Write-Host ('Host interview complete: '+[bool](Test-Path '/var/lib/elastic-kit/host-interview-complete'))
Write-Host ('Application setup state exists: '+[bool](Test-Path '/var/lib/elastic-kit/install-state.json'))
Write-Host 'Use Elastic setup / resume in the menu to configure the applications from local files.'
