#requires -Version 7.2
[CmdletBinding()]
param([switch]$FunctionsOnly,[switch]$LineMode)
$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest

function Test-HostIPv4([string]$Value) {
    if($Value -notmatch '^\d{1,3}(\.\d{1,3}){3}$'){return $false}
    foreach($part in $Value.Split('.')){if([int]$part -gt 255){return $false}}
    return $true
}
function Test-HostDnsName([string]$Value) {
    if($Value.Length -gt 253 -or $Value -notmatch '\.'){return $false}
    foreach($label in $Value.Split('.')){if($label -notmatch '^[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?$'){return $false}}
    return $true
}
function Test-HostSettings($Settings) {
    if(-not(Test-HostDnsName $Settings.hostname)){throw 'Use a full hostname such as elastic01.example.internal.'}
    if(-not(Test-HostIPv4 $Settings.ipv4_address)){throw 'Invalid IPv4 address.'}
    $firstOctet=[int]$Settings.ipv4_address.Split('.')[0]
    if($firstOctet -eq 0 -or $firstOctet -eq 127 -or $firstOctet -ge 224){throw 'Use a unicast interface address, not loopback or multicast.'}
    if($Settings.ipv4_prefix -lt 1 -or $Settings.ipv4_prefix -gt 32){throw 'Prefix must be 1 through 32.'}
    if($Settings.ipv4_gateway -and -not(Test-HostIPv4 $Settings.ipv4_gateway)){throw 'Invalid gateway.'}
    if(-not $Settings.dns_servers.Count){throw 'At least one DNS server is required.'}
    foreach($dns in $Settings.dns_servers){if(-not(Test-HostIPv4 $dns)){throw 'Invalid DNS server IPv4 address.'}}
    if($Settings.ad_domain -and -not(Test-HostDnsName $Settings.ad_domain)){throw 'Use the AD DNS domain, such as example.internal.'}
    if($Settings.local_user -and $Settings.local_user -notmatch '^[a-z_][a-z0-9_-]{0,30}$'){throw 'Invalid local account name.'}
    if($Settings.local_user -in @('root','elastic')){throw 'Choose another administrator name; root is preserved and /home/elastic is reserved for the kit.'}
    if($Settings.share_unc -and $Settings.share_unc -notmatch '^\\\\[A-Za-z0-9][A-Za-z0-9.-]*\\[A-Za-z0-9_$.-]+$'){throw 'Use a share root such as \\fileserver.example.internal\software.'}
    if($Settings.mount_point -notmatch '^/mnt/[A-Za-z0-9_-]+$'){throw 'Use a mount directory directly under /mnt.'}
    if($Settings.connection_uuid -notmatch '^[a-fA-F0-9]{8}(-[a-fA-F0-9]{4}){3}-[a-fA-F0-9]{12}$'){throw 'Select a NetworkManager connection UUID from the list.'}
    return $true
}
function Ask-HostValue([string]$Prompt,[string]$Default='') {
    $answer=(Read-Host $(if($Default){"$Prompt [$Default]"}else{$Prompt})).Trim()
    if(-not $answer){return $Default};return $answer
}
function Invoke-HostCommand([string]$Name,[string[]]$Arguments) {
    & $Name @Arguments
    if($LASTEXITCODE -ne 0){throw "$Name failed with exit $LASTEXITCODE. Settings were retained for review/retry."}
}
if($FunctionsOnly){return}
if(-not $IsLinux -or (& id -u) -ne '0'){throw 'Run at the RHEL root console.'}
if($env:SSH_CONNECTION){throw 'Apply initial networking at the VM console, not over SSH.'}
Import-Module (Join-Path $PSScriptRoot 'Kit.Common.psm1') -Force
$settingsPath='/etc/elastic-kit/host-settings.json'
$stateRoot='/var/lib/elastic-kit'
Invoke-HostCommand install @('-d','-m','0700','/etc/elastic-kit',$stateRoot)
$lock=[IO.File]::Open("$stateRoot/host-interview.lock",[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
try {
    Write-Host 'Host setup interview: hostname, static IPv4, DNS, AD and file share.'
    Write-Host 'Passwords are requested only by native password prompts; do not enter them in ordinary questions.'
    Write-Host 'This configures the host. It does not finish Elasticsearch, Kibana, Fleet, EPR or EAR.'
    if(Test-Path $settingsPath){
        $settings=Get-Content -Raw $settingsPath | ConvertFrom-Json -AsHashtable
        $null=Test-HostSettings $settings
        Write-Host "Resuming saved answers: $settingsPath"
    }else{
        Import-Module (Join-Path $PSScriptRoot 'HostInterview.psm1') -Force
        $settings=Read-FriendlyHostSettings -LineMode:$LineMode
        if($null -eq $settings){Write-Host 'Setup canceled. No settings were saved or applied.';return}
        $null=Test-HostSettings $settings
        Write-Host ($settings | ConvertTo-Json -Depth 5)
        if((Read-Host 'Save these answers? Type SAVE') -cne 'SAVE'){return}
        Write-KitPrivateFile $settingsPath ($settings | ConvertTo-Json -Depth 5) -CreateNew
    }
    Write-Host ($settings | ConvertTo-Json -Depth 5)
    Write-Host 'Applying changes will change this host name and the selected network connection. Use the VM console.'
    if((Read-Host 'Apply host settings now? Type APPLY, or Enter to keep the answers for later') -cne 'APPLY'){return}
    $networkMarker="$stateRoot/host-network-applied.json"
    $settingsHash=(Get-FileHash $settingsPath -Algorithm SHA256).Hash
    if(Test-Path $networkMarker){
        $previous=Get-Content -Raw $networkMarker | ConvertFrom-Json
        if($previous.settings_sha256 -ne $settingsHash){throw 'Settings changed since network application. Review the saved backup before proceeding.'}
        Write-Host 'Network settings were already applied. Preserving them.'
    }else{
        $oldPager=$env:PAGER
        try{$env:PAGER='cat';Invoke-HostCommand nmcli @('connection','show','uuid',$settings.connection_uuid)}
        finally{$env:PAGER=$oldPager}
        $backup="$stateRoot/host-network-before-"+[guid]::NewGuid().ToString('N')
        Invoke-HostCommand install @('-d','-m','0700',$backup)
        foreach($path in @('/etc/NetworkManager/system-connections','/etc/sysconfig/network-scripts','/etc/hostname','/etc/cloud/cloud.cfg.d')){
            if(Test-Path $path){Invoke-HostCommand cp @('-a',$path,$backup)}
        }
        Write-Host "Network backup: $backup"
        if(Test-Path '/etc/cloud/cloud.cfg.d'){
            $cloud='/etc/cloud/cloud.cfg.d/90-elastic-kit-site.cfg'
            $text="# Elastic kit: preserve operator-selected site settings.`nnetwork:`n  config: disabled`npreserve_hostname: true`n"
            if(Test-Path $cloud){if([IO.File]::ReadAllText($cloud) -cne $text){throw 'Existing cloud-init override differs; preserved.'}}
            else{Write-KitPrivateFile $cloud $text -Mode '0644' -CreateNew}
            Invoke-HostCommand restorecon @($cloud)
        }
        Invoke-HostCommand hostnamectl @('set-hostname',$settings.hostname)
        Invoke-HostCommand nmcli @('connection','modify','uuid',$settings.connection_uuid,'ipv4.method','manual','ipv4.addresses',"$($settings.ipv4_address)/$($settings.ipv4_prefix)",'ipv4.gateway',$settings.ipv4_gateway,'ipv4.dns',($settings.dns_servers -join ','),'ipv4.ignore-auto-dns','yes','connection.autoconnect','yes')
        Invoke-HostCommand nmcli @('connection','up','uuid',$settings.connection_uuid)
        Write-KitPrivateFile $networkMarker (@{settings_sha256=$settingsHash;backup=$backup;applied_utc=[datetime]::UtcNow.ToString('o')} | ConvertTo-Json) -CreateNew
    }
    if($settings.local_user){
        $accountMarker="$stateRoot/interview-created-account.json"
        & id $settings.local_user 2>$null
        if($LASTEXITCODE -eq 0){
            if(Test-Path $accountMarker){
                $created=Get-Content -Raw $accountMarker | ConvertFrom-Json
                $actualUid=(& id -u $settings.local_user).Trim()
                if($created.name -eq $settings.local_user -and $created.uid -eq $actualUid -and (Read-Host 'Retry password setup for the account created by this interview? Type PASSWORD') -ceq 'PASSWORD'){
                    Invoke-HostCommand passwd @($settings.local_user)
                }else{Write-Host 'Existing account preserved.'}
            }else{Write-Host 'Existing local account preserved; its password and groups were not changed.'}
        }
        elseif((Read-Host "Create local administrator $($settings.local_user) with wheel membership? Type CREATE") -ceq 'CREATE'){
            Invoke-HostCommand useradd @('--create-home','--groups','wheel','--shell','/bin/bash',$settings.local_user)
            Write-KitPrivateFile $accountMarker (@{name=$settings.local_user;uid=(& id -u $settings.local_user).Trim()} | ConvertTo-Json) -CreateNew
            Write-Host 'Set this new account password at the protected passwd prompts.'
            Invoke-HostCommand passwd @($settings.local_user)
            Invoke-HostCommand restorecon @('-RF',"/home/$($settings.local_user)")
        }
    }
    if($settings.ad_domain -and (Read-Host 'Join the AD realm now? Type JOIN, or Enter to defer') -ceq 'JOIN'){
        $domains=@(& realm list --name-only)
        if($LASTEXITCODE -ne 0){throw 'Could not inspect domain membership.'}
        if($domains.Count -and $settings.ad_domain -notin $domains){throw 'Existing domain membership preserved.'}
        if($settings.ad_domain -notin $domains){
            $realmd='/etc/realmd.conf'
            $text=if(Test-Path $realmd){[IO.File]::ReadAllText($realmd)}else{''}
            if($text -match '(?m)^\s*\[service\]'){
                if($text -notmatch '(?m)^\s*automatic-install\s*=\s*no\s*$'){throw 'Offline join requires automatic-install = no in the [service] section of /etc/realmd.conf.'}
            }else{Write-KitPrivateFile $realmd ($text+"`n[service]`nautomatic-install = no`n") -Mode '0644'}
            Invoke-HostCommand realm @('discover',$settings.ad_domain)
            $adUser=Ask-HostValue 'AD username allowed to join this computer'
            if($adUser -notmatch '^[A-Za-z0-9_.@\\-]{1,200}$'){throw 'Invalid AD username.'}
            Write-Host 'Enter the AD password only at the protected realm prompt.'
            Invoke-HostCommand realm @('join','--client-software=sssd','--membership-software=adcli','--user',$adUser,$settings.ad_domain)
            Invoke-HostCommand realm @('deny','--all')
            Write-Host 'Joined; domain login is denied until an explicit group is permitted.'
        }
        $group=Ask-HostValue 'Which AD group may sign in? Blank preserves current login restrictions'
        if($group){
            if($group -match '[\r\n\x00]' -or $group.StartsWith('-')){throw 'Invalid group.'}
            Invoke-HostCommand realm @('permit','--groups',$group)
        }
    }
    if($settings.share_unc){
        Write-Host 'This FIPS image uses Kerberos SMB authentication. No password file or NTLM fallback is created.'
        Write-Host 'A working Kerberos ticket/upcall configuration must already exist; a domain join alone may not provide one.'
        if((Read-Host 'Attempt a temporary read-only Kerberos share mount? Type MOUNT, or Enter to defer') -ceq 'MOUNT'){
            & mountpoint -q $settings.mount_point
            if($LASTEXITCODE -eq 0){Write-Host 'Existing mount preserved.'}
            else{
                Invoke-HostCommand install @('-d','-m','0700',$settings.mount_point)
                if(@(Get-ChildItem -Force $settings.mount_point).Count){throw 'Mount directory is not empty.'}
                Invoke-HostCommand mount @('-t','cifs',$settings.share_unc.Replace('\','/'),$settings.mount_point,'-o','vers=3.1.1,sec=krb5i,seal,ro,nosuid,nodev,noexec,cruid=0')
                Write-Host 'Temporary read-only mount created. It is not persisted in fstab.'
            }
        }
    }
    if((Read-Host 'Finish this host interview? Type DONE; deferred AD/share work will remain pending') -ceq 'DONE'){
        Write-KitPrivateFile "$stateRoot/host-interview-complete" ([datetime]::UtcNow.ToString('o'))
    }
    & (Join-Path $PSScriptRoot 'Show-ApplianceReadiness.ps1')
}finally{$lock.Dispose()}
