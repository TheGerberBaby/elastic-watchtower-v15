Set-StrictMode -Version Latest

function Test-FormIPv4([string]$Value) {
    if ($Value -notmatch '^(0|[1-9][0-9]{0,2})(\.(0|[1-9][0-9]{0,2})){3}$') { return $false }
    $parts=@($Value.Split('.') | ForEach-Object { [int]$_ })
    return @($parts | Where-Object { $_ -gt 255 }).Count -eq 0 -and $parts[0] -gt 0 -and $parts[0] -lt 224 -and $parts[0] -ne 127
}
function Test-FormName([string]$Value) {
    if (-not $Value -or $Value.Length -gt 253) { return $false }
    foreach ($label in $Value.Split('.')) { if ($label -notmatch '^[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?$') { return $false } }
    return $true
}
function ConvertTo-FormIPv4Number([string]$Value) {
    [long]$number=0
    foreach ($part in $Value.Split('.')) { $number=$number*256+[int]$part }
    return $number
}
function Get-HostFormErrors([System.Collections.IDictionary]$Values, [object[]]$Adapters) {
    $errors=[ordered]@{}
    if ($Values.adapter -notin @($Adapters | ForEach-Object { $_.device })) { $errors.adapter='Choose one of the detected network adapters.' }
    $fqdn=$Values.hostname
    if ($fqdn -and -not $fqdn.Contains('.')) { $fqdn="$fqdn.$($Values.suffix)" }
    if (-not (Test-FormName $Values.hostname)) { $errors.hostname='Enter a computer name using letters, digits and hyphens.' }
    elseif (-not (Test-FormName $fqdn) -or -not $fqdn.Contains('.')) { $errors.suffix='Enter a DNS suffix for the short computer name.' }
    if (-not (Test-FormIPv4 $Values.ip)) { $errors.ip='Enter the address assigned to this appliance; no IP is preselected.' }
    if ($Values.prefix -notmatch '^([1-9]|[12][0-9]|30)$') { $errors.prefix='Enter a subnet prefix from 1 to 30 (24 = 255.255.255.0).' }
    if (-not $errors.Contains('ip') -and -not $errors.Contains('prefix')) {
        [long]$size=[math]::Pow(2,32-[int]$Values.prefix)
        [long]$address=ConvertTo-FormIPv4Number $Values.ip
        [long]$offset=$address % $size
        if ($offset -eq 0 -or $offset -eq ($size-1)) { $errors.ip='This is a subnet or broadcast address. Choose a host address.' }
        if ($Values.gateway) {
            if (-not (Test-FormIPv4 $Values.gateway)) { $errors.gateway='Enter a valid gateway, or leave blank for an isolated LAN.' }
            else {
                [long]$gw=ConvertTo-FormIPv4Number $Values.gateway
                if ([math]::Floor($gw/$size) -ne [math]::Floor($address/$size) -or $gw % $size -in @(0,($size-1)) -or $gw -eq $address) { $errors.gateway='Gateway must be a different usable address in this subnet.' }
            }
        }
    }
    $dns=@($Values.dns.Split(',') | ForEach-Object { $_.Trim() })
    if ($dns.Count -lt 1 -or $dns.Count -gt 3 -or @($dns | Where-Object { -not (Test-FormIPv4 $_) }).Count) { $errors.dns='Enter one to three DNS server addresses, separated by commas.' }
    if ($Values.ad -and (-not (Test-FormName $Values.ad) -or -not $Values.ad.Contains('.'))) { $errors.ad='Use the AD DNS domain, or leave blank to skip AD.' }
    if ($Values.user -and ($Values.user -in @('root','elastic') -or $Values.user -notmatch '^[a-z_][a-z0-9_-]{0,30}$')) { $errors.user='Choose a local username other than root or elastic, or leave blank.' }
    if ($Values.share -and $Values.share -notmatch '^\\\\[A-Za-z0-9][A-Za-z0-9.-]*\\[A-Za-z0-9_$.-]+$') { $errors.share='Use a share root: \\server\share. Leave blank to skip.' }
    if ($Values.mount -notmatch '^/mnt/[A-Za-z0-9_-]+$') { $errors.mount='Use a directory directly under /mnt.' }
    return $errors
}
function ConvertFrom-HostForm([System.Collections.IDictionary]$Values,[object[]]$Adapters) {
    $errors=Get-HostFormErrors $Values $Adapters
    if ($errors.Count) { throw ($errors.Values -join ' ') }
    $name=$Values.hostname
    if (-not $name.Contains('.')) { $name="$name.$($Values.suffix)" }
    $adapter=@($Adapters | Where-Object { $_.device -eq $Values.adapter })[0]
    return @{schema_version=1;connection_uuid=$adapter.uuid;hostname=$name.ToLowerInvariant();ipv4_address=$Values.ip;ipv4_prefix=[int]$Values.prefix;ipv4_gateway=$Values.gateway;dns_servers=@($Values.dns.Split(',') | ForEach-Object { $_.Trim() });ad_domain=$Values.ad.ToLowerInvariant();local_user=$Values.user;share_unc=$Values.share;mount_point=$Values.mount}
}

# This reducer edits only in-memory text. Applying network/account changes remains
# in Start-HostSetup after its separate SAVE and APPLY confirmations.
function Update-HostFormKey([hashtable]$State,[ConsoleKeyInfo]$Key,[string[]]$Ids,[string[]]$AdapterNames) {
    $count=$Ids.Count+2 # Review and Cancel are keyboard-focusable controls.
    $shift=($Key.Modifiers -band [ConsoleModifiers]::Shift) -ne 0
    $control=($Key.Modifiers -band [ConsoleModifiers]::Control) -ne 0
    if ($Key.Key -eq 'Escape' -or ($control -and $Key.Key -eq 'C')) { return 'cancel' }
    if ($Key.Key -eq 'F10') { return 'review' }
    $direction=0
    if ($Key.Key -eq 'Tab') { $direction=if ($shift) {-1} else {1} }
    elseif ($Key.Key -eq 'UpArrow') { $direction=-1 }
    elseif ($Key.Key -eq 'DownArrow') { $direction=1 }
    elseif ($Key.Key -eq 'Enter') {
        if ($State.focus -eq $Ids.Count) { return 'review' }
        if ($State.focus -eq ($Ids.Count+1)) { return 'cancel' }
        $direction=1
    }
    if ($direction) {
        $State.focus=($State.focus+$direction+$count) % $count
        $State.cursor=if ($State.focus -lt $Ids.Count) { $State.values[$Ids[$State.focus]].Length } else {0}
        return 'edit'
    }
    if ($State.focus -ge $Ids.Count) { return 'edit' }
    $id=$Ids[$State.focus]; $value=[string]$State.values[$id]
    if ($id -eq 'adapter') {
        if ($Key.Key -in @('LeftArrow','RightArrow','Spacebar')) {
            $index=[array]::IndexOf($AdapterNames,$value)
            $step=if ($Key.Key -eq 'LeftArrow') {-1} else {1}
            $State.values[$id]=$AdapterNames[($index+$step+$AdapterNames.Count) % $AdapterNames.Count]
            $State.cursor=0
        }
        return 'edit'
    }
    $State.cursor=[math]::Min($State.cursor,$value.Length)
    switch ($Key.Key.ToString()) {
        'LeftArrow' { $State.cursor=[math]::Max(0,$State.cursor-1) }
        'RightArrow' { $State.cursor=[math]::Min($value.Length,$State.cursor+1) }
        'Home' { $State.cursor=0 }
        'End' { $State.cursor=$value.Length }
        'Backspace' { if ($State.cursor -gt 0) { $State.values[$id]=$value.Remove($State.cursor-1,1); $State.cursor-- } }
        'Delete' { if ($State.cursor -lt $value.Length) { $State.values[$id]=$value.Remove($State.cursor,1) } }
        default {
            if ($control -and $Key.Key -eq 'U') { $State.values[$id]='';$State.cursor=0 }
            elseif (-not $control -and [int]$Key.KeyChar -ge 32 -and [int]$Key.KeyChar -le 126 -and $value.Length -lt 512) {
                $State.values[$id]=$value.Insert($State.cursor,[string]$Key.KeyChar);$State.cursor++
            }
        }
    }
    return 'edit'
}

function Read-TabbedHostSettings([object[]]$Adapters) {
    if ([Console]::IsInputRedirected -or [Console]::IsOutputRedirected) { throw 'Use the VM console for the form, or run Start-HostSetup.ps1 -LineMode.' }
    if (-not $Adapters.Count) { throw 'No connected network adapter found.' }
    $fields=@(
        @('adapter','Network adapter','Left/Right or Space selects an adapter; Tab moves to the next field.'),
        @('hostname','Computer name','Enter a short name plus DNS suffix below, or a full hostname.'),
        @('suffix','DNS suffix','Required for a short name. Use the DNS domain for your actual site.'),
        @('ip','IPv4 address','Required. Enter the unused address assigned to this appliance.'),
        @('prefix','Subnet prefix','Required. 24 means 255.255.255.0. Supported range: 1 through 30.'),
        @('gateway','Gateway (optional)','Blank means no default route. Otherwise use a gateway in this subnet.'),
        @('dns','DNS server(s)','Required. One to three IPv4 addresses separated by commas. AD needs AD DNS.'),
        @('ad','AD domain (optional)','Blank skips AD. Joining later requires working DNS/time and join credentials.'),
        @('user','Local admin (optional)','Blank keeps existing accounts. Password is requested separately.'),
        @('share','Share (optional)','Optional share root, such as \\fileserver\software. Blank skips mounting.'),
        @('mount','Mount directory','Directory directly under /mnt; used only when a share is requested.')
    )
    [string[]]$ids=@($fields | ForEach-Object { $_[0] })
    $values=@{};foreach ($id in $ids) { $values[$id]='' }
    $values.adapter=$Adapters[0].device;$values.prefix='24';$values.mount='/mnt/elastic-kit-share'
    $state=@{values=$values;focus=0;cursor=0};$errors=[ordered]@{}
    $oldControl=[Console]::TreatControlCAsInput
    $oldForeground=[Console]::ForegroundColor;$oldBackground=[Console]::BackgroundColor
    try {
        [Console]::TreatControlCAsInput=$true
        [Console]::Clear()
        while ($true) {
            $width=[Console]::WindowWidth;$height=[Console]::WindowHeight
            if ($width -lt 80 -or $height -lt 24) { throw 'The setup form needs an 80x24 console. Enlarge it, or use -LineMode.' }
            [Console]::SetCursorPosition(0,0)
            [Console]::WriteLine('Elastic appliance - host setup')
            [Console]::WriteLine('Tab/Shift+Tab: move   F10: review   Esc: cancel   Ctrl+U: clear field')
            [Console]::WriteLine('Nothing is applied until you review and confirm after this form.')
            $fieldWidth=$width-28
            for ($i=0;$i -lt $fields.Count;$i++) {
                $id=$ids[$i];$value=$state.values[$id];$active=$i -eq $state.focus
                $start=if ($active) { [math]::Max(0,$state.cursor-$fieldWidth+1) } else {0}
                $visible=$value.Substring([math]::Min($start,$value.Length))
                if ($visible.Length -gt $fieldWidth) { $visible=$visible.Substring(0,$fieldWidth) }
                $mark=if ($errors.Contains($id)) {'!'} else {' '}
                [Console]::Write("$mark "+$fields[$i][1].PadRight(23))
                if ($active) { [Console]::BackgroundColor='DarkCyan';[Console]::ForegroundColor='White' }
                [Console]::Write($visible.PadRight($fieldWidth))
                [Console]::BackgroundColor=$oldBackground;[Console]::ForegroundColor=$oldForeground
                [Console]::WriteLine()
            }
            [Console]::WriteLine()
            [Console]::WriteLine($(if ($state.focus -eq $ids.Count) {'> [ Review ]    [ Cancel ]'} elseif ($state.focus -eq ($ids.Count+1)) {'  [ Review ]  > [ Cancel ]'} else {'  [ Review ]    [ Cancel ]'}).PadRight($width-1))
            $helpRow=[Console]::CursorTop
            for($row=$helpRow;$row -lt $height-1;$row++){
                [Console]::SetCursorPosition(0,$row);[Console]::Write(' '*($width-1))
            }
            [Console]::SetCursorPosition(0,$helpRow)
            $hint=if ($state.focus -lt $ids.Count) { $fields[$state.focus][2] } else {'Press Enter to activate the selected button.'}
            $errorText=if ($state.focus -lt $ids.Count -and $errors.Contains($ids[$state.focus])) { $errors[$ids[$state.focus]] } else {''}
            # Wrap help/error text without truncating validation instructions.
            foreach ($line in @($hint,$errorText)) {
                for ($offset=0;$offset -lt $line.Length;$offset+=($width-1)) { [Console]::WriteLine($line.Substring($offset,[math]::Min($width-1,$line.Length-$offset))) }
            }
            if ($state.focus -lt $ids.Count) {
                $cursor=[math]::Min($state.cursor,$fieldWidth-1)
                [Console]::SetCursorPosition(25+$cursor,3+$state.focus)
            }
            $action=Update-HostFormKey $state ([Console]::ReadKey($true)) $ids @($Adapters | ForEach-Object { $_.device })
            if ($action -eq 'cancel') { return $null }
            if ($action -eq 'review') {
                foreach ($id in $ids) { $state.values[$id]=$state.values[$id].Trim() }
                $errors=Get-HostFormErrors $state.values $Adapters
                if (-not $errors.Count) { return (ConvertFrom-HostForm $state.values $Adapters) }
                $state.focus=[array]::IndexOf($ids,@($errors.Keys)[0]);$state.cursor=$state.values[$ids[$state.focus]].Length
            }
        }
    } finally {
        [Console]::TreatControlCAsInput=$oldControl
        [Console]::ForegroundColor=$oldForeground;[Console]::BackgroundColor=$oldBackground
        [Console]::Clear()
    }
}
Export-ModuleMember -Function Read-TabbedHostSettings,Get-HostFormErrors,ConvertFrom-HostForm,Update-HostFormKey
