#requires -Version 7.2
<# ENGINEERING: exact offline 9.5.3 -> 9.5.4 transition, pending runtime acceptance.
Uses the vendor Fleet upgrade API. Never downgrades or rewrites enrollment.
This command is intentionally gated until its complete transition is accepted.
#>
[CmdletBinding()]
param([Parameter(Mandatory)][string]$SiteProfile,
      [Parameter(Mandatory)][string]$ReleaseDirectory,
      [Parameter(Mandatory)][ValidatePattern('^[a-fA-F0-9]{64}$')][string]$ExpectedManifestSHA256,
      [Parameter(Mandatory)][string]$ExpectedClusterUUID,
      [Parameter(Mandatory)][string]$RecoveryBundle,
      [Parameter(Mandatory)][ValidatePattern('^[a-fA-F0-9]{64}$')][string]$ExpectedCiphertextSHA256,
      [Parameter(Mandatory)][string]$RecipientCertificate,
      [Parameter(Mandatory)][string]$RecipientPrivateKey,
      [switch]$MaintenanceWindow,[switch]$BackupCopiedOffVm,[switch]$EngineeringTest)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
if(-not $EngineeringTest){throw 'This upgrade transition is still awaiting lab acceptance. Do not use it for site deployment.'}
if(-not $MaintenanceWindow -or -not $BackupCopiedOffVm){throw 'A maintenance window and an independently verified off-VM recovery copy are required.'}
Import-Module (Join-Path $PSScriptRoot 'Kit.Common.psm1') -Force
Assert-KitRoot
$p=Get-Content -Raw -LiteralPath $SiteProfile|ConvertFrom-Json -AsHashtable
$release=Read-KitRelease $ReleaseDirectory $ExpectedManifestSHA256 -RequireFull
if($release.Manifest.version -ne '9.5.4'){throw 'Only the exact 9.5.3 to 9.5.4 transition is implemented.'}
$identity=(Invoke-KitApi $p -Path '/').Data
if($identity.cluster_uuid -cne $ExpectedClusterUUID -or $identity.version.number -ne '9.5.3'){throw 'Expected source UUID/version differs. Reinstallation and downgrade are refused.'}
$installPath='/var/lib/elastic-kit/install-state.json'
$install=Get-Content -Raw $installPath|ConvertFrom-Json -AsHashtable
if(-not $install.Contains('lab') -or -not $install.lab){throw 'The unaccepted engineering transition is restricted to an explicitly provisioned lab kit.'}
$data=$install.data_directory
if($data -notmatch '^/srv/[A-Za-z0-9_-]+$' -or $install.version -ne '9.5.3' -or $install.profile_sha256 -ne (Get-FileHash $SiteProfile -Algorithm SHA256).Hash){throw 'Source installation ownership does not match.'}
$health=(Invoke-KitApi $p -Path '/_cluster/health').Data
if($health.number_of_nodes -ne 1 -or $health.status -eq 'red'){throw 'This runner requires one healthy kit node.'}
foreach($package in @('elasticsearch','kibana')){
    if((Invoke-KitNative rpm @('-q','--qf','%{VERSION}',$package)).Stdout.Trim() -ne '9.5.3'){throw 'Both RPMs must start at 9.5.3.'}
    if(@(Get-ChildItem -LiteralPath "/usr/share/$package/plugins" -Force -ErrorAction Stop).Count){throw 'Additional plugins require their own reviewed upgrade inputs.'}
    $rpm=$release.Roles[$package+'_rpm'][0].full_path
    if((Invoke-KitNative rpm @('-qp','--qf','%{NAME}|%{VERSION}|%{ARCH}',$rpm)).Stdout.Trim() -ne "$package|9.5.4|x86_64"){throw 'Target RPM identity mismatch.'}
    if((Invoke-KitNative rpm @('--checksig',$rpm)).Stdout -notmatch 'signatures OK'){throw 'Target RPM signature is not trusted.'}
}
$rpms=@($release.Roles.elasticsearch_rpm[0].full_path,$release.Roles.kibana_rpm[0].full_path)
$null=Invoke-KitNative rpm (@('-Uvh','--test')+$rpms)
foreach($path in @('/',$data)){
    $free=[long]((Invoke-KitNative df @('--output=avail','-B1',$path)).Stdout.Trim().Split("`n")[-1].Trim())
    $required=if($path -eq $data){6GB}else{3GB}
    if($free -lt $required){throw "Insufficient free space on $path before this lab transition."}
}
if((Invoke-KitNative getenforce).Stdout.Trim() -ne 'Enforcing'){throw 'SELinux must remain enforcing.'}
foreach($service in @('fapolicyd','firewalld','auditd','elasticsearch','kibana','elastic-agent','elastic-kit-https')){$null=Invoke-KitNative systemctl @('is-active','--quiet',$service)}
$fleet=(Invoke-KitApi $p -Service kibana -Path '/api/fleet/agents?perPage=100').Data.items
$server=@($fleet|Where-Object {$_.policy_id -eq 'elastic-kit-server' -and $_.status -eq 'online'})
if($server.Count -ne 1 -or $server[0].local_metadata.elastic.agent.version -ne '9.5.3'){throw 'Expected exactly one online 9.5.3 kit Fleet Server.'}
$agentId=$server[0].id
if($agentId -notmatch '^[a-fA-F0-9-]{36}$'){throw 'Unexpected Fleet Agent ID.'}
$beforeCount=(Invoke-KitApi $p -Path '/winlogbeat-*/_count').Data.count
$journal='/var/lib/elastic-kit/upgrade-state.json'
if(Test-Path $journal){throw 'An earlier upgrade journal is preserved. Inspect it; do not blindly repeat an interrupted upgrade.'}
$lock=[IO.File]::Open('/var/lib/elastic-kit/install.lock',[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
$id=[DateTime]::UtcNow.ToString('yyyyMMdd-HHmmss')+'-'+[Guid]::NewGuid().ToString('N').Substring(0,8)
$state=@{schema_version=1;status='preparing';source_version='9.5.3';target_version='9.5.4';cluster_uuid=$ExpectedClusterUUID;fleet_agent_id=$agentId;release_sha256=$release.SHA256;backup_sha256=$ExpectedCiphertextSHA256;completed=@();current='backup-verification';windows_events_before=$beforeCount}
function Save-State {Write-KitPrivateFile $journal ($state|ConvertTo-Json -Depth 15)}
function Step([string]$Name,[scriptblock]$Action){$state.current=$Name;Save-State;Write-Host "Upgrade: $Name";& $Action;$state.completed+=,$Name;Save-State}
function Wait-Fleet {
    $until=[DateTime]::UtcNow.AddMinutes(5)
    do{
        $probe=Invoke-KitApi $p -Service kibana -Path '/api/fleet/agents?perPage=100' -AllowFailure
        if($probe.Success){return}
        Start-Sleep 3
    }while([DateTime]::UtcNow -lt $until)
    throw 'Fleet API did not become ready.'
}
try{
    Save-State
    Step 'authenticate-source-backup' {
        $verification="$data/recovery-stage-upgrade-$id"
        & (Join-Path $PSScriptRoot 'Stage-KitRecovery.ps1') -RecoveryBundle $RecoveryBundle -ExpectedCiphertextSHA256 $ExpectedCiphertextSHA256 -RecipientCertificate $RecipientCertificate -RecipientPrivateKey $RecipientPrivateKey -Destination $verification -VerifyOnly -ExpectedVersion 9.5.3
        $record=(Get-Content -Raw "$verification/verification.json"|ConvertFrom-Json -AsHashtable).record
        if($record.cluster_uuid -cne $ExpectedClusterUUID -or $record.release_sha256 -ne $install.release_sha256){throw 'Authenticated backup belongs to another source cluster/release.'}
        $state.snapshot=$record.snapshot
    }
    Step 'preserve-configuration' {
        $saved="$data/upgrade-preserved-$id"
        $null=Invoke-KitNative install @('-d','-m','0700',$saved)
        $null=Invoke-KitNative cp @('-a','--','/etc/elasticsearch','/etc/kibana','/etc/elastic-kit','/var/lib/elastic-kit/install-state.json','/var/lib/elastic-kit/fleet-state.json',$saved) -Sensitive
        $state.preserved_directory=$saved
        $state.identity_files=@(Get-ChildItem '/etc/elastic-kit/pki','/etc/elastic-kit/secrets' -File -Recurse -Force|ForEach-Object {@{path=$_.FullName;sha256=(Get-FileHash $_.FullName -Algorithm SHA256).Hash}})
    }
    Step 'prepare-verified-agent-trust' {
        $version=$release.Roles.linux_agent[0].package_version
        $extract="$data/agent-install-$version"
        $arguments=@((Join-Path $PSScriptRoot 'extract-agent.py'),'--archive',$release.Roles.linux_agent[0].full_path,'--destination',$extract,'--version',$version)
        if(Test-Path $extract){$arguments+=,'--verify-existing'}
        $null=Invoke-KitNative '/usr/libexec/platform-python' $arguments
        $null=Invoke-KitNative '/usr/libexec/platform-python' @((Join-Path $PSScriptRoot 'write-agent-trust.py'),'--root',"$extract/elastic-agent-$version-linux-x86_64",'--name','elastic-kit-agent-upgrade','--upgrade-to',"$data/Elastic/Agent",'--version',$version)
        $null=Invoke-KitNative restorecon @('-RF','/etc/fapolicyd/trust.d')
        $null=Invoke-KitNative fapolicyd-cli @('--update')
    }
    Step 'stop-and-upgrade-stack-rpms' {
        $null=Invoke-KitNative systemctl @('stop','elastic-agent','kibana')
        $null=Invoke-KitApi $p -Method POST -Path '/_flush'
        $null=Invoke-KitNative systemctl @('stop','elasticsearch')
        $null=Invoke-KitNative rpm (@('-Uvh')+$rpms) -Sensitive
        $null=Invoke-KitNative fapolicyd-cli @('--update')
        $null=Invoke-KitNative systemctl @('daemon-reload')
        $null=Invoke-KitNative systemctl @('start','elasticsearch')
        $null=Wait-KitApi $p 'es' -Seconds 600
        $upgraded=(Invoke-KitApi $p -Path '/').Data
        if($upgraded.cluster_uuid -cne $ExpectedClusterUUID -or $upgraded.version.number -ne '9.5.4'){throw 'Upgraded Elasticsearch identity/version check failed.'}
        $null=Invoke-KitNative systemctl @('start','kibana')
        $null=Wait-KitApi $p 'kibana' -Seconds 600
        Wait-Fleet
    }
    Step 'publish-offline-upgrade-artifacts' {
        $config=Get-Content -Raw '/etc/elastic-kit/artifact-server.json'|ConvertFrom-Json -AsHashtable
        if($config.root -ne "$data/artifacts"){throw 'Unexpected artifact root preserved.'}
        foreach($file in @($release.Manifest.files|Where-Object {$_.Contains('artifact_path')})){
            $target=Resolve-KitMember $config.root $file.artifact_path
            $null=Invoke-KitNative install @('-d','-m','0755',(Split-Path -Parent $target))
            if(Test-Path $target){if((Get-FileHash $target -Algorithm SHA512).Hash -ne $file.sha512){throw 'Existing artifact differs; preserved.'}}
            else{$null=Invoke-KitNative install @('-m','0644',$file.full_path,$target)}
            $old=@($config.files|Where-Object {$_.path -eq $file.artifact_path})
            if($old.Count -eq 0){$config.files+=,@{path=$file.artifact_path;bytes=$file.bytes}}
            elseif($old.Count -ne 1 -or $old[0].bytes -ne $file.bytes){throw 'Existing artifact allowlist differs.'}
        }
        Write-KitPrivateFile '/etc/elastic-kit/artifact-server.json' ($config|ConvertTo-Json -Depth 10)
        $null=Invoke-KitNative restorecon @('-RF',$config.root)
        $null=Invoke-KitNative systemctl @('restart','elastic-kit-https')
        foreach($package in $release.Roles.integration){
            $bundled='/usr/share/kibana/node_modules/@kbn/fleet-plugin/target/bundled_packages/'+$package.package_name+'-'+$package.package_version+'.zip'
            if(-not(Test-Path $bundled) -or (Get-FileHash $bundled -Algorithm SHA512).Hash -ne $package.sha512){throw 'Target integration bytes differ from the signed Kibana package.'}
            $null=Invoke-KitApi $p -Service kibana -Method POST -Path ('/api/fleet/epm/packages/'+$package.package_name+'/'+$package.package_version) -Body @{}
        }
    }
    Step 'fleet-managed-agent-upgrade' {
        $download=(Invoke-KitApi $p -Service kibana -Path '/api/fleet/agent_download_sources/elastic-kit-download').Data.item
        if($download.host -ne "https://$($p.hostname):8443"){throw 'Fleet binary download source is not this offline kit.'}
        $null=Invoke-KitNative systemctl @('start','elastic-agent')
        $until=[DateTime]::UtcNow.AddMinutes(5)
        do{
            $agent=(Invoke-KitApi $p -Service kibana -Path "/api/fleet/agents/$agentId").Data.item
            if($agent.status -eq 'online'){break};Start-Sleep 3
        }while([DateTime]::UtcNow -lt $until)
        if($agent.status -ne 'online'){throw 'Original Agent did not reconnect before upgrade.'}
        $null=Invoke-KitApi $p -Service kibana -Method POST -Path "/api/fleet/agents/$agentId/upgrade" -Body @{version=$release.Roles.linux_agent[0].package_version;force=$false}
        $until=[DateTime]::UtcNow.AddMinutes(15)
        do{
            $probe=Invoke-KitApi $p -Service kibana -Path "/api/fleet/agents/$agentId" -AllowFailure
            if($probe.Success){
                $agent=$probe.Data.item
                $version=$agent.local_metadata.elastic.agent.version
                if($agent.status -eq 'online' -and $version -in @('9.5.4',$release.Roles.linux_agent[0].package_version) -and $agent.Contains('upgraded_at') -and $agent.upgraded_at){break}
            }
            Start-Sleep 5
        }while([DateTime]::UtcNow -lt $until)
        if(-not $probe.Success -or $agent.status -ne 'online' -or $version -notin @('9.5.4',$release.Roles.linux_agent[0].package_version) -or -not $agent.Contains('upgraded_at') -or -not $agent.upgraded_at){throw 'Same Fleet identity did not report a completed target-version upgrade. Inspect the preserved journal and Agent diagnostics.'}
        $state.agent_version=$version
        $state.agent_upgraded_at=$agent.upgraded_at
    }
    Step 'install-new-winlogbeat-assets' {
        $policy='kit-'+$p.site_name.ToLowerInvariant()+'-winlogbeat'
        $template=Get-Content -Raw $release.Roles.winlogbeat_template[0].full_path|ConvertFrom-Json -AsHashtable
        if(-not $template.Contains('data_stream') -or @($template.index_patterns).Count -ne 1 -or $template.index_patterns[0] -ne 'winlogbeat-9.5.4'){throw 'Unexpected target Winlogbeat template.'}
        if(-not $template.template.Contains('settings')){$template.template.settings=@{}}
        $settings=$template.template.settings
        foreach($flat in @('index.lifecycle.name','index.number_of_replicas','index.number_of_shards')){$settings.Remove($flat)}
        if(-not $settings.Contains('index')){$settings.index=@{}}
        if(-not $settings.index.Contains('lifecycle')){$settings.index.lifecycle=@{}}
        $settings.index.lifecycle.name=$policy;$settings.index.number_of_replicas=0;$settings.index.number_of_shards=1
        $null=Invoke-KitApi $p -Method PUT -Path '/_index_template/winlogbeat-9.5.4' -Body $template
        foreach($pipeline in ($release.Roles.winlogbeat_pipeline|Sort-Object @{Expression={if($_.pipeline_id -match '-routing$'){2}elseif($_.pipeline_id -match '-security$'){1}else{0}}})){
            if($pipeline.pipeline_id -notmatch '^winlogbeat-9\.5\.4-[a-z_]+$'){throw 'Unexpected target pipeline identity.'}
            $null=Invoke-KitApi $p -Method PUT -Path ('/_ingest/pipeline/'+$pipeline.pipeline_id) -BodyFile $pipeline.full_path
        }
        $stream=Invoke-KitApi $p -Path '/_data_stream/winlogbeat-9.5.4' -AllowFailure
        if($stream.Status -eq 404){$null=Invoke-KitApi $p -Method PUT -Path '/_data_stream/winlogbeat-9.5.4'}
        elseif(-not $stream.Success){throw 'Could not inspect target Winlogbeat stream.'}
        $output="$data/output/upgrade-$id"
        $null=Invoke-KitNative install @('-d','-m','0700',$output)
        $vendor=$release.Roles.winlogbeat_zip[0]
        & (Join-Path $PSScriptRoot 'Build-WinlogbeatBundle.ps1') -SiteProfile $SiteProfile -VendorZip $vendor.full_path -ExpectedSHA512 $vendor.sha512 -CaCertificate '/etc/elastic-kit/pki/http-ca/ca.crt' -OutputZip "$output/Winlogbeat.zip" -OutputDirectory "$output/Winlogbeat"
        $state.new_winlogbeat_directory=$output
    }
    Step 'accept-server-and-preserved-identities' {
        foreach($file in $state.identity_files){if((Get-FileHash -LiteralPath $file.path -Algorithm SHA256).Hash -ne $file.sha256){throw 'Existing CA or protected credential changed unexpectedly.'}}
        $now=(Invoke-KitApi $p -Path '/').Data
        if($now.cluster_uuid -cne $ExpectedClusterUUID){throw 'Cluster UUID changed.'}
        $count=(Invoke-KitApi $p -Path '/winlogbeat-*/_count').Data.count
        if($count -lt $beforeCount){throw 'Saved event count decreased during the bounded lab transition.'}
        & (Join-Path $PSScriptRoot 'Test-ElasticKit.ps1') -SiteProfile $SiteProfile
        $install.version='9.5.4';$install.release_sha256=$release.SHA256;$install.status='upgraded-server-accepted-endpoint-and-reboot-tests-pending'
        Write-KitPrivateFile $installPath ($install|ConvertTo-Json -Depth 12)
        $fleetState=Get-Content -Raw '/var/lib/elastic-kit/fleet-state.json'|ConvertFrom-Json -AsHashtable
        $fleetState.release_sha256=$release.SHA256
        Write-KitPrivateFile '/var/lib/elastic-kit/fleet-state.json' ($fleetState|ConvertTo-Json -Depth 12)
        $state.windows_events_after=$count
    }
    $state.status='server-upgrade-accepted-endpoint-and-reboot-tests-pending';Save-State
    Write-Host 'Prove new Windows events, reboot with the network offline, and repeat acceptance before declaring the kit upgraded.'
}catch{
    $state.status='failed-inspect-preserved-journal';Save-State
    throw
}finally{$lock.Dispose()}
