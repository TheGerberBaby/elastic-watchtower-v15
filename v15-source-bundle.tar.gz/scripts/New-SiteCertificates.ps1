#requires -Version 7.2
[CmdletBinding()]
param(
    [Parameter(Mandatory)][string]$SiteProfile,
    [string]$OutputDirectory = '/etc/elastic-kit/pki',
    [ValidateRange(1,1095)][int]$CertificateDays = 365
)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
Import-Module (Join-Path $PSScriptRoot 'SiteProfile.psm1') -Force
$profile = Get-Content -Raw -LiteralPath $SiteProfile | ConvertFrom-Json -AsHashtable
$null = Test-SiteProfile $profile
# Check the explicit decision before attempting any native command or filesystem mutation.
if ($profile.schema_version -notin @(3,4) -or $profile.mode -cne 'fresh' -or $profile.tls_mode -cne 'certutil') {
    throw 'This command only generates certificates for fresh setup with the explicit certutil choice. Supplied/recovery certificates are preserved; they require the separate validation/import workflow.'
}
if (-not $IsLinux -or (& id -u) -ne '0') { throw 'Run at the deployed RHEL root console, after installing the verified Elasticsearch RPM.' }
& bash (Join-Path $PSScriptRoot 'generate-site-certificates.sh') $OutputDirectory $profile.hostname $profile.ipv4_address $profile.site_name '/usr/share/elasticsearch/bin/elasticsearch-certutil' ([string]$CertificateDays)
if ($LASTEXITCODE -ne 0) { throw 'Certificate generation failed. Preserve any incomplete output for inspection; no service configuration was changed.' }
Write-Output 'Site certificates generated and checked. Service installation/configuration and recovery backup are separate steps.'
Write-Output ('Public CA for the Winlogbeat builder: ' + (Join-Path $OutputDirectory 'http-ca/ca.crt'))
