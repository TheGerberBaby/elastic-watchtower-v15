#requires -Version 7.2
& (Join-Path $PSScriptRoot 'Start-OfflineSetup.ps1')
