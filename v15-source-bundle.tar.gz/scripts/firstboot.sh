#!/bin/bash
# Image foundation only: offline artifact-host tools, not a complete Elastic installer.
set -euo pipefail
umask 077
[[ $(id -u) == 0 ]] || exit 1
for tool in podman sha256sum systemctl install restorecon mount findmnt /usr/libexec/platform-python; do
  command -v "$tool" >/dev/null || { echo "Missing image prerequisite: $tool"; exit 1; }
done
install -d -m 0755 /usr/local/libexec/elastic-kit /etc/elastic-kit /srv/elastic-artifacts
install -d -m 0700 /var/lib/elastic-kit /var/log/elastic-kit
# The cloud STIG customization can copy inode64 into the tmpfs fstab entry.
# RHEL 8 rejects it, leaving the live /dev/shm mount without noexec.
/usr/libexec/platform-python "$(dirname "$0")/normalize-shm-fstab.py"
restorecon /etc/fstab
mount -o remount /dev/shm
for option in nodev nosuid noexec; do
  findmnt -rn -o OPTIONS /dev/shm | tr ',' '\n' | grep -qx "$option"
done
# Re-run the failed boot unit, rather than clearing an unverified failure.
if systemctl is-failed --quiet systemd-remount-fs.service; then
  systemctl restart systemd-remount-fs.service
fi
cat > /etc/elastic-kit/artifacts-nginx.conf <<'NGINX'
worker_processes 1;
pid /tmp/nginx.pid;
error_log /dev/stderr warn;
events { worker_connections 256; }
http {
  access_log /dev/stdout;
  server_tokens off;
  client_body_temp_path /tmp/client-body;
  proxy_temp_path /tmp/proxy;
  fastcgi_temp_path /tmp/fastcgi;
  uwsgi_temp_path /tmp/uwsgi;
  scgi_temp_path /tmp/scgi;
  server {
    listen 8080;
    root /srv/artifacts;
    autoindex off;
    default_type application/octet-stream;
    location = /healthz { return 200 "ready\n"; }
    location / { limit_except GET { deny all; } try_files $uri =404; }
    location ~ /\. { deny all; }
  }
}
NGINX
chmod 0644 /etc/elastic-kit/artifacts-nginx.conf
cat > /usr/local/libexec/elastic-kit/run-artifacts <<'RUNNER'
#!/bin/bash
set -euo pipefail
image=$(cat /etc/elastic-kit/artifact-image-id)
[[ "$image" =~ ^sha256:[a-f0-9]{64}$ ]] || { echo 'Invalid pinned image ID'; exit 1; }
# Bind to loopback until an approved TLS frontend/network profile is configured.
# No registry pulls, privilege escalation, writable payload or host networking.
exec /usr/bin/podman run --rm --name elastic-kit-artifacts --pull=never \
  --user 1001:1001 --cap-drop=ALL --security-opt=no-new-privileges \
  --read-only --tmpfs /tmp:rw,nosuid,nodev,size=64m,mode=1777 \
  --pids-limit=128 --memory=256m \
  -p 127.0.0.1:8080:8080 \
  -v /srv/elastic-artifacts:/srv/artifacts:ro,Z \
  -v /etc/elastic-kit/artifacts-nginx.conf:/etc/nginx/nginx.conf:ro,Z \
  --entrypoint /usr/sbin/nginx "$image" -g 'daemon off;'
RUNNER
cat > /etc/systemd/system/elastic-kit-artifacts.service <<'UNIT'
[Unit]
Description=Offline Elastic artifact host (loopback HTTP)
After=network-online.target
Wants=network-online.target
ConditionPathExists=/etc/elastic-kit/artifact-image-id
RequiresMountsFor=/srv/elastic-artifacts /var/lib/containers

[Service]
Type=simple
ExecStart=/bin/bash /usr/local/libexec/elastic-kit/run-artifacts
ExecStop=-/usr/bin/podman stop --time 10 elastic-kit-artifacts
Restart=on-failure
RestartSec=10
TimeoutStopSec=45

[Install]
WantedBy=multi-user.target
UNIT
cat > /usr/local/libexec/elastic-kit/load-artifacts <<'LOADER'
#!/bin/bash
# Usage: bash load-artifacts ARCHIVE SHA256 IMAGE_ID
# Checksums/IDs must come from an authenticated approved release manifest.
set -euo pipefail
umask 077
[[ $(id -u) == 0 && $# == 3 ]] || {
  echo 'As root: bash /usr/local/libexec/elastic-kit/load-artifacts ARCHIVE SHA256 sha256:IMAGE_ID'; exit 2;
}
archive=$(realpath -e -- "$1")
[[ -f "$archive" && "$2" =~ ^[a-f0-9]{64}$ && "$3" =~ ^sha256:[a-f0-9]{64}$ ]] || exit 2
exec 9>/var/lib/elastic-kit/artifacts.lock
flock -n 9 || { echo 'Another artifact setup is running'; exit 1; }
actual=$(sha256sum -- "$archive")
[[ "${actual%% *}" == "$2" ]] || { echo 'Archive hash mismatch'; exit 1; }
podman load --input "$archive"
podman image exists "$3" || { echo 'Expected pinned image is absent'; exit 1; }
test_result=$(podman run --rm --pull=never --network=none --read-only \
  --user 1001:1001 --cap-drop=ALL --security-opt=no-new-privileges \
  --tmpfs /tmp:rw,nosuid,nodev,size=64m,mode=1777 \
  -v /etc/elastic-kit/artifacts-nginx.conf:/etc/nginx/nginx.conf:ro,Z \
  --entrypoint /usr/sbin/nginx "$3" -t 2>&1) || { printf '%s\n' "$test_result"; exit 1; }
printf '%s\n' "$3" > /etc/elastic-kit/artifact-image-id.new
chmod 0600 /etc/elastic-kit/artifact-image-id.new
mv /etc/elastic-kit/artifact-image-id.new /etc/elastic-kit/artifact-image-id
systemctl enable elastic-kit-artifacts.service
systemctl restart elastic-kit-artifacts.service
for attempt in {1..15}; do
  if curl --noproxy '*' -fsS http://127.0.0.1:8080/healthz; then
    echo 'Local artifact host ready. External TLS/frontend configuration still required.'
    exit 0
  fi
  sleep 1
done
echo 'Health check failed; inspect journalctl -u elastic-kit-artifacts'; exit 1
LOADER
chmod 0750 /usr/local/libexec/elastic-kit/run-artifacts /usr/local/libexec/elastic-kit/load-artifacts
chmod 0644 /etc/systemd/system/elastic-kit-artifacts.service
cat > /etc/elastic-kit/README <<'README'
Offline Elastic image foundation
-------------------------------
Podman is installed. No container is pulled or service exposed during first boot.
Stage only approved distributable binaries under /srv/elastic-artifacts, preserving
the Elastic artifact URL paths. Never put credentials, snapshots, private keys or
site configuration in this served directory. Use a separately sized data disk for
artifacts/container storage; the compact base /var filesystem is not a sizing plan.

Load a vetted nginx-compatible OCI/docker archive from the offline release bundle:
  bash /usr/local/libexec/elastic-kit/load-artifacts ARCHIVE SHA256 sha256:IMAGE_ID
The container must provide /usr/sbin/nginx and support UID 1001 with this config.
Validate the archive hash and image ID against an authenticated release manifest.
The service binds only 127.0.0.1:8080. Configure an approved HTTPS frontend and
scoped firewall access before pointing Fleet's artifact download source to it.

This foundation does NOT yet join AD, configure IP/DNS, mount SMB, install Elastic,
upload integrations, or restore snapshots. Those require the site profile and
tested release runner. Existing endpoints are not automatically enrolled.
No claim of complete STIG or Elastic/JVM FIPS compliance is made.
README
chmod 0644 /etc/elastic-kit/README
restorecon -RF /etc/elastic-kit /usr/local/libexec/elastic-kit /var/lib/elastic-kit /var/log/elastic-kit
restorecon /etc/systemd/system/elastic-kit-artifacts.service
if command -v fapolicyd-cli >/dev/null; then
  for helper in run-artifacts load-artifacts; do
    path="/usr/local/libexec/elastic-kit/$helper"
    fapolicyd-cli --file update "$path" || fapolicyd-cli --file add "$path"
  done
  fapolicyd-cli --update
fi
systemctl daemon-reload
printf '%s\n' 'Image foundation prepared; read /etc/elastic-kit/README.'
