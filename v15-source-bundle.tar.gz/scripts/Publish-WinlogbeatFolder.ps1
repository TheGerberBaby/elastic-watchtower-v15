#requires -Version 7.2
[CmdletBinding()]
param([Parameter(Mandatory)][string]$SourceDirectory,
      [Parameter(Mandatory)][string]$ShareMount,
      [Parameter(Mandatory)][string]$RelativeDestination,
      [Parameter(Mandatory)][ValidatePattern('^[a-fA-F0-9]{64}$')][string]$ExpectedManifestSHA256)
$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
Import-Module (Join-Path $PSScriptRoot 'Kit.Common.psm1') -Force
Assert-KitRoot
if((Invoke-KitNative mountpoint @('-q',$ShareMount) -AllowFailure).ExitCode -ne 0){throw 'The selected staging share is not mounted.'}
$manifestPath=Resolve-KitMember $SourceDirectory 'payload-manifest.json' -MustExist
if((Get-FileHash $manifestPath -Algorithm SHA256).Hash -ne $ExpectedManifestSHA256){throw 'Payload manifest hash mismatch.'}
$manifest=Get-Content -Raw $manifestPath | ConvertFrom-Json -AsHashtable
if($manifest.schema_version -ne 1){throw 'Unsupported payload manifest.'}
$destination=Resolve-KitMember $ShareMount $RelativeDestination
if(Test-Path $destination){throw 'Existing published folder preserved. Choose a new versioned destination.'}
$seen=[Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
foreach($file in $manifest.files){
    if(-not $seen.Add($file.path)){throw 'Duplicate payload entry.'}
    $source=Resolve-KitMember $SourceDirectory $file.path -MustExist
    if((Get-FileHash $source -Algorithm SHA256).Hash -ne $file.sha256){throw 'Payload content mismatch.'}
}
$null=New-Item -ItemType Directory -Path $destination
foreach($file in $manifest.files){
    $target=Resolve-KitMember $destination $file.path
    $null=New-Item -ItemType Directory -Path (Split-Path -Parent $target) -Force
    Copy-Item -LiteralPath (Join-Path $SourceDirectory $file.path) -Destination $target
    if((Get-FileHash $target -Algorithm SHA256).Hash -ne $file.sha256){throw 'Published file verification failed. Partial folder preserved.'}
}
# Publish the acceptance manifest last, after all content has copied and verified.
Copy-Item -LiteralPath $manifestPath -Destination (Join-Path $destination 'payload-manifest.json')
if((Get-FileHash (Join-Path $destination 'payload-manifest.json') -Algorithm SHA256).Hash -ne $ExpectedManifestSHA256){throw 'Published manifest verification failed.'}
Write-Host "Published verified payload: $destination"
Write-Host "ExpectedManifestSHA256: $ExpectedManifestSHA256"
