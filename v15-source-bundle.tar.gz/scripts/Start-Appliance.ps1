#requires -Version 7.2
[CmdletBinding()]
param([ValidateSet('Menu','HostSetup','Setup','Status','Kits','Certificates','Restore')][string]$Action='Menu',
      [switch]$ListActions,[switch]$LineMode)
$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
$actions=@(
    @{id='HostSetup';label='Host interview / resume';detail='Network, hostname, DNS, optional AD and share. Applies only after confirmation.'},
    @{id='Setup';label='Elastic setup / resume';detail='Set up from the embedded offline release: Elastic, Kibana, Fleet, EPR and Winlogbeat.'},
    @{id='Status';label='Service status and readiness';detail='Inspect service state. Does not change passwords, certificates or data.'},
    @{id='Kits';label='Find generated deployment kits';detail='Lists existing output. Does not silently regenerate keys or enroll endpoints.'},
    @{id='Certificates';label='Certificate expiry / renewal status';detail='Read-only certificate inspection. Automated renewal is not implemented yet.'},
    @{id='Restore';label='Guided snapshot recovery';detail='Explicit recovery operation. Requires a prepared empty replacement and protected backup.'}
)
if($ListActions){$actions | ConvertTo-Json -Depth 3;return}
Import-Module (Join-Path $PSScriptRoot 'Kit.Common.psm1') -Force
Assert-KitRoot
function Invoke-ApplianceAction([string]$Selected) {
    switch($Selected){
        'HostSetup' { & (Join-Path $PSScriptRoot 'Start-HostSetup.ps1') -LineMode:$LineMode }
        'Setup' { & (Join-Path $PSScriptRoot 'Start-OfflineSetup.ps1') }
        'Status' {
            foreach($name in @('elasticsearch','kibana','elastic-agent','elastic-kit-https','elastic-epr')){
                $result=Invoke-KitNative systemctl @('show',$name,'--property=ActiveState,SubState,UnitFileState','--no-pager') -AllowFailure
                Write-Host "--- $name ---";Write-Host $result.Stdout
                if($result.ExitCode){Write-Host 'Unit could not be inspected.' -ForegroundColor Yellow}
            }
            if(Test-Path '/etc/elastic-kit/site/site.json'){ & (Join-Path $PSScriptRoot 'Test-ElasticKit.ps1') -SiteProfile '/etc/elastic-kit/site/site.json' }
        }
        'Kits' {
            $roots=@('/home/elastic/kits','/srv/elastic-data/output','/srv/elastic-payloads')
            $found=@(foreach($root in $roots){if(Test-Path -LiteralPath $root){Get-ChildItem -LiteralPath $root -File -Recurse -Filter '*.zip' | Where-Object {$_.Name -match 'winlogbeat|fleet.*kit|agent.*kit'}}})
            if(-not $found.Count){Write-Host 'No generated client kits found. Missing offline payloads cannot be created by rerunning host setup.' -ForegroundColor Yellow}
            else{$found | Select-Object FullName,Length | Format-Table -AutoSize | Out-Host}
        }
        'Certificates' {
            $found=@(foreach($root in @('/etc/elastic-kit/pki','/etc/elastic-kit/live-stack')){
                if(Test-Path -LiteralPath $root){Get-ChildItem -LiteralPath $root -Filter '*.crt' -File -Recurse}
            })
            foreach($certificate in $found){
                Write-Host $certificate.FullName
                $result=Invoke-KitNative openssl @('x509','-in',$certificate.FullName,'-noout','-subject','-issuer','-dates') -AllowFailure
                Write-Host $result.Stdout
            }
            if(-not $found.Count){Write-Host 'No kit certificates found.'}
            Write-Host 'Renewal is not implemented. Do not rerun fresh certificate generation against an existing cluster.' -ForegroundColor Yellow
        }
        'Restore' {
            Write-Host 'Recovery replaces an explicitly prepared empty target identity and data.' -ForegroundColor Yellow
            if((Read-Host 'Open the guarded recovery workflow? Type RESTORE') -ceq 'RESTORE'){
                & (Join-Path $PSScriptRoot 'Start-KitRecovery.ps1')
            }
        }
    }
}
if($Action -ne 'Menu'){Invoke-ApplianceAction $Action;return}
if([Console]::IsInputRedirected -or [Console]::IsOutputRedirected){throw 'Use an interactive console or select -Action explicitly.'}
$selected=0
while($true){
    Clear-Host
    Write-Host 'Elastic appliance maintenance - /home/elastic'
    Write-Host 'Tab/Shift+Tab or Up/Down: select. Enter: open. Esc: exit.'
    Write-Host ''
    for($i=0;$i -lt $actions.Count;$i++){
        $prefix=if($i -eq $selected){'> '}else{'  '}
        Write-Host ($prefix+$actions[$i].label)
    }
    Write-Host '';Write-Host $actions[$selected].detail
    $key=[Console]::ReadKey($true)
    if($key.Key -eq 'Escape'){return}
    if($key.Key -eq 'UpArrow' -or ($key.Key -eq 'Tab' -and ($key.Modifiers -band [ConsoleModifiers]::Shift))){$selected=($selected-1+$actions.Count)%$actions.Count}
    elseif($key.Key -in @('DownArrow','Tab')){$selected=($selected+1)%$actions.Count}
    elseif($key.Key -eq 'Enter'){
        Clear-Host
        try{Invoke-ApplianceAction $actions[$selected].id}catch{Write-Host $_.Exception.Message -ForegroundColor Yellow}
        $null=Read-Host 'Press Enter to return to the menu'
    }
}
